package com.lawyer.manager;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout list;
    private JSONArray cases = new JSONArray();
    private SharedPreferences prefs;
    private final String[] categories = {"جنائي", "عقاري", "مدني", "أسري", "تجاري", "أخرى"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("lawyer_manager", MODE_PRIVATE);
        try { cases = new JSONArray(prefs.getString("cases", "[]")); } catch (Exception ignored) {}
        buildUi();
        renderCases();
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(0xFF172033);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(4), dp(6), dp(4), dp(6));
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(18), dp(16), dp(24));
        page.setBackgroundColor(0xFFF4F6FA);
        scroll.addView(page);

        TextView title = text("Lawyer_Manager", 25, true);
        title.setGravity(Gravity.CENTER);
        title.setTextColor(0xFF12345A);
        page.addView(title);
        TextView subtitle = text("إدارة القضايا ومواعيد الجلسات", 16, false);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle);

        Button add = button("+ إضافة قضية جديدة");
        add.setOnClickListener(v -> showAddDialog());
        page.addView(add);

        TextView heading = text("القضايا المسجلة", 20, true);
        heading.setPadding(0, dp(16), 0, dp(8));
        page.addView(heading);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        page.addView(list);
        setContentView(scroll);
    }

    private void showAddDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(12), dp(4), dp(12), dp(4));

        EditText name = new EditText(this);
        name.setHint("عنوان القضية");
        form.addView(name);

        EditText client = new EditText(this);
        client.setHint("اسم الموكل (اختياري)");
        form.addView(client);

        Spinner category = new Spinner(this);
        category.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories));
        form.addView(category);

        EditText date = new EditText(this);
        date.setHint("تاريخ الجلسة (اختياري)");
        date.setFocusable(false);
        date.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            new DatePickerDialog(this, (view, y, m, d) -> {
                date.setText(String.format(Locale.getDefault(), "%04d-%02d-%02d", y, m + 1, d));
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
        form.addView(date);

        EditText notes = new EditText(this);
        notes.setHint("ملاحظات");
        notes.setMinLines(2);
        form.addView(notes);

        ScrollView wrapper = new ScrollView(this);
        wrapper.addView(form);

        new AlertDialog.Builder(this)
            .setTitle("إضافة قضية")
            .setView(wrapper)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ", (dialog, which) -> {
                String caseName = name.getText().toString().trim();
                if (caseName.isEmpty()) {
                    Toast.makeText(this, "اكتب عنوان القضية أولًا", Toast.LENGTH_SHORT).show();
                    return;
                }
                JSONObject item = new JSONObject();
                try {
                    item.put("name", caseName);
                    item.put("client", client.getText().toString().trim());
                    item.put("category", category.getSelectedItem().toString());
                    item.put("date", date.getText().toString().trim());
                    item.put("notes", notes.getText().toString().trim());
                    item.put("created", System.currentTimeMillis());
                    cases.put(item);
                    saveCases();
                    renderCases();
                    Toast.makeText(this, "تم حفظ القضية على الهاتف", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "تعذر حفظ القضية", Toast.LENGTH_SHORT).show();
                }
            }).show();
    }

    private void saveCases() {
        prefs.edit().putString("cases", cases.toString()).apply();
    }

    private void renderCases() {
        if (list == null) return;
        list.removeAllViews();
        if (cases.length() == 0) {
            list.addView(text("لا توجد قضايا بعد. اضغط على «إضافة قضية جديدة» للبدء.", 15, false));
            return;
        }
        for (int i = cases.length() - 1; i >= 0; i--) {
            final int index = i;
            JSONObject item = cases.optJSONObject(i);
            if (item == null) continue;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(8), dp(12), dp(8));
            card.setBackgroundColor(0xFFFFFFFF);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, dp(5), 0, dp(8));
            card.setLayoutParams(params);

            card.addView(text(item.optString("name"), 18, true));
            card.addView(text("التصنيف: " + item.optString("category"), 14, false));
            String client = item.optString("client");
            if (!client.isEmpty()) card.addView(text("الموكل: " + client, 14, false));
            String date = item.optString("date");
            if (!date.isEmpty()) card.addView(text("موعد الجلسة: " + date, 14, true));
            String notes = item.optString("notes");
            if (!notes.isEmpty()) card.addView(text("ملاحظات: " + notes, 14, false));

            Button delete = button("حذف القضية");
            delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("هل تريد حذف هذه القضية؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف", (d, w) -> {
                    JSONArray updated = new JSONArray();
                    for (int j = 0; j < cases.length(); j++) {
                        if (j != index) updated.put(cases.opt(j));
                    }
                    cases = updated;
                    saveCases();
                    renderCases();
                }).show());
            card.addView(delete);
            list.addView(card);
        }
    }
}
