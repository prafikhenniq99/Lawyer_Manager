<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class RR_Portfolio_GridE extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-portfolio-grid';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Portfolio Grid', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
     
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

     // title/content
     $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-1', 'layout-2'] );

    // Query Controls
    $this->rr_query_controls_wooc('product', 'Product', '6', '10', 'product', 'product_cat', ['layout-1', 'layout-2']);


	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('security_section', 'Section - Style', '.rr-el-section'); 
        $this->rr_section_style_controls('cta_section', 'CTA Section - Style', '.rr-el-section-cta'); 
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function render() {
        $settings = $this->get_settings_for_display();

        // Setup query arguments using helper function
        $query_args = RR_Helper::get_query_args('product', 'product_cat', $settings);

        // The Query
        $query = new \WP_Query($query_args);

        $filter_list = $settings['category'];

        // Ensure $filter_list is an array
        if (is_string($filter_list)) {
            $filter_list = explode(',', $filter_list); // Convert comma-separated string to array
        } elseif (!is_array($filter_list)) { 
            $filter_list = []; // Fallback to an empty array
        }
        
        // Check if the array is not empty
        if (empty($filter_list)) {
            echo '<p>' . esc_html__('No categories found.', 'rr-core') . '</p>';
            return;
        }

        $tags = get_terms( [
            'hide_empty' => true,
            'taxonomy'   => 'product_tag',
        ] );

        $products = new \WP_Query( [
            'posts_per_page' => -1,
            'post_type'      => 'product',
            'post_status'    => 'publish',

        ] );
        
        ?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ) :     
    $this->add_render_attribute('title_cta_args', 'class', 'rr-portfolio__title-white');
?>


<?php else: 
	$this->add_render_attribute('title_args', 'class', 'title wow fadeInLeft animated');
    
?>
<!-- trend-product-area-start -->
<div class="rr-trend-product-5__area project-section-4 pb-60 overflow-hidden">
    <div class="container custom-container">
        <div class="rr-trend-product-5__top-mb">
            <div class="row align-items-center">
                <div class="rr-trend-product-5__btn-wrap">
                    <h4 class="title-5 wow fadeInLeft animated" data-wow-delay=".1s">Trending Product</h4>
                    <div class="button-box wow fadeInLeft animated" data-wow-delay=".2s">
                        <ul class="project-filter text-center wow fade-in-right" data-wow-delay="400ms">
                            <li class="list active" data-filter="*">New Collections </li>
                            <?php
                                foreach ( $tags as $tag ) {
                                    printf( '<li class="list" data-filter=".%s">%s</li>', esc_attr( $tag->slug ), esc_html( $tag->name ) );
                                }
                            ?>
                        </ul>
                        <div class="button">
                            <a class="btn" href="shop-details.html">All Product</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row filter-items">
            <?php foreach ($filter_list as $key => $list): 
                $active_tab = ($key === 0) ? 'active show' : '';

                // Query for products in the current category
                $category_query_args = array_merge($query_args, [
                    'tax_query' => [
                        [
                            'taxonomy' => 'product_cat',
                            'field'    => 'slug',
                            'terms'    => $list, // Use the current tab's category
                        ],
                    ],
                ]);
                $category_query = new \WP_Query($category_query_args);
            ?>
            <div class="col-xl-3 col-lg-4 col-md-6 single-item design app">
                <div class="rr-trend-product-5__item-box wow fadeInLeft animated" data-wow-delay=".1s">
                    <div class="rr-trend-product-5__item">
                        <div class="rr-trend-product-5__thumb fix p-relative">
                            <img src="assets/imgs/project-4/project-5-img-1.png" alt="img not found">
                        </div>
                        <div class="rr-trend-product-5__content">
                            <ul>
                                <li>
                                    <div class="rr-trend-product-5__title-box">
                                        <h4 class="rr-trend-product-5__title-sm"><a href="shop-details.html">Fine Jersey
                                                Tee</a></h4>
                                    </div>
                                </li>
                                <li>
                                    <div class="rr-trend-product-5__price">
                                        <del>$270.30</del>
                                        <span>$230.50</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="rr-trend-product-5__star">
                                        <span>Buyers Rating :</span>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <i class="fa-solid fa-star"></i>
                                        <span class="star"><i class="fa-solid fa-star"></i></span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="rr-trend-product-5__link-box text-center">
                        <a class="rr-btn-cart" href="cart.html">Add To Cart</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php endif;
	}

    function get_portfolio_tags( $post_id ) {
        $tags = get_the_terms( $post_id, 'product_tag' );
        $_tags = [];

        if ( !empty( $tags ) ) {

            foreach ( $tags as $tag ) {
                $_tags[$tag->term_id] = $tag->slug;
            }
        }

        return join( ' ', $_tags );
    }
}

$widgets_manager->register( new RR_Portfolio_Grid() );