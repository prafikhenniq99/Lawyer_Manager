<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;
use \Elementor\Repeater;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Hero_Banner extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'hero-banner';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Hero Banner', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

    public function get_rr_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $rr_cfa         = array();
        $rr_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $rr_forms       = get_posts( $rr_cf_args );
        $rr_cfa         = ['0' => esc_html__( 'Select Form', 'rr-core' ) ];
        if( $rr_forms ){
            foreach ( $rr_forms as $rr_form ){
                $rr_cfa[$rr_form->ID] = $rr_form->post_title;
            }
        }else{
            $rr_cfa[ esc_html__( 'No contact form found', 'rr-core' ) ] = 0;
        }
        return $rr_cfa;
    }


	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  


	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core')
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->rr_section_title_render_controls('banner', 'Banner Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1', 'layout-2','layout-3','layout-4','layout-5']);
        // button
        $this->rr_button_render('banner', 'Button', ['layout-1', 'layout-2']);
        $this->rr_button_render('banner_2', 'Button Two', ['layout-1']);
    
        // banner shape
        $this->start_controls_section(
         'rr_banner_shape',
             [
               'label' => esc_html__( 'Hero Shape', 'rr-core' ),
               'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
             ]
         
        );

        $this->add_control(
         'rr_banner_shape_switch',
         [
           'label'        => esc_html__( 'Shape On/Off', 'rr-core' ),
           'type'         => \Elementor\Controls_Manager::SWITCHER,
           'label_on'     => esc_html__( 'Show', 'rr-core' ),
           'label_off'    => esc_html__( 'Hide', 'rr-core' ),
           'return_value' => 'yes',
           'default'      => '0',
         ]
        );
        $this->end_controls_section();

        // thumbnail image
        $this->start_controls_section(
        'rr_thumbnail_section',
            [
                'label' => esc_html__( 'Thumbnail', 'rr-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'rr_thumbnail_image',
            [
                'label' => esc_html__( 'Choose Thumbnail Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_thumbnail_image2',
            [
                'label' => esc_html__( 'Choose Cup Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'rr_thumbnail_image3',
            [
                'label' => esc_html__( 'Choose Medicine Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_thumbnail_image4',
            [
                'label' => esc_html__( 'Choose Medicine 02 Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_thumbnail_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );
        $this->end_controls_section();

        // hero slider
        $this->start_controls_section(
            'rr-core_hero_sider_area',
            [
                'label' => esc_html__('Hero Slider Area', 'rr-core'),
                'condition' => [
                    'rr_design_style' => 'layout-4'
                ]
            ]
        );

        // repeter field with text 
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'rr-core_hero_slider_title',
            [
                'label'       => esc_html__( 'Title', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Your Title', 'rr-core' ),
                'placeholder' => esc_html__( 'Your Title Text', 'rr-core' ),
                'description' => 'Type Your Title In This Field',
                'label_block' => true,
            ]
        );


        $this->add_control(
            'rr-core_hero_slider_list',
            [
                'label' => esc_html__( 'Hero Slider List', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_section();
       
	}
    

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('banner_section', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('banner_dec', 'banner Description', '.rr-el-desc');
        $this->rr_link_controls_style('repiter_btn', 'banner - Button', '.rr-el-btn');
        $this->rr_link_controls_style('repiter_btn_two', 'banner - Button Two', '.rr-el-btn-1');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): 

    $this->add_render_attribute('title_args', 'class', 'rr-hero-3-title wow rrfadeUp rr-el-title');

?>


<?php else:

    // thumbnail image
    if ( !empty($settings['rr_thumbnail_image']['url']) ) {
        $rr_thumbnail_image = !empty($settings['rr_thumbnail_image']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image']['url'];
        $rr_thumbnail_image_alt = get_post_meta($settings["rr_thumbnail_image"]["id"], "_wp_attachment_image_alt", true);
    }
    // thumbnail image2
    if ( !empty($settings['rr_thumbnail_image2']['url']) ) {
        $rr_thumbnail_image2 = !empty($settings['rr_thumbnail_image2']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image2']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image2']['url'];
        $rr_thumbnail_image_alt2 = get_post_meta($settings["rr_thumbnail_image2"]["id"], "_wp_attachment_image_alt", true);
    }
    // thumbnail image3
    if ( !empty($settings['rr_thumbnail_image3']['url']) ) {
        $rr_thumbnail_image3 = !empty($settings['rr_thumbnail_image3']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image3']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image3']['url'];
        $rr_thumbnail_image_alt3 = get_post_meta($settings["rr_thumbnail_image3"]["id"], "_wp_attachment_image_alt", true);
    }
    // thumbnail image4
    if ( !empty($settings['rr_thumbnail_image4']['url']) ) {
        $rr_thumbnail_image4 = !empty($settings['rr_thumbnail_image4']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image4']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image4']['url'];
        $rr_thumbnail_image_alt4 = get_post_meta($settings["rr_thumbnail_image4"]["id"], "_wp_attachment_image_alt", true);
    }
        
    $this->add_render_attribute('title_args', 'class', 'title mb-15 mb-xs-10 wow fadeInLeft animated rr-el-title');
    // Link
    if ('2' == $settings['rr_banner_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_banner_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn wow fadeInLeft animated rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_banner_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_banner_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn wow fadeInLeft animated rr-el-btn');
        }
    }
    // Link
    if ('2' == $settings['rr_banner_2_btn_link_type']) {
        $this->add_render_attribute('rr-button-2-arg', 'href', get_permalink($settings['rr_banner_2_btn_page_link']));
        $this->add_render_attribute('rr-button-2-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-2-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-2-arg', 'class', 'rr-btn btn-transparent wow fadeInLeft animated rr-el-btn-1');
    } else {
        if ( ! empty( $settings['rr_banner_2_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-2-arg', $settings['rr_banner_2_btn_link'] );
            $this->add_render_attribute('rr-button-2-arg', 'class', 'rr-btn btn-transparent wow fadeInLeft animated rr-el-btn-1');
        }
    }
?>
<!-- Banner area start -->
<section class="banner-home overflow-hidden banner-home-bg p-relative rr-el-section">
    <div class="banner-home__middel-shape"></div>
    <div class="container p-relative z-index-1">
        <div class="banner-all-shape-wrapper">
            <?php if(!empty($settings['rr_banner_shape_switch'])) : ?>
            <div class="banner-home__small-red" data-parallax='{"y": -160, "smoothness": 15}'>
                <img 
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-1/small-red.svg"
                    alt="img not found">
            </div>
            <div class="banner-home__small-parpale" data-parallax='{"x": -160, "smoothness": 15}'>
                <img 
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-1/small-parpale.svg"
                    alt="img not found">
            </div>
            <div class="banner-home__small-blue" data-parallax='{"x": -160, "smoothness": 15}'>
                <img 
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-1/small-blue.svg"
                    alt="img not found">
            </div>
            <div class="banner-home__blue-dot-shape" data-parallax='{"x": -160, "smoothness": 15}'>
                <img 
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-1/blue-dot.svg"
                    alt="img not found">
            </div>
            <div class="banner-home__red-shape" data-parallax='{"x": -160, "smoothness": 15}'>
                <img 
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-1/red-dot.svg"
                    alt="img not found">
            </div>
            <div class="banner-home__blue-shape d-none d-md-block" data-parallax='{"y": -160, "smoothness": 15}'>
                <img 
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-1/blue-shape.svg"
                    alt="img not found">
            </div>
            <div class="banner-home__parpale-shape d-none d-md-block" data-parallax='{"y": -160, "smoothness": 15}'>
                <img 
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-1/parpale-shape.svg"
                    alt="img not found">
            </div>
            <div class="banner-home__banner-shape-1">
                <img class="upDown-top"
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-1/banner-shape-1.svg"
                    alt="img not found">
            </div>
            <div class="banner-home__banner-shape-2">
                <img class="upDown-bottom"
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-1/banner-shape-2.svg"
                    alt="img not found">
            </div>
            <div class="banner-home__banner-right-shape d-none d-md-block">
                <img class=""
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-1/big-right-shape.png"
                    alt="img not found">
            </div>
            <?php endif; ?>
            <?php if(!empty($rr_thumbnail_image4)) : ?>
            <div class="banner-home__card1-shape" data-parallax='{"y": -160, "smoothness": 15}'>
                <img src="<?php echo esc_url($rr_thumbnail_image4); ?>"
                    alt="<?php echo esc_url($rr_thumbnail_image_alt4); ?>">
            </div>
            <?php endif; ?>
            <?php if(!empty($rr_thumbnail_image3)) : ?>
            <div class="banner-home__card2-shape" data-parallax='{"x": -160, "smoothness": 15}'>
                <img src="<?php echo esc_url($rr_thumbnail_image3); ?>"
                    alt="<?php echo esc_url($rr_thumbnail_image_alt3); ?>"> 
            </div>
            <?php endif; ?>
            <?php if(!empty($rr_thumbnail_image2)) : ?>
            <div class="banner-home__cup-shape">
                <img class="zooming" src="<?php echo esc_url($rr_thumbnail_image2); ?>"
                    alt="<?php echo esc_url($rr_thumbnail_image_alt2); ?>">
            </div>
            <?php endif; ?>
        </div>
        <div class="row align-items-center">
            <div class="col-md-7">
                <div class="banner-home__content p-relative">
                    <?php if ( !empty($settings['rr_banner_sub_title' ]) ) : ?>
                    <h6 class="sub-title mb-20 mb-sm-10 mb-xs-5 wow fadeInLeft animated rr-el-sub-title" data-wow-delay="1s">
                        <?php echo rr_kses($settings['rr_banner_sub_title']); ?></h6>
                    <?php endif; ?>
                    <?php if ( !empty($settings['rr_banner_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                                tag_escape( $settings['rr_banner_title_tag'] ),
                                $this->get_render_attribute_string( 'title_args' ),
                                rr_kses( $settings['rr_banner_title' ] )
                                );
                        endif; ?>
                    <div class="description mb-20 mb-sm-15 mb-xs-10 wow fadeInLeft animated" data-wow-delay="1.4s">
                        <?php if ( !empty($settings['rr_banner_description' ]) ) : ?>
                        <p class="rr-el-desc" data-wow-duration=".9s" data-wow-delay=".7s">
                            <?php echo rr_kses($settings['rr_banner_description']); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="banner-home__btn__wrapper d-flex flex-wrap mt-40 mt-md-35 mt-sm-30 mt-xs-25">
                        <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>
                            data-wow-delay="1.5s"><?php echo rr_kses($settings['rr_banner_btn_text']); ?></a>
                        <a <?php echo $this->get_render_attribute_string( 'rr-button-2-arg' ); ?>
                            data-wow-delay="1.6s"><?php echo rr_kses($settings['rr_banner_2_btn_text']); ?></a>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <?php if(!empty($rr_thumbnail_image)) : ?>
                <div class="banner-home__media text-sm-center text-xs-center mt-sm-40">
                    <img src="<?php echo esc_url($rr_thumbnail_image); ?>"
                        alt="<?php echo esc_url($rr_thumbnail_image_alt); ?>">
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<!-- Banner area end -->
<?php endif; 
		
	}
}


$widgets_manager->register( new rr_Hero_Banner() );