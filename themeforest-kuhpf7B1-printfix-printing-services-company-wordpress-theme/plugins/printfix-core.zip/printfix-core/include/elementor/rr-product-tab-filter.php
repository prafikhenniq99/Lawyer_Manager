<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class RR_Product_Tab_Filter extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

    public function get_name() {
        return 'rr_product_tab_filter';
    }

    public function get_title() {
        return __( 'Product Tab Filter', 'rr-core' );
    }

    public function get_icon() {
        return 'rr-icon';
    } 

    public function get_categories() {
        return [ 'rr-core' ];
    }

    public function get_script_depends() {
        return [ 'rr-core' ];
    }
	/**
	 * Get a list of All Post Types
	 *
	 * @return array
	 */
	public static function get_post_types () {
		$diff_key = [
			'elementor_library' => '',
			'attachment' => '',
			'page' => ''
		];
		$post_types = rr_get_post_types( [], $diff_key );
		return $post_types;
	}

    protected function register_controls() {
        $this->register_controls_section();
        $this->style_tab_content();
    }

    protected function register_controls_section() {
      
        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // section title
        $this->start_controls_section(
            '_section_title',
            [
                'label' => __( 'Title & Description', 'rrdevs' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'heading_switch',
            [
                'label' => __( 'Show', 'rrdevs' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'rrdevs' ),
                'label_off' => __( 'Hide', 'rrdevs' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'style_transfer' => true,
            ]
        );


        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'rrdevs' ),
                'label_block' => true,
                'type' => Controls_Manager::TEXT,
                'default' => __( 'bdevs Info Box Title', 'rrdevs' ),
                'placeholder' => __( 'Type Info Box Title', 'rrdevs' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );
              

        $this->end_controls_section();    

		 // Query Controls
         $this->rr_query_controls_wooc('product', 'Product', '6', '10', 'product', 'product_cat', ['layout-1', 'layout-2']);
	

    }

    protected function style_tab_content() {
        $this->rr_section_style_controls('services_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('newsletter_sub_title', 'Subtitle Style', '.ele-subtitle');
        $this->rr_basic_style_controls('newsletter_title', 'Heading Style', '.ele-heading');
        $this->rr_basic_style_controls('newsletter_desc', 'Description Style', '.rr-el-desc');
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
<?php if ( $settings['rr_design_style']  == 'layout-2' ) : 
    $this->add_render_attribute('title_args', 'class', 'rr-team-details-title');  

?>

<?php else:

        $this->add_render_attribute('title_args', 'class', 'teamdetail__progress-wrapper-title pb-30 wow fadeInLeft animated rr-el-title-skill');
    ?>
<!-- trend-product-area-start -->
    <!-- trend-product-area-start -->
    <div class="rr-trend-product-5__area project-section-4 pb-60 overflow-hidden">
        <div class="container custom-container">
            <div class="rr-trend-product-5__top-mb">
                <div class="row align-items-center">
                    <div class="rr-trend-product-5__btn-wrap">
                        <h4 class="title-5 wow fadeInLeft animated" data-wow-delay=".1s">Trending Product</h4>
                        <div class="button-box wow fadeInLeft animated" data-wow-delay=".2s">
                            <ul class="project-filter text-center wow fade-in-right" data-wow-delay="400ms">
                                <li class="list active" data-filter="*">New Collections </li>
                                <li class="list" data-filter=".design">Trending</li>
                                <li class="list" data-filter=".develop">On Sale</li>
                            </ul> 
                            <div class="button">
                                <a class="btn" href="shop-details.html">All Product</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row filter-items">
                <div class="col-xl-3 col-lg-4 col-md-6 single-item design app">
                    <div class="rr-trend-product-5__item-box wow fadeInLeft animated" data-wow-delay=".1s">
                        <div class="rr-trend-product-5__item">
                            <div class="rr-trend-product-5__thumb fix p-relative">
                                <img src="assets/imgs/project-4/project-5-img-1.png" alt="img not found">
                            </div>
                            <div class="rr-trend-product-5__content">
                                <ul>
                                    <li>
                                        <div class="rr-trend-product-5__title-box">
                                            <h4 class="rr-trend-product-5__title-sm"><a href="shop-details.html">Fine Jersey Tee</a></h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__price">
                                            <del>$270.30</del>
                                            <span>$230.50</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__star">
                                            <span>Buyers Rating :</span>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <span class="star"><i class="fa-solid fa-star"></i></span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="rr-trend-product-5__link-box text-center">
                            <a class="rr-btn-cart" href="cart.html">Add To Cart</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 single-item develop app">
                    <div class="rr-trend-product-5__item-box wow fadeInLeft animated" data-wow-delay=".2s">
                        <div class="rr-trend-product-5__item">
                            <div class="rr-trend-product-5__thumb fix p-relative">
                                <img src="assets/imgs/project-4/project-4-img-2.png" alt="img not found">
                            </div>
                            <div class="rr-trend-product-5__content">
                                <ul>
                                    <li>
                                        <div class="rr-trend-product-5__title-box">
                                            <h4 class="rr-trend-product-5__title-sm"><a href="shop-details.html">Hooded Sweatshirt</a></h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__price">
                                            <del>$270.30</del>
                                            <span>$230.50</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__star">
                                            <span>Buyers Rating :</span>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <span class="star"><i class="fa-solid fa-star"></i></span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="rr-trend-product-5__link-box text-center">
                            <a class="rr-btn-cart" href="cart.html">Add To Cart</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 single-item develop app">
                    <div class="rr-trend-product-5__item-box wow fadeInLeft animated" data-wow-delay=".3s">
                        <div class="rr-trend-product-5__item">
                            <div class="rr-trend-product-5__thumb fix p-relative">
                                <img src="assets/imgs/project-4/project-5-img-3.png" alt="img not found">
                            </div>
                            <div class="rr-trend-product-5__content">
                                <ul>
                                    <li>
                                        <div class="rr-trend-product-5__title-box">
                                            <h4 class="rr-trend-product-5__title-sm"><a href="shop-details.html">All-Over-Print T-shirt</a></h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__price">
                                            <del>$270.30</del>
                                            <span>$230.50</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__star">
                                            <span>Buyers Rating :</span>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <span class="star"><i class="fa-solid fa-star"></i></span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="rr-trend-product-5__link-box text-center">
                            <a class="rr-btn-cart" href="cart.html">Add To Cart</a>
                        </div>
                    </div>
                </div>
                 <div class="col-xl-3 col-lg-4 col-md-6 single-item design develop">
                    <div class="rr-trend-product-5__item-box wow fadeInLeft animated" data-wow-delay=".4s">
                        <div class="rr-trend-product-5__item">
                            <div class="rr-trend-product-5__thumb fix p-relative">
                                <img src="assets/imgs/project-4/project-5-img-4.png" alt="img not found">
                            </div>
                            <div class="rr-trend-product-5__content">
                                <ul>
                                    <li>
                                        <div class="rr-trend-product-5__title-box">
                                            <h4 class="rr-trend-product-5__title-sm"><a href="shop-details.html">Fit Round-neck T-shirt</a></h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__price">
                                            <del>$270.30</del>
                                            <span>$230.50</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__star">
                                            <span>Buyers Rating :</span>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <span class="star"><i class="fa-solid fa-star"></i></span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="rr-trend-product-5__link-box text-center">
                            <a class="rr-btn-cart" href="cart.html">Add To Cart</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 single-item design app">
                    <div class="rr-trend-product-5__item-box wow fadeInRight animated" data-wow-delay=".1s">
                        <div class="rr-trend-product-5__item">
                            <div class="rr-trend-product-5__thumb fix p-relative">
                                <img src="assets/imgs/project-4/project-5-img-5.png" alt="img not found">
                            </div>
                            <div class="rr-trend-product-5__content">
                                <ul>
                                    <li>
                                        <div class="rr-trend-product-5__title-box">
                                            <h4 class="rr-trend-product-5__title-sm"><a href="shop-details.html">Midweight Cotton Tee</a></h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__price">
                                            <del>$270.30</del>
                                            <span>$230.50</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__star">
                                            <span>Buyers Rating :</span>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <span class="star"><i class="fa-solid fa-star"></i></span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="rr-trend-product-5__link-box text-center">
                            <a class="rr-btn-cart" href="cart.html">Add To Cart</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 single-item design develop">
                    <div class="rr-trend-product-5__item-box wow fadeInRight animated" data-wow-delay=".2s">
                        <div class="rr-trend-product-5__item">
                            <div class="rr-trend-product-5__thumb fix p-relative">
                                <img src="assets/imgs/project-4/project-5-img-6.png" alt="img not found">
                            </div>
                            <div class="rr-trend-product-5__content">
                                <ul>
                                    <li>
                                        <div class="rr-trend-product-5__title-box">
                                            <h4 class="rr-trend-product-5__title-sm"><a href="shop-details.html">Fit Round-neck T-shirt</a></h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__price">
                                            <del>$270.30</del>
                                            <span>$230.50</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__star">
                                            <span>Buyers Rating :</span>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <span class="star"><i class="fa-solid fa-star"></i></span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="rr-trend-product-5__link-box text-center">
                            <a class="rr-btn-cart" href="cart.html">Add To Cart</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 single-item design app">
                    <div class="rr-trend-product-5__item-box wow fadeInRight animated" data-wow-delay=".3s">
                        <div class="rr-trend-product-5__item">
                            <div class="rr-trend-product-5__thumb fix p-relative">
                                <img src="assets/imgs/project-4/project-5-img-7.png" alt="img not found">
                            </div>
                            <div class="rr-trend-product-5__content">
                                <ul>
                                    <li>
                                        <div class="rr-trend-product-5__title-box">
                                            <h4 class="rr-trend-product-5__title-sm"><a href="shop-details.html">Park Avenue Dress Shirts</a></h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__price">
                                            <del>$270.30</del>
                                            <span>$230.50</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__star">
                                            <span>Buyers Rating :</span>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <span class="star"><i class="fa-solid fa-star"></i></span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="rr-trend-product-5__link-box text-center">
                            <a class="rr-btn-cart" href="cart.html">Add To Cart</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6 single-item design develop">
                    <div class="rr-trend-product-5__item-box wow fadeInRight animated" data-wow-delay=".4s">
                        <div class="rr-trend-product-5__item">
                            <div class="rr-trend-product-5__thumb fix p-relative">
                                <img src="assets/imgs/project-4/project-5-img-8.png" alt="img not found">
                            </div>
                            <div class="rr-trend-product-5__content">
                                <ul>
                                    <li>
                                        <div class="rr-trend-product-5__title-box">
                                            <h4 class="rr-trend-product-5__title-sm"><a href="shop-details.html">Diptych brochure</a></h4>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__price">
                                            <del>$270.30</del>
                                            <span>$230.50</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="rr-trend-product-5__star">
                                            <span>Buyers Rating :</span>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <i class="fa-solid fa-star"></i>
                                            <span class="star"><i class="fa-solid fa-star"></i></span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="rr-trend-product-5__link-box text-center">
                            <a class="rr-btn-cart" href="cart.html">Add To Cart</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
endif; 
    }
}

$widgets_manager->register( new RR_Product_Tab_Filter() );