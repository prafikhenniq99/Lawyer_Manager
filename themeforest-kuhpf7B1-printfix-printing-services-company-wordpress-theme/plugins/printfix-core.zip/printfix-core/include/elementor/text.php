<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Text_Slider extends Widget_Base {

	use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-text-slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Text slider', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

    protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

   
        $this->start_controls_section(
			'about_team_list_sec',
				[
				  'label' => esc_html__( 'Features List', 'rr-core' ),
				  'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
				  'condition' => [
					   'rr_design_style' => ['layout-1', 'layout-2']
				  ]
				]
		   );      
	
		   // repeater for about features list with text , testarea and icon
		   $repeater = new Repeater();
		   
		   $repeater->add_control(
			   'rr_about_features_list_title',
			   [
				   'label' => esc_html__('Title', 'rr-core'),
				   'type' => Controls_Manager::TEXT,
				   'default' => esc_html__('Title', 'rr-core'),
				   'title' => esc_html__('Enter title', 'rr-core'),
				   'label_block' => true
				   
			   ]
		   );

		   $this->add_control(
			   'rr_about_features_list',
			   [
				   'label' => esc_html__('Features List', 'rr-core'),
				   'type' => Controls_Manager::REPEATER,
				   'fields' => $repeater->get_controls(),
				   'default' => [
					   [
						   'rr_about_features_list_title' => esc_html__('Custom shortcodes', 'rr-core'),
					   ]
				   ],
				   'title_field' => '{{{ rr_about_features_list_title }}}',
			   ]
		   );
   
		   $this->end_controls_section();
		   
   
    }

    protected function style_tab_content(){
		$this->rr_section_style_controls('section_section', 'Section Style', '.ele-section');
		$this->rr_basic_style_controls('history_title', 'Title', '.rr-el-box-title');
		$this->rr_section_style_controls('text_section', 'Text BG Color', '.ele-box');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): ?>



<?php else: ?>

<!--slider-->
<div class="tp-slider-text__area tp-slider-text__space fix section-space ele-section ">
    <div class="container-fluid g-0">
        <div class="tp-slider-text-2__bg">
            <div class="row">
                <div class="col-xl-12">
                    <div class="tp-slider-text-2-active ele-box">
                        <?php 
							if ( !empty($settings['rr_about_features_list']) ) :
								foreach ( $settings['rr_about_features_list'] as $item ) :
								$title = $item['rr_about_features_list_title'];
						?>
                        <div class="tp-slider-text-2__item">
                            <div class="tp-slider-text-2__text">
                                <span
                                    class="rr-el-box-title"><?php echo rr_kses( $item['rr_about_features_list_title'] ); ?></span>
                                <svg width="10" height="10" viewBox="0 0 10 10" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M8.29998 1.60012L9.24444 3.11277L5.98587 4.67745L9.41286 5.86773L8.58626 7.52126L5.57571 5.56413L6.14885 9.16307L4.35132 9.25727L4.52116 5.6194L1.73293 7.90446L0.712797 6.32368L3.97137 4.75899L0.569605 3.59143L1.37223 1.93916L4.45594 3.91648L3.88155 0.293575L5.70305 0.198114L5.48653 3.86247L8.29998 1.60012Z"
                                        fill="white" />
                                </svg>
                            </div>
                        </div>
                        <?php endforeach; endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; 
	}
}

$widgets_manager->register( new rr_Text_Slider() );