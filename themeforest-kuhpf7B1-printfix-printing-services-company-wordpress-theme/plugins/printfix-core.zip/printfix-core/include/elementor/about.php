<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_About extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'about';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();


        $this->rr_section_title_render_controls('about', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1', 'layout-2','layout-3','layout-4','layout-5']);

   
        // rr_btn_button_group
        $this->start_controls_section(
            'rr_btn_button_group',
            [
                'label' => esc_html__('Button', 'rr-core'),

            ]
        );

        $this->add_control(
            'rr_button_style',
            [
                'label' => esc_html__('Select Button Style', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'rr-btn-blue-lg' => esc_html__('Style 1', 'rr-core'),
                    'rr-btn-inner' => esc_html__('Style 2', 'rr-core'),
                ],
                'default' => 'rr-btn-blue-lg',
                'condition' => [
                    'rr_design_style' => ['layout-4']
                ]
            ]
        );

        $this->add_control(
            'rr_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'rr-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'rr-core' ),
                'label_off' => esc_html__( 'Hide', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'rr_btn_text',
            [
                'label' => esc_html__('Button Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'rr-core'),
                'title' => esc_html__('Enter button text', 'rr-core'),
                'label_block' => true,
                'condition' => [
                    'rr_btn_button_show' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'rr_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'rr_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'rr_btn_link',
            [
                'label' => esc_html__('Button link', 'rr-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htRRs://your-link.com', 'rr-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'rr_btn_link_type' => '1',
                    'rr_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'rr_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'rr-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => rr_get_all_pages(),
                'condition' => [
                    'rr_btn_link_type' => '2',
                    'rr_btn_button_show' => 'yes'
                ]
            ]
        );
        $this->end_controls_section();

        // _rr_image
		$this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_image_2',
            [
                'label' => esc_html__( 'Choose Image 2', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],

            ]
        );      
        
        $this->add_control(
            'rr_image_3',
            [
                'label' => esc_html__( 'Choose Image 3', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_design_style' => ['layout-4']
                ]
            ]
        );


        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();

        // shape section
        $this->start_controls_section(
            'rr_about_shape',
                [
                'label' => esc_html__( 'Shape', 'rr-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,

            ]
        );
      
        $this->add_control(
            'rr_about_shape_switch',
            [
            'label'        => esc_html__( 'Shape On/Off', 'rr-core' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'rr-core' ),
            'label_off'    => esc_html__( 'Hide', 'rr-core' ),
            'return_value' => 'yes',
            'default'      => '1',
            ]
        );

        $this->end_controls_section();
     
        // list
        $this->start_controls_section(
            'rr_about_list',
                [
                    'label' => esc_html__( 'Info List', 'rr-core' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                    'condition' => [
                        'rr_design_style' => ['layout-1', 'layout-2', 'layout-4']
                    ]
                ]
            );
            
            $repeater = new \Elementor\Repeater();
            
            $repeater->add_control(
            'rr_about_list_title_1',
                [
                'label'   => esc_html__( 'Title', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Default-value', 'rr-core' ),
                'label_block' => true,
                ]
            );
            
            $this->add_control(
                'rr_about_list_list_1',
                [
                'label'       => esc_html__( 'Features List', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                    'rr_about_list_title_1'   => esc_html__( ' Mistakes To Avoid to dum Auam. ', 'rr-core' ),
                    ],
                    [
                    'rr_about_list_title_1'   => esc_html__( 'Avoid to the dumy mistakes', 'rr-core' ),
                    ],
                    [
                    'rr_about_list_title_1'   => esc_html__( ' Your Startup industry stan', 'rr-core' ),
                    ],
                ],
                'title_field' => '{{{ rr_about_list_title_1 }}}',
                ]
            );
            $this->end_controls_section();

            $this->start_controls_section(
                'rr_about_experience',
                    [
                    'label' => esc_html__( 'Experience', 'rr-core' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                    'condition' => [
                        'rr_design_style' => ['layout-1']
                    ]
                ]
            );
          
            $this->add_control(
                'rr_about_experience_switch',
                [
                'label'        => esc_html__( 'Experience On/Off', 'rr-core' ),
                'type'         => \Elementor\Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'Show', 'rr-core' ),
                'label_off'    => esc_html__( 'Hide', 'rr-core' ),
                'return_value' => 'yes',
                'default'      => '1',
                ]
            );
            $this->add_control(
                'rr_extra_about_experience',
                [
                    'label' => esc_html__('Extra About Experience Number', 'rr-core'),
                    'type' => Controls_Manager::TEXT,
                    'title' => esc_html__('Enter Extra About Experience Number', 'rr-core'),
                    'label_block' => true,
                ]
            );
            $this->add_control(
                'rr_extra_about_experience_years',
                [
                    'label' => esc_html__('Extra About Experience Years', 'rr-core'),
                    'type' => Controls_Manager::TEXT,
                    'title' => esc_html__('Enter Extra About Experience Years', 'rr-core'),
                    'label_block' => true,
                ]
            );
            $this->add_control(
                'rr_abouot_experience',
                [
                    'label' => esc_html__('About Experience Paragrap', 'rr-core'),
                    'type' => Controls_Manager::TEXT,
                    'title' => esc_html__('Enter About Experience Paragrap', 'rr-core'),
                    'label_block' => true,
                ]
            );
            $this->end_controls_section();
       // Skill
       $this->start_controls_section(
        'rr_progress_bar',
        [
            'label' => esc_html__('Skill Bar', 'rr-core'),
            'condition' => [
                'rr_design_style' => ['layout-3']
            ]
        ]
    );
    $this->add_control(
        'rr_about_skill_switch',
        [
        'label'        => esc_html__( 'Skill Swittcher', 'rr-core' ),
        'type'         => \Elementor\Controls_Manager::SWITCHER,
        'label_on'     => esc_html__( 'Show', 'rr-core' ),
        'label_off'    => esc_html__( 'Hide', 'rr-core' ),
        'return_value' => 'yes',
        'default'      => '1',
        ]
    );
    $repeater = new Repeater();

    $repeater->add_control(
        'rr_skill_box_title',
        [
            'type' => Controls_Manager::TEXT,
            'label' => esc_html__( 'Skill Title', 'rr-core' ),
            'default' => esc_html__( 'Design', 'rr-core' ),
            'placeholder' => esc_html__( 'Type a skill name', 'rr-core' ),
            'label_block' => true
        ]
    );
 
    $repeater->add_control(
        'rr_skill_num',
        [
            'label'       => esc_html__( 'Skill Number', 'rr-core' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => esc_html__( '85', 'rr-core' ),
            'placeholder' => esc_html__( 'Your Number', 'rr-core' ),
        ]
    );

    $this->add_control(
        'rr_skill_list',
        [
            'label' => esc_html__('About - List', 'rr-core'),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                [
                    'rr_skill_box_title' => esc_html__('Design', 'rr-core'),
                    'rr_skill_num' => '70',
                ],
                [
                    'rr_skill_box_title' => esc_html__('Development', 'rr-core'),
                    'rr_skill_num' => '80',
                ],
                [
                    'rr_skill_box_title' => esc_html__('Customization', 'rr-core'),
                    'rr_skill_num' => '95',
                ],
            ],
            'title_field' => '{{{ rr_skill_box_title }}}',
        ]
    );

    $this->end_controls_section();
     // Skill
     $this->start_controls_section(
        'rr_product',
        [
            'label' => esc_html__('Product Bar', 'rr-core'),
            'condition' => [
                'rr_design_style' => ['layout-3']
            ]
        ]
    );
    $this->add_control(
        'rr_product_switch',
        [
        'label'        => esc_html__( 'Product Swittcher', 'rr-core' ),
        'type'         => \Elementor\Controls_Manager::SWITCHER,
        'label_on'     => esc_html__( 'Show', 'rr-core' ),
        'label_off'    => esc_html__( 'Hide', 'rr-core' ),
        'return_value' => 'yes',
        'default'      => '1',
        ]
    );

    $this->add_control(
        'rr_product_title',
        [
            'type' => Controls_Manager::TEXT,
            'label' => esc_html__( 'Product Title', 'rr-core' ),
            'default' => esc_html__( 'Design', 'rr-core' ),
            'placeholder' => esc_html__( 'Type a Product name', 'rr-core' ),
            'label_block' => true
        ]
    );
    $this->add_control(
        'rr_product_numb',
        [
            'label'       => esc_html__( 'Skill Number', 'rr-core' ),
            'type'        => \Elementor\Controls_Manager::TEXT,
            'default'     => esc_html__( '85', 'rr-core' ),
            'placeholder' => esc_html__( 'Your Number', 'rr-core' ),
        ]
    );
    $this->end_controls_section();
     // Skill
     $this->start_controls_section(
        'rr_explore_product',
        [
            'label' => esc_html__('Explore Product Bar', 'rr-core'),
            'condition' => [
                'rr_design_style' => ['layout-3']
            ]
        ]
    );
    $this->add_control(
        'rr_explore_product_switch',
        [
        'label'        => esc_html__( 'Explore Product Swittcher', 'rr-core' ),
        'type'         => \Elementor\Controls_Manager::SWITCHER,
        'label_on'     => esc_html__( 'Show', 'rr-core' ),
        'label_off'    => esc_html__( 'Hide', 'rr-core' ),
        'return_value' => 'yes',
        'default'      => '1',
        ]
    );

    $this->add_control(
        'rr_explore_product_title',
        [
            'type' => Controls_Manager::TEXT,
            'label' => esc_html__( 'Explore Product Title', 'rr-core' ),
            'default' => esc_html__( 'Design', 'rr-core' ),
            'placeholder' => esc_html__( 'Type a Product name', 'rr-core' ),
            'label_block' => true
        ]
    );
    $this->add_control(
        'rr_explore_product_url',
        [
            'label' => esc_html__( 'Explore Product Url', 'text-domain' ),
            'type' => Controls_Manager::URL,
            'options' => [ 'url', 'is_external', 'nofollow' ],
            'default' => [
                'url' => '',
                'is_external' => true,
                'nofollow' => true,
            ],
            'label_block' => true,
        ]
    );

    $this->end_controls_section();

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('about_section', 'Section - Style', '.rr-el-section'); 
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('section_desc', 'Section - Description', '.rr-el-desc');
        $this->rr_basic_style_controls('about_title', 'About - Title', '.rr-rp-title');
        $this->rr_link_controls_style('about_btn', 'About - Button', '.rr-el-btn');
        $this->rr_basic_style_controls('section_exp', 'Section - Experience', '.rr-el-exp');
        $this->rr_section_style_controls('experience', 'Experience', '.rr-el-experience'); 
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): 
     if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_2']['url']) ) {
        $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
        $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
    }    
    
    // Link
    if ('2' == $settings['rr_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn rr-el-btn');
        }
    }

    $this->add_render_attribute('title_args', 'class', 'latest-about2__content-title rr-el-title');
?>
<section class="latest-about2__area section-space overflow-hidden rr-el-section">
    <div class="container p-relative z-index-1">
        <?php if ( !empty($settings['rr_about_shape_switch']) ) : ?>
        <div class="latest-about2__all-shape">
            <div class="latest-about2__all-shape-bg-shape">
                <img class="upDown-bottom"
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/latest-about/home-2/about2-bg-shape.svg"
                    alt="img not found">
            </div>
            <div class="latest-about2__all-shape-circle-shape">
                <img class="zooming"
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/latest-about/home-2/about2-circle-img1.svg"
                    alt="img not found">
            </div>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-xl-6 col-lg-6">
                <div class="latest-about2__content">
                    <?php if ( !empty($settings['rr_about_sub_title']) ) : ?>
                    <h6 class="latest-about2__content-subtitle rr-el-sub-title">
                        <?php echo rr_kses( $settings['rr_about_sub_title'] ); ?></h6>
                    <?php endif; ?>

                    <?php if ( !empty($settings['rr_about_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_about_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_about_title' ] )
                        );  
                    endif; ?>

                    <div class="latest-about2__content-description">
                        <?php if ( !empty($settings['rr_about_description']) ) : ?>
                        <p class="rr-el-desc" data-wow-delay="1s">
                            <?php echo rr_kses( $settings['rr_about_description'] ); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="latest-about2__content-text">
                        <ul>
                            <?php foreach($settings['rr_about_list_list_1'] as $key => $item) : ?>
                            <li class="rr-rp-title"><i
                                    class="fa-solid fa-check"></i><?php echo rr_kses($item['rr_about_list_title_1']); ?>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <div class="latest-about2__content-btn">
                        <a
                            <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_btn_text']); ?></a>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6">
                <div class="latest-about2__media">
                    <div class="latest-about2__media-img1">
                        <?php if(!empty($rr_image)) : ?>
                        <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="latest-about2__media-img2">
                        <?php if(!empty($rr_image_2)) : ?>
                        <img src="<?php echo esc_url($rr_image_2); ?>" alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-3' ): 
     if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_2']['url']) ) {
        $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
        $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
    }
    
    // Link
    if ('2' == $settings['rr_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'fact-4__btn rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'fact-4__btn rr-el-btn');
        }
    }

    $this->add_render_attribute('title_args', 'class', 'fact-4__title wow fadeInLeft animated rr-el-title');
?>
<section class="fact-4__area section-space p-relative overflow-hidden rr-el-section">
    <div class="fact-4__bg p-absolute"></div>
    <div class="container custom-container">
        <?php if ( !empty($settings['rr_about_shape_switch']) ) : ?>
        <div class="fact-4__shape-1 p-absolute">
            <img class="upDown-top"
                src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/fact-4/fact-4__shape.png" alt="">
        </div>
        <div class="fact-4__shape-2 p-absolute">
            <img class="upDown-bottom"
                src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/fact-4/fact-4__shape-2.png" alt="">
        </div>
        <?php endif; ?>
        <div class="fact-4__bg__shape-1 p-absolute"></div>
        <div class="fact-4__bg__shape-2 p-absolute"></div>
        <div class="row align-items-center">
            <div class="col-xl-6">
                <div class="fact-4__content fact-4__content__space text-center text-md-start">
                    <?php if ( !empty($settings['rr_about_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_about_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_about_title' ] )
                        );  
                    endif; ?>
                    <?php if ( !empty($settings['rr_about_description']) ) : ?>
                    <p class="fact-4__dec wow fadeInLeft animated rr-el-desc" data-wow-delay=".2s">
                        <?php echo rr_kses( $settings['rr_about_description'] ); ?></p>
                    <?php endif; ?>
                    <?php if ( !empty($settings['rr_about_skill_switch']) ) : ?>
                    <div class="fact-4__counter wow fadeInLeft animated" data-wow-delay=".3s">
                        <?php foreach($settings['rr_skill_list'] as $key => $item) : ?>
                        <h4 class="fact-4__counter__list rr-rp-title"><span
                                class="count"><?php echo rr_kses($item['rr_skill_num']); ?></span>K+ <span
                                class="text"><?php echo rr_kses($item['rr_skill_box_title']); ?></span></h4>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    <div class="fact-4__btn__wrapper wow fadeInLeft animated" data-wow-delay=".4s">
                        <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_btn_text']); ?>
                            <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="row">
                    <div class="col-xl-6 col-lg-4 col-md-6">
                        <div class="fact-4__thumb__left text-center text-md-start">
                            <div class="fact-4__thumb__1 mb-30">
                                <?php if(!empty($rr_image)) : ?>
                                <img src="<?php echo esc_url($rr_image); ?>"
                                    alt="<?php echo esc_attr($rr_image_alt); ?>">
                                <?php endif; ?>
                            </div>
                            <?php if ( !empty($settings['rr_product_switch']) ) : ?>
                            <div class="fact-4__text">
                                <h3><span class="count"><?php echo rr_kses($settings['rr_product_numb']); ?></span>+
                                    <span class="text"><?php echo rr_kses($settings['rr_product_title']); ?></span></h3>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6">
                        <div class="fact-4__thumb__right mt-70 text-center text-md-start">
                            <?php if ( !empty($settings['rr_explore_product_switch']) ) : ?>
                            <div class="fact-4__btn__wrapper">
                                <a href="<?php echo esc_url($settings['rr_explore_product_url']['url']); ?>" class="fact-4__btn-2"><span>
                                        <svg width="25" height="24" viewBox="0 0 25 24" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M12.4998 24C12.4591 24 12.4179 23.9972 12.3764 23.9914C12.0575 23.9454 11.7942 23.7266 11.7014 23.4296L6.70154 7.4296C6.61363 7.148 6.69383 6.8424 6.9107 6.6342C7.12799 6.426 7.44819 6.3486 7.73923 6.4334L24.4056 11.2334C24.7147 11.3224 24.9427 11.5752 24.9908 11.8814C25.0385 12.188 24.8972 12.4936 24.6287 12.6654L20.4748 15.324L24.7558 19.4342C25.0814 19.7468 25.0814 20.253 24.7558 20.5654L21.4225 23.7654C21.0969 24.078 20.5696 24.078 20.2442 23.7654L15.9628 19.6556L13.1935 23.6434C13.0373 23.8684 12.7756 24 12.4998 24ZM15.833 17.6C16.0532 17.6 16.2651 17.6836 16.4222 17.8344L20.8329 22.0688L22.9877 20L18.5772 15.7656C18.4005 15.596 18.3126 15.3598 18.3372 15.121C18.3615 14.8828 18.4963 14.667 18.7042 14.5342L22.2304 12.2776L8.74317 8.3932L12.7893 21.3412L15.1399 17.956C15.2783 17.7564 15.5028 17.627 15.7512 17.6036C15.7785 17.6012 15.8057 17.6 15.833 17.6ZM4.75574 4.5656C5.08136 4.253 5.08136 3.7468 4.75574 3.4344L3.08911 1.8344C2.76349 1.5218 2.23621 1.5218 1.9108 1.8344C1.58539 2.147 1.58518 2.6532 1.9108 2.9656L3.57743 4.5656C3.74014 4.7218 3.95326 4.8 4.16659 4.8C4.37992 4.8 4.59304 4.7218 4.75574 4.5656ZM4.16659 7.2C4.16659 6.7582 3.79347 6.4 3.33327 6.4H0.833318C0.373118 6.4 0 6.7582 0 7.2C0 7.6418 0.373118 8 0.833318 8H3.33327C3.79347 8 4.16659 7.6418 4.16659 7.2ZM3.08911 12.5656L4.75574 10.9656C5.08136 10.653 5.08136 10.1468 4.75574 9.8344C4.43013 9.522 3.90284 9.5218 3.57743 9.8344L1.9108 11.4344C1.58518 11.747 1.58518 12.2532 1.9108 12.5656C2.0735 12.7218 2.28662 12.8 2.49995 12.8C2.71328 12.8 2.9264 12.7218 3.08911 12.5656ZM11.4223 4.5656L13.0889 2.9656C13.4145 2.653 13.4145 2.1468 13.0889 1.8344C12.7633 1.522 12.236 1.5218 11.9106 1.8344L10.244 3.4344C9.91836 3.747 9.91836 4.2532 10.244 4.5656C10.4067 4.7218 10.6198 4.8 10.8331 4.8C11.0465 4.8 11.2596 4.7218 11.4223 4.5656ZM8.33318 3.2V0.8C8.33318 0.3582 7.96006 0 7.49986 0C7.03966 0 6.66654 0.3582 6.66654 0.8V3.2C6.66654 3.6418 7.03966 4 7.49986 4C7.96006 4 8.33318 3.6418 8.33318 3.2Z"
                                                fill="white" />
                                        </svg>
                                    </span><?php echo rr_kses($settings['rr_explore_product_title']); ?></a>
                            </div>
                            <?php endif; ?>
                            <div class="fact-4__thumb__2">
                                <?php if(!empty($rr_image_2)) : ?>
                                <img src="<?php echo esc_url($rr_image_2); ?>"
                                    alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-4' ): 
     if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_2']['url']) ) {
        $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
        $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_3']['url']) ) {
        $rr_image_3 = !empty($settings['rr_image_3']['id']) ? wp_get_attachment_image_url( $settings['rr_image_3']['id'], $settings['rr_image_size_size']) : $settings['rr_image_3']['url'];
        $rr_image_alt_3 = get_post_meta($settings["rr_image_3"]["id"], "_wp_attachment_image_alt", true);
    }
    // Link
    if ('2' == $settings['rr_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'high-quality-services__btn wow fadeInLeft animated rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'high-quality-services__btn wow fadeInLeft animated rr-el-btn');
        }
    }

    $this->add_render_attribute('title_args', 'class', 'high-quality-services__title pr-30 mb-15 wow fadeInLeft animated rr-el-title');
?>
<section class="high-quality-services__area section-space rr-el-section">
    <div class="container custom-container">
        <div class="row">
            <div class="col-xl-6 col-lg-6">
                <div class="high-quality-services__text services5__text__space mt-10 mb-40">
                    <?php if ( !empty($settings['rr_about_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_about_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_about_title' ] )
                        );  
                    endif; ?>
                    <?php if ( !empty($settings['rr_about_description']) ) : ?>
                    <p class="services-5__text__space pr-120 mb-35 wow fadeInLeft animated rr-el-desc"
                        data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_about_description'] ); ?></p>
                    <?php endif; ?>
                    <div class="high-quality-services__list mb-35 wow fadeInLeft animated" data-wow-delay=".3s">
                        <ul>
                            <?php foreach($settings['rr_about_list_list_1'] as $key => $item) : ?>
                            <li class="rr-rp-title">
                                <span><svg width="22" height="22" viewBox="0 0 22 22" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M21 10.0857V11.0057C20.9988 13.1621 20.3005 15.2604 19.0093 16.9875C17.7182 18.7147 15.9033 19.9782 13.8354 20.5896C11.7674 21.201 9.55726 21.1276 7.53447 20.3803C5.51168 19.633 3.78465 18.2518 2.61096 16.4428C1.43727 14.6338 0.879791 12.4938 1.02168 10.342C1.16356 8.19029 1.99721 6.14205 3.39828 4.5028C4.79935 2.86354 6.69279 1.72111 8.79619 1.24587C10.8996 0.770634 13.1003 0.988061 15.07 1.86572"
                                            stroke="#D04D48" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                        <path d="M21 3.00574L11 13.0157L8 10.0157" stroke="#D04D48" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </span>
                                <?php echo rr_kses($item['rr_about_list_title_1']); ?>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>
                        data-wow-delay=".4s"><?php echo rr_kses($settings['rr_btn_text']); ?></a>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6">
                <div class="high-quality-services__thumb services5__thumb__space p-relative pl-100">
                    <?php if ( !empty($settings['rr_about_shape_switch']) ) : ?>
                    <div class="high-quality-services__shape p-absolute">
                        <img class="upDown"
                            src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/services-5/bg-shape-01.png"
                            alt="img not found">
                    </div>
                    <?php endif; ?>
                    <div class="high-quality-services__thumb-1 br-10 p-absolute">
                        <?php if(!empty($rr_image)) : ?>
                        <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="high-quality-services__thumb-2 br-10 p-absolute">
                        <?php if(!empty($rr_image_2)) : ?>
                        <img src="<?php echo esc_url($rr_image_2); ?>" alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="high-quality-services__thumb-3 br-10 p-absolute">
                        <?php if(!empty($rr_image_3)) : ?>
                        <img src="<?php echo esc_url($rr_image_3); ?>" alt="<?php echo esc_attr($rr_image_alt_3); ?>">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php else:

    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_2']['url']) ) {
        $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
        $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
    }

    // Link
    if ('2' == $settings['rr_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn rr-el-btn');
    } else {
        if ( ! empty( $settings['rr_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', 'rr-btn rr-el-btn');
        }
    }

    $this->add_render_attribute('title_args', 'class', 'title wow fadeInLeft animated rr-el-title');
?>
<!--latest Choose Us start-->
<section class="latest-Choose-us__area section-space overflow-hidden latest-Choose-bg rr-el-section">
    <div class="container p-relative z-index-1">
        <?php if ( !empty($settings['rr_about_shape_switch']) ) : ?>
        <div class="latest-Choose-us__all-shape">
            <div class="latest-Choose-us__bg-shape">
                <img class="upDown-bottom img-fluid"
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/choose-us/bg-shape.svg"
                    alt="img not found">
            </div>
            <div class="latest-Choose-us__bag-shape">
                <img class="zooming img-fluid"
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/choose-us/bag-shape.png"
                    alt="img not found">
            </div>
            <div class="latest-Choose-us__cap-shape">
                <img class="upDown-top img-fluid"
                    src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/choose-us/cap-shape.png"
                    alt="img not found">
            </div>
        </div>
        <?php endif; ?>
        <?php if ( !empty($settings['rr_about_experience_switch']) ) : ?>
        <div class="latest-Choose-us__media-experience-box d-flex rr-el-experience"
            data-parallax='{"y": -160, "smoothness": 15}'>
            <div class="title">
                <?php if ( !empty($settings['rr_extra_about_experience']) ) : ?>
                <h3 class="rr-el-exp"><span
                        class="count"><?php echo rr_kses( $settings['rr_extra_about_experience']);?></span>+</h3>
                <?php endif; ?>
                <?php if ( !empty($settings['rr_extra_about_experience_years']) ) : ?>
                <h4 class="rr-el-exp"><?php echo rr_kses( $settings['rr_extra_about_experience_years']);?></h4>
                <?php endif; ?>
            </div>
            <?php if ( !empty($settings['rr_abouot_experience']) ) : ?>
            <div class="description">
                <p class="rr-el-exp"><?php echo rr_kses( $settings['rr_abouot_experience']);?></p>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-7">
                <div class="latest-Choose-us__content mb-40">
                    <?php if ( !empty($settings['rr_about_sub_title']) ) : ?>
                    <h6 class="subtitle wow fadeInLeft animated rr-el-sub-title" data-wow-delay=".6s">
                        <?php echo rr_kses( $settings['rr_about_sub_title'] ); ?></h6>
                    <?php endif; ?>
                    <?php if ( !empty($settings['rr_about_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_about_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_about_title' ] )
                        );  
                    endif; ?>
                    <?php if ( !empty($settings['rr_about_description']) ) : ?>
                    <p class="wow fadeInLeft animated rr-el-desc" data-wow-delay="1s">
                        <?php echo rr_kses( $settings['rr_about_description'] ); ?></p>
                    <?php endif; ?>
                    <div class="latest-Choose-us__content-text d-flex">
                        <div class="latest-Choose-us__content-text-box wow fadeInLeft animated" data-wow-delay="1.2s">
                            <ul>
                                <?php foreach($settings['rr_about_list_list_1'] as $key => $item) : ?>
                                <li class="rr-rp-title"><i
                                        class="fa-solid fa-circle-check"></i><?php echo rr_kses($item['rr_about_list_title_1']); ?>
                                </li>
                                <?php endforeach; ?>
                            </ul>

                        </div>
                    </div>
                    <div class="latest-Choose-us__content-btn wow fadeInLeft animated" data-wow-delay="1.4s">
                        <a
                            <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_btn_text']); ?></a>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-5">
                <div class="latest-Choose-us__media d-flex flex-row">
                    <div class="latest-Choose-us__media-img1">
                        <?php if(!empty($rr_image)) : ?>
                        <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                    <div class="latest-Choose-us__media-img2">
                        <?php if(!empty($rr_image_2)) : ?>
                        <img src="<?php echo esc_url($rr_image_2); ?>" alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--latest Choose Us end-->

<?php endif; 
	}
}
$widgets_manager->register( new rr_About() );