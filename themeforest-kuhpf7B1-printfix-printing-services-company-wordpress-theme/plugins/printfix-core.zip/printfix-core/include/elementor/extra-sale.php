<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Extra_Sale extends Widget_Base {

	use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'extra_sale';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Extra Sale', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

    protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
		 'rr_list_sec',
			 [
			   'label' => esc_html__( 'Info List', 'rr-core' ),
			   'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			 ]
		);	
		
		$this->add_control(
		'rr_text_list_title',
		  [
			'label'   => esc_html__( 'Title', 'rr-core' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'default'     => esc_html__( 'Extra Sale 30% OFF', 'rr-core' ),
			'label_block' => true,
		  ]
		);
		$this->add_control(
            'rr_text_list_desc',
              [
                'label'   => esc_html__( 'Description', 'rr-core' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'default'     => esc_html__( 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature.', 'rr-core' ),
                'label_block' => true,
              ]
            );	
            
		$this->end_controls_section();

        // _rr_image
		$this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_image_2',
            [
                'label' => esc_html__( 'Choose Image 2', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],

            ]
        );      
        
        $this->add_control(
            'rr_image_3',
            [
                'label' => esc_html__( 'Choose Image 3', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );        
        
        $this->add_control(
            'rr_image_4',
            [
                'label' => esc_html__( 'Choose Image 4', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();

        // rr_btn_button_group
        $this->start_controls_section(
            'rr_btn_button_group',
            [
                'label' => esc_html__('Button', 'rr-core'),
            ]
        );
        $this->add_control(
			'rr_button_switcher',
			[
				'label' => esc_html__( 'Button switcher', 'rr-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'rr-core   ' ),
				'label_off' => esc_html__( 'No', 'rr-core   ' ),
				'return_value' => 'yes',
				'default' => '0',
                'separator' => 'before',
              
			]
		);
        $this->add_control(
            'rr_btn_text',
            [
                'label' => esc_html__('Button Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'rr-core'),
                'title' => esc_html__('Enter button text', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_btn_link',
            [
                'label' => esc_html__('Button link', 'rr-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htRRs://your-link.com', 'rr-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],

                'label_block' => true,
            ]
        );
        $this->add_control(
			'rr_video_switcher',
			[
				'label' => esc_html__( 'Video switcher', 'rr-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'rr-core   ' ),
				'label_off' => esc_html__( 'No', 'rr-core   ' ),
				'return_value' => 'yes',
				'default' => '0',
                'separator' => 'before',
              
			]
		);
        $this->add_control(
            'rr_video_url',
            [
                'label' => esc_html__('Video URL', 'rr-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => 'https://www.youtube.com/watch?v=ceFpltI4HfQ',
                'label_block' => true,
                'description' => __("We recommended to put video url form video website such as 'youtube', 'vimeo'.", 'rr-core')
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
			'section_countdown',
			[
				'label' => esc_html__( 'Countdown', 'rr-core' ),
			]
		);
		$this->add_control(
			'due_date',
			[
				'label' => esc_html__( 'Due Date', 'rr-core' ),
				'type' => \Elementor\Controls_Manager::DATE_TIME,
			]
		);
		$this->end_controls_section();
		
    }

    protected function style_tab_content(){
		$this->rr_section_style_controls('blog_section', 'Section - Style', '.rr-el-section');
		$this->rr_basic_style_controls('history_sub_title', 'Sub Title', '.rr-el-box-sub-title');
		$this->rr_basic_style_controls('history_title', 'Title', '.rr-el-box-title');
		$this->rr_basic_style_controls('history_desc', 'Description', '.rr-el-desc');
        $this->rr_link_controls_style('main_button', 'Button Style', '.rr-el-btn');
        $this->rr_link_controls_style('main_video', 'Video Style', '.rr-el-video');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
<?php if ( $settings['rr_design_style']  == 'layout-2' ): ?>

<?php else: 
	
	if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_2']['url']) ) {
        $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
        $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
    }     
	
	if ( !empty($settings['rr_image_3']['url']) ) {
        $rr_image_3 = !empty($settings['rr_image_3']['id']) ? wp_get_attachment_image_url( $settings['rr_image_3']['id'], $settings['rr_image_size_size']) : $settings['rr_image_3']['url'];
        $rr_image_alt_3 = get_post_meta($settings["rr_image_3"]["id"], "_wp_attachment_image_alt", true);
    } 	
    
    if ( !empty($settings['rr_image_4']['url']) ) {
        $rr_image_4 = !empty($settings['rr_image_4']['id']) ? wp_get_attachment_image_url( $settings['rr_image_4']['id'], $settings['rr_image_size_size']) : $settings['rr_image_4']['url'];
        $rr_image_alt_4 = get_post_meta($settings["rr_image_4"]["id"], "_wp_attachment_image_alt", true);
    }    
    	
?>
<!-- counter-5__area start  -->
<section class="counter-5__area p-relative section-space overflow-hidden rr-el-section">
    <div class="counter-5__bg p-absolute"></div>
    <div class="container custom-container">
        <div class="counter-5__bg__shape-1 p-absolute"></div>
        <div class="counter-5__bg__shape-2 p-absolute"></div>
        <div class="counter-5__thumb__shape__wrapper-1">
            <div class="counter-5__thumb__shape-1 p-absolute d-none d-xl-block">
                <?php if(!empty($rr_image)) : ?>
                <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
                <?php endif; ?>
            </div>
            <div class="contain contain1 p-absolute d-none d-lg-block">
                <div class="path-placeholder">
                    <?php if(!empty($rr_image_3)) : ?>
                    <img src="<?php echo esc_url($rr_image_3); ?>" alt="<?php echo esc_attr($rr_image_alt_3); ?>">
                    <?php endif; ?>
                </div>
                <div class="mover mover1"></div>
            </div>
        </div>
        <div class="counter-5__thumb__shape__wrapper-2">
            <div class="counter-5__thumb__shape-2 p-absolute d-none d-xl-block">
                <?php if(!empty($rr_image_2)) : ?>
                <img src="<?php echo esc_url($rr_image_2); ?>" alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                <?php endif; ?>
            </div>
            <div class="counter-5__thumb__shape-3 p-absolute d-none d-xl-block">
                <?php if(!empty($rr_image_4)) : ?>
                <img src="<?php echo esc_url($rr_image_4); ?>" alt="<?php echo esc_attr($rr_image_alt_4); ?>">
                <?php endif; ?>
            </div>
            <div class="contain contain2 p-absolute d-none d-lg-block">
                <div class="path-placeholder-2"></div>
                <div class="mover mover2"></div>
                <div class="mover mover3"></div>
            </div>
        </div> 
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                <div class="counter-5__item text-center p-relative z-index-11">
                    <?php if ( !empty($settings['rr_text_list_title']) ) : ?>
                    <h3 class="counter-5__item__title wow fadeInLeft animated rr-el-box-title" data-wow-delay=".1s">
                        <?php echo rr_kses($settings['rr_text_list_title']); ?></h3>
                    <?php endif; ?>
                    <?php if ( !empty($settings['rr_text_list_desc']) ) : ?>
                    <p class=" wow fadeInLeft animated rr-el-desc" data-wow-delay=".2s">
                        <?php echo rr_kses($settings['rr_text_list_desc']); ?></p>
                    <?php endif; ?>
                    <div class="counter-5__item__count wow fadeInLeft animated" data-wow-delay=".3s">
                        <div class="counter-5__item__count__button">
                            <div class="best-deal__button-right-small-btn counter-5__item">
                                <div class="getting-started"
                                    data-due-time="<?php printf( esc_html__( '%s:00', 'rr-core' ), $settings['due_date'] ); ?>">
                                    
                                </div>
                            </div> 
                        </div>
                    </div>
                    <div class="counter-5__item__btn mt-50 wow fadeInLeft animated" data-wow-delay=".4s">
                        <?php if ( !empty($settings['rr_button_switcher']) ) : ?>
                        <a class="counter-5__btn__1 rr-el-btn"
                            href="<?php echo esc_url($settings['rr_btn_link']['url']); ?>"><?php echo rr_kses($settings['rr_btn_text']); ?></a>
                        <?php endif; ?>
                        <?php if ( !empty($settings['rr_video_switcher']) ) : ?>
                        <a class="counter-5__btn__2 popup-video zooming rr-el-video"
                            href="<?php echo rr_kses($settings['rr_video_url']); ?>">
                            <svg width="13" height="16" viewBox="0 0 13 16" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M12.5 7.13398C13.1667 7.51888 13.1667 8.48112 12.5 8.86602L2 14.9282C1.33333 15.3131 0.5 14.832 0.5 14.0622V1.93782C0.5 1.16802 1.33333 0.686897 2 1.0718L12.5 7.13398Z"
                                    fill="white" />
                            </svg>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php endif; 
	}
}

$widgets_manager->register( new Extra_Sale() ); 