<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Repeater;
use \Elementor\Control_Media;
use \Elementor\Utils;
Use \Elementor\Core\Schemes\Typography;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Image_Size;


if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Pricing extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-pricing';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Pricing', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {

       

        $this->start_controls_section(
            '_content_title',
            [
                'label' => __('Title & Content', 'rr-core'),
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__('Subtitle', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Pricing Action', 'rr-core'),
                'dynamic' => [
                    'currency' => true
                ]
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Charting Pathways to Profitability', 'rr-core'),
                'dynamic' => [
                    'currency' => true
                ]
            ]
        );

        $this->add_control(
            'monthly_tab',
            [
                'label' => esc_html__('Monthly', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Monthly', 'rr-core'),
                'dynamic' => [
                    'currency' => true
                ]
            ]
        );

        $this->add_control(
            'yearly_tab',
            [
                'label' => esc_html__('Yearly', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Yearly', 'rr-core'),
                'dynamic' => [
                    'currency' => true
                ]
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            '_content_pricing_list',
            [
                'label' => __('Pricing List', 'rr-core'),
            ]
        );


        $repeater = new Repeater();

        $repeater->add_control(
            'active_price',
            [
                'label' => __('Active Price', 'rr-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'rr-core'),
                'label_off' => __('Hide', 'rr-core'),
                'return_value' => 'yes',
                'default' => false,
                'style_transfer' => true,
            ]
        );


        $repeater->add_control(
            'package_name',
            [
                'label' => esc_html__('Package Name', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Basic Plan', 'rr-core'),
                'dynamic' => [
                    'currency' => true
                ]
            ]
        );
        $repeater->add_control(
            'package_content',
            [
                'label' => esc_html__('Content', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Automation plus enterprise-grade features.', 'rr-core'),
                'label_block' => false,
            ]
        );

        $repeater->add_control(
            'currency',
            [
                'label' => __('currency', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'label_block' => false,
                'options' => [
                    '' => __('None', 'rr-core'),
                    'baht' => '&#3647; ' . _x('Baht', 'currency Symbol', 'rr-core'),
                    'bdt' => '&#2547; ' . _x('BD Taka', 'currency Symbol', 'rr-core'),
                    'dollar' => '&#36; ' . _x('Dollar', 'currency Symbol', 'rr-core'),
                    'euro' => '&#128; ' . _x('Euro', 'currency Symbol', 'rr-core'),
                    'franc' => '&#8355; ' . _x('Franc', 'currency Symbol', 'rr-core'),
                    'guilder' => '&fnof; ' . _x('Guilder', 'currency Symbol', 'rr-core'),
                    'krona' => 'kr ' . _x('Krona', 'currency Symbol', 'rr-core'),
                    'lira' => '&#8356; ' . _x('Lira', 'currency Symbol', 'rr-core'),
                    'peseta' => '&#8359 ' . _x('Peseta', 'currency Symbol', 'rr-core'),
                    'peso' => '&#8369; ' . _x('Peso', 'currency Symbol', 'rr-core'),
                    'pound' => '&#163; ' . _x('Pound Sterling', 'currency Symbol', 'rr-core'),
                    'real' => 'R$ ' . _x('Real', 'currency Symbol', 'rr-core'),
                    'ruble' => '&#8381; ' . _x('Ruble', 'currency Symbol', 'rr-core'),
                    'rupee' => '&#8360; ' . _x('Rupee', 'currency Symbol', 'rr-core'),
                    'indian_rupee' => '&#8377; ' . _x('Rupee (Indian)', 'currency Symbol', 'rr-core'),
                    'shekel' => '&#8362; ' . _x('Shekel', 'currency Symbol', 'rr-core'),
                    'won' => '&#8361; ' . _x('Won', 'currency Symbol', 'rr-core'),
                    'yen' => '&#165; ' . _x('Yen/Yuan', 'currency Symbol', 'rr-core'),
                    'custom' => __('Custom', 'rr-core'),
                ],
                'default' => 'dollar',
            ]
        );

        $repeater->add_control(
            'currency_custom',
            [
                'label' => __('Custom Symbol', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'condition' => [
                    'currency' => 'custom',
                ],
                'dynamic' => [
                    'currency' => true,
                ]
            ]
        );
        $repeater->add_control(
            'active_price_top',
            [
                'label' => __('Most Popular', 'rr-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'rr-core'),
                'label_off' => __('Hide', 'rr-core'),
                'return_value' => 'yes',
                'default' => false,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'price_most_popular',
            [
                'label' => esc_html__('Most Popular', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Most Popular', 'rr-core'),
            ]
        );
        $repeater->start_controls_tabs( '_tabs_price' );
        
        $repeater->start_controls_tab(
            'price_monthly_tab',
            [
                'label' => esc_html__( 'Monthly', 'rr-core' ),
            ]
        );
        
        $repeater->add_control(
            'price_monthly',
            [
                'label' => esc_html__('Price', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '19',
                'dynamic' => [
                    'currency' => true
                ]
            ]
        );
        
        $repeater->add_control(
            'price_period_monthly',
            [
                'label' => esc_html__('Period', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('/mo', 'rr-core'),
                'dynamic' => [
                    'currency' => true
                ]
            ]
        );
        
        $repeater->end_controls_tab();
        
        $repeater->start_controls_tab(
            'price_yearly_tab',
            [
                'label' => esc_html__( 'Yearly', 'rr-core' ),
            ]
        );
        
        $repeater->add_control(
            'price_yearly',
            [
                'label' => esc_html__('Price', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '50',
                'dynamic' => [
                    'currency' => true
                ]
            ]
        );

        $repeater->add_control(
            'price_period_yearly',
            [
                'label' => esc_html__('Period', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('/ye', 'rr-core'),
                'dynamic' => [
                    'currency' => true
                ]
            ]
        );
        
        $repeater->end_controls_tab();
        
        $repeater->end_controls_tabs();

        $repeater->add_control(
            'template',
            [
                'label' => __('Section Template', 'rr-core'),
                'placeholder' => __('Select a section template for as tab content', 'rr-core'),
  
                'type' => Controls_Manager::SELECT2,
                'options' => get_elementor_templates()
            ]
        );

        $repeater->add_control(
            'rr_btn_text',
            [
                'label' => esc_html__('Button Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Get Started', 'rr-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'rr_btn_link',
            [
                'label' => esc_html__('Button link', 'rr-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'currency' => true,
                ],
                'placeholder' => esc_html__('https://your-link.com', 'rr-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'pricing_list',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'show_label' => false,
                'default' => [
                    [
                        'package_name' => __('Basic Plan', 'rr-core'),
                        'price_monthly' => '19',
                        'price_yearly' => '50',
                    ],
                    [
                        'package_name' => __('Hard Plan', 'rr-core'),
                        'price_monthly' => '30',
                        'price_yearly' => '80',
                    ],
                    [
                        'package_name' => __('Easy Plan', 'rr-core'),
                        'price_monthly' => '50',
                        'price_yearly' => '100',
                    ],
                ],
                'title_field' => '<# print((package_name)); #>',
            ]
        );

        $this->end_controls_section();
        $this->style_tab_content();
        // title/content
        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',$control_condition = ['layout-1','layout-2','layout-3','layout-4']);
	}

    private static function get_currency_symbol($symbol_name)
    {
        $symbols = [
            'baht' => '&#3647;',
            'bdt' => '&#2547;',
            'dollar' => '&#36;',
            'euro' => '&#128;',
            'franc' => '&#8355;',
            'guilder' => '&fnof;',
            'indian_rupee' => '&#8377;',
            'pound' => '&#163;',
            'peso' => '&#8369;',
            'peseta' => '&#8359',
            'lira' => '&#8356;',
            'ruble' => '&#8381;',
            'shekel' => '&#8362;',
            'rupee' => '&#8360;',
            'real' => 'R$',
            'krona' => 'kr',
            'won' => '&#8361;',
            'yen' => '&#165;',
        ];

        return isset($symbols[$symbol_name]) ? $symbols[$symbol_name] : '';
    }

    // style_tab_content
    protected function style_tab_content(){

        $this->rr_section_style_controls('section_section', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('section_subtitle', 'Section - Subtitle', '.rr-el-subtitle');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('pricing_box_title', 'Pricing - Title', '.rr-el-box-title');
        $this->rr_basic_style_controls('pricing_box_desc', 'Pricing - Description', '.rr-el-box-desc');
        $this->rr_basic_style_controls('pricing_box_ammunt', 'Pricing - Ammunt', '.rr-el-box-ammut');
        $this->rr_link_controls_style('repiter_btn_tab', 'Pricing - Tab', '.rr-el-tab');
        $this->rr_link_controls_style('repiter_btn', 'Pricing - Button', '.rr-el-btn');
        }
    
	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

<section class="pricing__area section-space-bottom-2 rr-el-section">
    <div class="container">
        <div class="pricing__pricing-top">
            <div class="pricing__title-wrapper mb-70">
                <h6 class="pricing__title-wrapper-subtitle rr-el-subtitle">
                    <?php print esc_html($settings['subtitle']); ?></h6>
                <h2 class="pricing__title-wrapper-title rr-el-title"><?php print esc_html($settings['title']); ?></h2>
            </div>
            <div class="pricing__toggler_button mt-md-30 mt-sm-25 mt-xs-20 wow  fadeIn animated" data-wow-delay=".3s">
                <button id="monthly-btn"
                    class="rr-btn btn-transparent currency rr-el-tab active"><?php print esc_html($settings['monthly_tab']); ?></button>
                <button id="yearly-btn"
                    class="rr-btn btn-transparent rr-el-tab"><?php print esc_html($settings['yearly_tab']); ?></button>
            </div>
        </div>

        <div class="row mb-minus-40 pb-30 border-gray">
            <?php foreach ($settings['pricing_list'] as $item) : 

            if ($item['currency'] === 'custom') {
                $currency = $item['currency_custom'];
            } else {
                $currency = self::get_currency_symbol($item['currency']);
            }
            $active_price = $item['active_price'] ? 'active' : '';         
            ?>
            <div class="col-xl-3 col-md-6 wow fadeIn animated p-0" data-wow-delay="1.2s">
                <div class="pricing-card <?php echo esc_attr($active_price); ?> mb-40 pricing-card-popular"
                    data-bg-color="#fff">
                    <?php if ( !empty( $item['active_price_top'] )) : ?>
                    <div class="popular-price">
                        <span class="popular-top-title"><?php echo rr_kses( $item['price_most_popular']);?></span>
                    </div>
                    <div class="top-color"></div>
                    <?php endif; ?>
                    <div class="pricing-card-inner">
                        <div class="pricing-card-price pt-40 mb-20 color-theme-primary price-bg">
                            <h2 class="mb-0 rr-el-box-ammut"
                                data-yearly="<?php echo esc_attr($currency); ?><span><?php echo esc_attr($item['price_yearly']); ?></span> <span><?php echo esc_attr($item['price_period_yearly']); ?></span>"
                                data-monthly="<?php echo esc_attr($currency); ?><span><?php echo esc_attr($item['price_monthly']); ?></span> <span><?php echo esc_attr($item['price_period_monthly']); ?></span>">
                                <?php echo esc_html($currency); ?><span><?php echo esc_html($item['price_monthly']); ?></span>
                                <span><?php echo esc_html($item['price_period_monthly']); ?></span>
                            </h2>
                        </div>
                        <?php if ( !empty( $item['package_name'] )) : ?>
                        <h3 class="pricing-card-title rr-el-box-title"><?php echo rr_kses($item['package_name']); ?>
                        </h3>
                        <?php endif; ?>
                        <?php if ( !empty( $item['package_content'] )) : ?>
                        <p class="rr-el-box-desc"><?php echo rr_kses($item['package_content']);?></p>
                        <?php endif; ?>
                        <div class="pricing-card-body mb-40">
                            <?php echo \Elementor\Plugin::instance()->frontend->get_builder_content($item['template'], true); ?>
                        </div>
                    </div>
                    <?php if ( !empty( $item['rr_btn_text'] )) : ?>
                    <div class="pricing-btn">
                        <a href="<?php echo esc_url($item['rr_btn_link']['url']);?>" class="rr-btn btn-transparent pricing-card-button d-flex rr-el-btn"><?php echo rr_kses($item['rr_btn_text']); ?></a>
                    </div>
                    <?php endif; ?>
                </div>
            </div> 
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php
	}

}

$widgets_manager->register( new rr_Pricing() );