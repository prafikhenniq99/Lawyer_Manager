<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_CTA extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-cta';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'CTA', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

    /**
     * contact form 7 setup.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

    public function get_rr_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $rr_cfa         = array();
        $rr_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $rr_forms       = get_posts( $rr_cf_args );
        $rr_cfa         = ['0' => esc_html__( 'Select Form', 'rr-core' ) ];
        if( $rr_forms ){
            foreach ( $rr_forms as $rr_form ){
                $rr_cfa[$rr_form->ID] = $rr_form->post_title;
            }
        }else{
            $rr_cfa[ esc_html__( 'No contact form found', 'rr-core' ) ] = 0;
        }
        return $rr_cfa;
    }

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */


	protected function register_controls(){
		$this->register_controls_section();
		$this->style_tab_content();
	}		


	// controls file 
	protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );

        $this->add_control(
            'rr_shap_show',
            [
                'label' => esc_html__( 'Show Shape', 'rr-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'rr-core' ),
                'label_off' => esc_html__( 'Hide', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control( 
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();
          // rr_section_title
          $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1','layout-2','layout-3', 'layout-4']);

          $this->start_controls_section(
            'rr-core_contact',
            [
                'label' => esc_html__('Contact Form', 'rr-core'),
                'condition' => [
                    'rr_design_style' => 'layout-1'
                ]

            ]
        );

        $this->add_control(
            'rr-core_select_contact_form',
            [
                'label'   => esc_html__( 'Select Form', 'rr-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '0',
                'options' => $this->get_rr_contact_form(),
            ]
        );

        $this->end_controls_section();
      // rr_btn_button_group
      $this->start_controls_section(
        'rr_btn_button_group',
        [
            'label' => esc_html__('Button', 'rr-core'),
            'condition' => [
                'rr_design_style' => ['layout-2', 'layout-3', 'layout-4']
            ]
        ]
    );
    $this->add_control(
        'rr_btn_text',
        [
            'label' => esc_html__('Button Number Text', 'rr-core'),
            'type' => Controls_Manager::TEXT, 
            'default' => esc_html__('+978 645 241', 'rr-core'),
            'title' => esc_html__('Enter button Number text', 'rr-core'),
            'label_block' => true,
        ]
    );
    $this->add_control(
        'rr_number_url',
        [
            'label' => esc_html__('Button Number link', 'rr-core'),
            'type' => Controls_Manager::URL,
            'dynamic' => [
                'active' => true,
            ],
            'placeholder' => esc_html__('01254555444', 'rr-core'),
            'show_external' => false,
            'default' => [
                'url' => '01245545521225',
                'is_external' => true,
                'nofollow' => true,
                'custom_attributes' => '',
            ],
            'label_block' => true,
        ]
    );
    $this->add_control(
        'rr_btn_button_show',
        [
            'label' => esc_html__( 'Show Button', 'rr-core' ),
            'type' => Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'Show', 'rr-core' ),
            'label_off' => esc_html__( 'Hide', 'rr-core' ),
            'return_value' => 'yes',
            'default' => 'yes',
        ]
    );
    $this->add_control(
        'rr_btn_text_2',
        [
            'label' => esc_html__('Button Text', 'rr-core'),
            'type' => Controls_Manager::TEXT, 
            'default' => esc_html__('Request A Quote', 'rr-core'),
            'title' => esc_html__('Enter button Number text', 'rr-core'),
            'label_block' => true,
        ]
    );


    $this->add_control(
        'rr_btn_link_type',
        [
            'label' => esc_html__('Button Link Type', 'rr-core'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                '1' => 'Custom Link',
                '2' => 'Internal Page',
            ],
            'default' => '1',
            'label_block' => true,
            'condition' => [
                'rr_btn_button_show' => 'yes'
            ],
        ]
    );

    $this->add_control(
        'rr_btn_link',
        [
            'label' => esc_html__('Button link', 'rr-core'),
            'type' => Controls_Manager::URL,
            'dynamic' => [
                'active' => true,
            ],
            'placeholder' => esc_html__('htRRs://your-link.com', 'rr-core'),
            'show_external' => false,
            'default' => [
                'url' => '#',
                'is_external' => true,
                'nofollow' => true,
                'custom_attributes' => '',
            ],
            'condition' => [
                'rr_btn_link_type' => '1',
                'rr_btn_button_show' => 'yes'
            ],
            'label_block' => true,
        ]
    );
    $this->add_control(
        'rr_btn_page_link',
        [
            'label' => esc_html__('Select Button Page', 'rr-core'),
            'type' => Controls_Manager::SELECT2,
            'label_block' => true,
            'options' => rr_get_all_pages(),
            'condition' => [
                'rr_btn_link_type' => '2',
                'rr_btn_button_show' => 'yes'
            ]
        ]
    );

    $this->add_responsive_control(
        'rr_align',
        [
            'label' => esc_html__('Alignment', 'rr-core'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => esc_html__('Left', 'rr-core'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => esc_html__('Center', 'rr-core'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => esc_html__('Right', 'rr-core'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'default' => 'left',
            'toggle' => false,
            'selectors' => [
                '{{WRAPPER}}' => 'text-align: {{VALUE}};'
            ]
        ]
    );
    
    $this->end_controls_section();
      // _rr_image
		$this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_image_2',
            [
                'label' => esc_html__( 'Choose Image 2', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],

            ]
        );      
        
        $this->add_control(
            'rr_image_3',
            [
                'label' => esc_html__( 'Choose Image 3', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();
   
	}

	// style_tab_content
	protected function style_tab_content(){
        $this->rr_section_style_controls('cta_section', 'Section Style', '.ele-section'); 
        $this->rr_basic_style_controls('cta_title', 'Cta Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('cta_content', 'Cta Content', '.rr-el-content');
        $this->rr_link_controls_style('repiter_btn', 'Cta - Button', '.rr-el-btn');
        $this->rr_link_controls_style('repiter_btn_2', 'Cta - Number Button', '.rr-el-btn_2');
	}


/**
 * Render the widget ouRRut on the frontend.
 *
 * Written in PHP and used to generate the final HTML.
 *
 * @since 1.0.0
 *
 * @access protected
 */
protected function render() {
    $settings = $this->get_settings_for_display();

    ?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ):
    // Link
    if ('2' == $settings['rr_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', "rr-btn mt-40 rr-el-btn");
    } else {
        if ( ! empty( $settings['rr_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', "rr-btn mt-40 rr-el-btn");

        }
    }
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_2']['url']) ) {
        $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
        $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
    }
    $this->add_render_attribute('title_args', 'class', 'happy-customer__content-wrapper-title rr-el-re-Title');
?>
<!-- happy-customer start-->
<section
    class="happy-customer__are section-space-top overflow-hidden pb-70-custom happy-customer-bg position-relative ele-section">
    <div class="container-fluid overflow-hidden">
        <div class="happy-customer__shape-wrapper overflow-hidden">
            <?php if( !empty($settings['rr_shap_show'])) : ?>
            <div class="happy-customer__shape-wrapper-bottom-shape">
                <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/callaction/cta-banneshape.png"
                    alt="img not found ">
            </div>
            <?php endif; ?>
            <div class="happy-customer__shape-wrapper-left-shape">
                <?php if(!empty($rr_image)) : ?>
                <img class="upDown-bottom" src="<?php echo esc_url($rr_image); ?>"
                    alt="<?php echo esc_attr($rr_image_alt); ?>">
                <?php endif; ?>
            </div>
            <div class="happy-customer__shape-wrapper-right-shape">
                <?php if(!empty($rr_image_2)) : ?>
                <img class="upDown-top" src="<?php echo esc_url($rr_image_2); ?>"
                    alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="happy-customer__content-wrapper position-relative text-center mb-45">
                    <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h6 class="happy-customer__content-wrapper-subtitle">
                        <?php echo rr_kses( $settings['rr_section_sub_title'] ); ?></h6>
                    <?php endif; ?>
                    <?php if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s data-wow-duration=".9s"
                        data-wow-delay=".5s" >%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        ); endif;  ?>
                    <?php if ( !empty($settings['rr_section_description']) ) : ?>
                    <p class="happy-customer__content-wrapper-description rr-el-content">
                        <?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
                    <?php endif; ?>
                    <a
                        <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_btn_text_2']); ?></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- happy-customer end-->
<?php elseif ( $settings['rr_design_style']  == 'layout-3' ):
    // Link
    if ('2' == $settings['rr_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', "rr-btn btn-white active rr-el-btn");
    } else {
        if ( ! empty( $settings['rr_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', "rr-btn btn-white active rr-el-btn");

        }
    }
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    $this->add_render_attribute('title_args', 'class', 'latest-cta2__content-title rr-el-re-Title');
?>
<!-- latest-cta2__area start -->
<div class="latest-cta2__area section-space p-relative overflow-hidden ele-section"
    data-background="<?php echo esc_url($rr_image); ?>">
    <div class="container overflow-hidden position-relative z-index-1">
        <div class="row">
            <div class="col-xl-12">
                <div class="latest-cta2__content text-center">
                    <?php if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s data-wow-duration=".9s"
                        data-wow-delay=".5s" >%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        ); endif;  ?>
                    <?php if ( !empty($settings['rr_section_description']) ) : ?>
                    <p class="latest-cta2__content-description mb-40 text-white opacity rr-el-content">
                        <?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
                    <?php endif; ?>
                    <div class="latest-cta2__content-btn">
                        <a href="tel:<?php echo rr_kses($settings['rr_btn_text']); ?>"
                            class="rr-btn btn-white btn-1 rr-el-btn_2"><img
                                src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/cta/home-2/call.png"
                                alt="img not found"> <?php echo rr_kses($settings['rr_btn_text']); ?></a>
                        <a
                            <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?>><?php echo rr_kses($settings['rr_btn_text_2']); ?></a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- latest-cta2__area end -->
<?php elseif ( $settings['rr_design_style']  == 'layout-4' ):
    // Link
    if ('2' == $settings['rr_btn_link_type']) {
        $this->add_render_attribute('rr-button-arg', 'href', get_permalink($settings['rr_btn_page_link']));
        $this->add_render_attribute('rr-button-arg', 'target', '_self');
        $this->add_render_attribute('rr-button-arg', 'rel', 'nofollow');
        $this->add_render_attribute('rr-button-arg', 'class', "cta-5__btn wow fadeInLeft animated rr-el-btn");
    } else {
        if ( ! empty( $settings['rr_btn_link']['url'] ) ) {
            $this->add_link_attributes( 'rr-button-arg', $settings['rr_btn_link'] );
            $this->add_render_attribute('rr-button-arg', 'class', "cta-5__btn wow fadeInLeft animated rr-el-btn");

        }
    }
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_2']['url']) ) {
        $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
        $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_3']['url']) ) {
        $rr_image_3 = !empty($settings['rr_image_3']['id']) ? wp_get_attachment_image_url( $settings['rr_image_3']['id'], $settings['rr_image_size_size']) : $settings['rr_image_3']['url'];
        $rr_image_alt_3 = get_post_meta($settings["rr_image_3"]["id"], "_wp_attachment_image_alt", true);
    }
    $this->add_render_attribute('title_args', 'class', 'cta-5__title mb-45 wow fadeInLeft animated rr-el-re-Title');
?>
<!-- cta-5__area start  -->
<section class="cta-5__area section-space position-relative overflow-hidden ele-section"
    data-background="<?php echo esc_url($rr_image); ?>">
    <div class="container-fluid">
        <div class="cta-5__shape-1 position-absolute d-none d-xl-block">
            <?php if(!empty($rr_image_2)) : ?>
            <img class="upDown" src="<?php echo esc_url($rr_image_2); ?>"
                alt="<?php echo esc_attr($rr_image_alt_2); ?>">
            <?php endif; ?>
        </div>
        <div class="cta-5__shape-2 position-absolute d-none d-xl-block">
            <?php if(!empty($rr_image_3)) : ?>
            <img class="upDown-top" src="<?php echo esc_url($rr_image_3); ?>"
                alt="<?php echo esc_attr($rr_image_alt_3); ?>">
            <?php endif; ?>
        </div>
        <div class="cta-5__text text-center p-relative z-index-11">
            <?php if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s data-wow-duration=".9s"
                        data-wow-delay=".5s" >%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        ); 
            endif;  ?>
            <a <?php echo $this->get_render_attribute_string( 'rr-button-arg' ); ?> data-wow-delay=".2s"><?php echo rr_kses($settings['rr_btn_text_2']); ?></a>
        </div>
    </div>
</section>
<?php else: 
    if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_2']['url']) ) {
        $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
        $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
    }
    $this->add_render_attribute('title_args', 'class', 'title wow fadeInLeft animated rr-el-re-Title');   
?>
<!-- latest-newsletter area start -->
<section class="latest-newsletter__area pt-80 pb-80 overflow-hidden latest-newsletter-bg ele-section">
    <div class="container p-relative">
        <?php if( !empty($settings['rr_shap_show'])) : ?>
        <div class="latest-newsletter__all-shape">
            <div class="latest-newsletter__pen-shape">
                <?php if(!empty($rr_image_2)) : ?>
                <img class="zooming" src="<?php echo esc_url($rr_image_2); ?>"
                    alt="<?php echo esc_attr($rr_image_alt_2); ?>">
                <?php endif; ?>
            </div>
            <div class="latest-newsletter__bg-shape">
                <?php if(!empty($rr_image)) : ?>
                <img class="upDown" src="<?php echo esc_url($rr_image); ?>"
                    alt="<?php echo esc_attr($rr_image_alt); ?>">
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-xl-12">
                <div class="latest-newsletter__content text-center">
                    <?php if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s data-wow-duration=".9s"
                        data-wow-delay=".5s" >%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        ); endif;  ?>
                    <?php if ( !empty($settings['rr_section_description']) ) : ?>
                    <p class="rr-el-content"><?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
                    <?php endif; ?>

                    <?php if( !empty($settings['rr-core_select_contact_form']) ) : ?>
                    <?php echo do_shortcode( '[contact-form-7  id="'.$settings['rr-core_select_contact_form'].'"]' ); ?>
                    <?php else : ?>
                    <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'rr-core' ). '</p></div>'; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- latest-newsletter area end -->

<?php endif; 
	}
}

$widgets_manager->register( new rr_CTA() );