<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class RR_Product_Tab extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

    public function get_name() {
        return 'rr_product_tab';
    }

    public function get_title() {
        return __( 'Product Tab', 'rr-core' );
    }

    public function get_icon() {
        return 'rr-icon';
    } 

    public function get_categories() {
        return [ 'rr-core' ];
    }

    public function get_script_depends() {
        return [ 'rr-core' ];
    }

    protected function register_controls() {
        $this->register_controls_section();
        $this->style_tab_content();
    }

    protected function register_controls_section() {
        // Layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );

        $this->add_control(
            'rr_design_style',
            [
                'label'   => esc_html__('Select Layout', 'rr-core'),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // Section Title
        $this->start_controls_section(
            'rr_project_section_title',
            [
                'label' => esc_html__('Section Title', 'rr-core'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'rr_project_section_switch',
            [
                'label'        => esc_html__('Call On/Off', 'rr-core'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'rr-core'),
                'label_off'    => esc_html__('Hide', 'rr-core'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->add_control(
            'rr_project_sub_title',
            [
                'label'       => esc_html__('Project Sub Title', 'rr-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('BEST SELLING DISHES', 'rr-core'),
            ]
        );

        $this->add_control(
            'rr_project_title',
            [
                'label'       => esc_html__('Project Title', 'rr-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('Discover Our Menu', 'rr-core'),
            ]
        );       

        $this->add_control(
            'rr_project_url',
            [
                'label' => esc_html__( 'Project Url', 'text-domain' ),
                'type' => Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        // Query Controls
        $this->rr_query_controls_wooc('product', 'Product', '6', '10', 'product', 'product_cat', ['layout-1', 'layout-2']);

        // Shape Section
        $this->start_controls_section(
            '_rr_project_shape',
            [
                'label' => esc_html__('Shape', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-3']
                ]
            ]
        );

        $this->add_control(
            'rr_project_shape_switch',
            [
                'label'        => esc_html__('Shape On/Off', 'rr-core'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__('Show', 'rr-core'),
                'label_off'    => esc_html__('Hide', 'rr-core'),
                'return_value' => 'yes',
                'default'      => 'yes',
            ]
        );

        $this->end_controls_section();
        
        // rr_btn_button_group
        $this->start_controls_section(
            'rr_btn_button_group',
            [
                'label' => esc_html__('Button', 'rr-core'),
                'condition' => [
                    'rr_design_style' => ['layout-2']
                ]
            ]
        );

        $this->add_control(
            'rr_btn_text',
            [
                'label' => esc_html__('Button Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'rr-core'),
                'title' => esc_html__('Enter button text', 'rr-core'),
                'label_block' => true,
            
            ]
        );

        $this->add_control(
            'rr_btn_link',
            [
                'label' => esc_html__('Button link', 'rr-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htRRs://your-link.com', 'rr-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'label_block' => true,
            ]
        );

        $this->end_controls_section();
    }

    protected function style_tab_content() {
        $this->rr_section_style_controls('services_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('newsletter_sub_title', 'Subtitle Style', '.ele-subtitle');
        $this->rr_basic_style_controls('newsletter_title', 'Heading Style', '.ele-heading');
        $this->rr_link_controls_style('about_btn', 'Product - Button', '.rr-el-btn');
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        // Setup query arguments using helper function
        $query_args = RR_Helper::get_query_args('product', 'product_cat', $settings);

        // The Query
        $query = new \WP_Query($query_args);

        $filter_list = $settings['category'];

        // Ensure $filter_list is an array
        if (is_string($filter_list)) {
            $filter_list = explode(',', $filter_list); // Convert comma-separated string to array
        } elseif (!is_array($filter_list)) { 
            $filter_list = []; // Fallback to an empty array
        }
        
        // Check if the array is not empty
        if (empty($filter_list)) {
            echo '<p>' . esc_html__('No categories found.', 'rr-core') . '</p>';
            return;
        }

        
        ?>
<?php if ( $settings['rr_design_style']  == 'layout-2' ) : 
    $this->add_render_attribute('title_args', 'class', 'rr-team-details-title');  

?>
<!-- trend-product-area-start -->
<div class="rr-trend-product-5__area project-section-4 pb-60 overflow-hidden ele-section">
    <div class="container custom-container">
        <div class="rr-trend-product-5__top-mb">
            <div class="row align-items-center">
                <div class="rr-trend-product-5__btn-wrap">
                    <?php if ( !empty($settings['rr_project_title']) ) : ?>
                    <h4 class="title-5 wow fadeInLeft animated ele-heading" data-wow-delay=".1s">
                        <?php echo esc_html($settings['rr_project_title']); ?></h4>
                    <?php endif; ?>
                    <div class="button-box wow fadeInLeft animated" data-wow-delay=".2s">
                        <nav>
                            <div class="nav nav-tab project-filter text-center wow fade-in-right" data-wow-delay="400ms"
                                id="nav-tab" role="tablist">
                                <?php if (!empty($filter_list) && is_array($filter_list)) {
                                    foreach ($filter_list as $key => $list) {
                                    $active = ($key === 0) ? 'active' : '';
                                ?>
                                <button class="nav-link rr-el-rep-filterBtn <?php echo esc_attr($active); ?>"
                                    id="nav-<?php echo esc_attr($key); ?>-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-<?php echo esc_attr($key); ?>" type="button" role="tab"
                                    aria-controls="nav-<?php echo esc_attr($key); ?>"
                                    aria-selected="true"><?php echo esc_html($list); ?></button>
                                <?php
                                    }
                                    }
                                ?>
                            </div>
                        </nav>
                        <div class="button">
                            <a class="btn rr-el-btn" href="<?php echo rr_kses($settings['rr_btn_link']['url']); ?>"><?php echo rr_kses($settings['rr_btn_text']); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row filter-items">

            <div class="tab-content" id="nav-tabContent">
                <?php foreach ($filter_list as $key => $list): 
                        $active_tab = ($key === 0) ? 'active show' : '';

                        // Query for products in the current category
                        $category_query_args = array_merge($query_args, [
                            'tax_query' => [
                                [
                                    'taxonomy' => 'product_cat',
                                    'field'    => 'slug',
                                    'terms'    => $list, // Use the current tab's category
                                ],
                            ],
                        ]);
                        $category_query = new \WP_Query($category_query_args);
                    ?>
                <div class="tab-pane fade <?php echo esc_attr($active_tab); ?>" id="nav-<?php echo esc_attr($key); ?>"
                    role="tabpanel" aria-labelledby="nav-<?php echo esc_attr($key); ?>-tab" tabindex="0">
                    <div class="rr-fea-product__wrapper">
                        <div class="row">
                            <?php 
                                    if ($category_query->have_posts()):
                                        while ($category_query->have_posts()): $category_query->the_post(); 
                                ?>
                            <div class="col-xl-3 col-lg-4 col-md-6">
                                <div class="rr-trend-product-5__item-box wow fadeInLeft animated" data-wow-delay=".1s">
                                    <div class="rr-trend-product-5__item">
                                        <?php if (has_post_thumbnail()): ?>
                                        <div class="rr-trend-product-5__thumb fix p-relative">
                                            <?php the_post_thumbnail(); ?>
                                        </div>
                                        <?php endif; ?>
                                        <div class="rr-trend-product-5__content">
                                            <ul>
                                                <li>
                                                    <div class="rr-trend-product-5__title-box">
                                                        <h4 class="rr-trend-product-5__title-sm"><a
                                                                href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                                        </h4>
                                                    </div>
                                                </li>
                                                <?php if(!empty(woocommerce_template_loop_price())): ?>
                                                <li>
                                                    <div class="rr-trend-product-5__price">
                                                        <?php echo woocommerce_template_loop_price(); ?>
                                                    </div>
                                                </li>
                                                <?php endif; ?>
                                                <?php if(!empty(woocommerce_template_single_rating())): ?>
                                                <li>
                                                    <div class="rr-trend-product-5__star">
                                                        <?php woocommerce_template_single_rating(); ?>
                                                    </div>
                                                </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="rr-trend-product-5__link-box text-center">
                                        <?php woocommerce_template_loop_add_to_cart();?>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                            <?php else: ?>
                            <p><?php esc_html_e('No products found in this category.', 'rr-core'); ?></p>
                            <?php 
                                    endif; 
                                    wp_reset_postdata(); 
                                ?>
                        </div>
                    </div>
                </div>

                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<?php else:

        $this->add_render_attribute('title_args', 'class', 'teamdetail__progress-wrapper-title pb-30 wow fadeInLeft animated rr-el-title-skill');
    ?>

<!-- prodact-3-area start -->
<section class="prodact-area product-bg ele-section">
    <div class="rr-fea-product__area p-relative fix grey-bg-2 pb-35 pt-115 rr-pro-tab1 rr-el-section">
        <div class="container custom-container-3">
            <div class="row">
                <div class="col-xl-12">
                    <?php if ( !empty($settings['rr_project_section_switch']) ) : ?>
                    <div class="prodact-title-wrapper text-center mb-25 ele-subtitle">
                        <?php if ( !empty($settings['rr_project_sub_title']) ) : ?>
                        <span
                            class="subtitle rr-el-subtitle"><?php echo esc_html($settings['rr_project_sub_title']); ?></span>
                        <?php endif; ?>
                        <?php if ( !empty($settings['rr_project_title']) ) : ?>
                        <h2 class="title ele-heading"><?php echo esc_html($settings['rr_project_title']); ?></h2>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="rr-fea-product__tab mb-25">
                        <nav>
                            <div class="nav nav-tab justify-content-center" id="nav-tab" role="tablist">
                                <?php if (!empty($filter_list) && is_array($filter_list)) {
                                    foreach ($filter_list as $key => $list) {
                                    $active = ($key === 0) ? 'active' : '';
                                ?>
                                <button class="nav-link rr-el-rep-filterBtn <?php echo esc_attr($active); ?>"
                                    id="nav-<?php echo esc_attr($key); ?>-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-<?php echo esc_attr($key); ?>" type="button" role="tab"
                                    aria-controls="nav-<?php echo esc_attr($key); ?>"
                                    aria-selected="true"><?php echo esc_html($list); ?></button>
                                <?php
                                    }
                                    }
                                ?>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="tab-content" id="nav-tabContent">
                    <?php foreach ($filter_list as $key => $list): 
                        $active_tab = ($key === 0) ? 'active show' : '';

                        // Query for products in the current category
                        $category_query_args = array_merge($query_args, [
                            'tax_query' => [
                                [
                                    'taxonomy' => 'product_cat',
                                    'field'    => 'slug',
                                    'terms'    => $list, // Use the current tab's category
                                ],
                            ],
                        ]);
                        $category_query = new \WP_Query($category_query_args);
                    ?>
                    <div class="tab-pane fade <?php echo esc_attr($active_tab); ?>"
                        id="nav-<?php echo esc_attr($key); ?>" role="tabpanel"
                        aria-labelledby="nav-<?php echo esc_attr($key); ?>-tab" tabindex="0">
                        <div class="rr-fea-product__wrapper">
                            <div class="row">
                                <?php 
                                    if ($category_query->have_posts()):
                                        while ($category_query->have_posts()): $category_query->the_post(); 
                                ?>
                                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                                    <div class="rr-fea-product__item rr-pro-img">
                                        <?php if (has_post_thumbnail()): ?>
                                        <div class="rr-fea-product__thumb fix p-relative">
                                            <?php the_post_thumbnail(); ?>
                                            <div class="rr-fea-product__icon-box icon-box-3 rr-product-action">
                                                <div class="product-action-btn mb-6">
                                                    <?php if( function_exists( 'woosc_init' )) : ?>
                                                    <!-- compare button -->
                                                    <?php echo do_shortcode('[woosc]');?>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="product-action-btn mb-6">
                                                    <!-- quick view button -->
                                                    <?php if( class_exists( 'WPCleverWoosq' )) : ?>
                                                    <?php echo do_shortcode('[woosq]'); ?>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="product-action-btn">
                                                    <?php if( function_exists( 'woosw_init' )) : ?>
                                                    <!-- wishlist button -->
                                                    <?php echo do_shortcode('[woosw]'); ?>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <div class="rr-fea-product__content">
                                        <?php if(!empty(woocommerce_template_single_rating())): ?>
                                            <div class="rr-fea-product__star">
                                                <?php woocommerce_template_single_rating(); ?>
                                            </div>
                                        <?php endif; ?>
                                            <h4 class="rr-fea-product__title-sm"><a
                                                    href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                            <?php if(!empty(woocommerce_template_loop_price())): ?>
                                            <div class="rr-product-content-price">
                                                <span class="product-item-3-price">
                                                    <span class="price">
                                                        <span class="woocs_price_code d-flex gap-6">
                                                            <?php echo woocommerce_template_loop_price(); ?>
                                                        </span>
                                                    </span>
                                                </span>
                                            </div>
                                            <?php endif; ?>
                                            <div class="rr-fea-product__link-box">
                                                <?php woocommerce_template_loop_add_to_cart();?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endwhile; ?>
                                <?php else: ?>
                                <p><?php esc_html_e('No products found in this category.', 'rr-core'); ?></p>
                                <?php 
                                    endif; 
                                    wp_reset_postdata(); 
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- prodact-3-area end -->

<?php
endif; 
    }
}

$widgets_manager->register( new RR_Product_Tab() );