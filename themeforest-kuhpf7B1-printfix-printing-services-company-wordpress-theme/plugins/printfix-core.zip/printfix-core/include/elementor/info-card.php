<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Info_Card extends Widget_Base {

	use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-info-card';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Info Card', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}


    public function get_rr_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $rr_cfa         = array();
        $rr_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $rr_forms       = get_posts( $rr_cf_args );
        $rr_cfa         = ['0' => esc_html__( 'Select Form', 'rr-core' ) ];
        if( $rr_forms ){
            foreach ( $rr_forms as $rr_form ){
                $rr_cfa[$rr_form->ID] = $rr_form->post_title;
            }
        }else{
            $rr_cfa[ esc_html__( 'No contact form found', 'rr-core' ) ] = 0;
        }
        return $rr_cfa;
    }

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

    protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );

        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'rr_info_card',
                [
                'label' => esc_html__( 'Info Card', 'rr-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'rr_info_card_sub_title',
            [
                'label' => esc_html__('Sub Title', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'title' => esc_html__('Enter Your Sub Title', 'rr-core'),
                'label_block' => true,
                'default' => 'Wear Your Brand With Pride',
            ]
        );
        $this->add_control(
            'rr_info_card_title',
            [
                'label' => esc_html__('Title', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'title' => esc_html__('Enter Your Title', 'rr-core'),
                'label_block' => true,
                'default' => 'Cloth & Bag Printing',
            ]
        );
        $this->add_control(
            'rr_info_card_desc',
            [
                'label' => esc_html__('Description', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'title' => esc_html__('Enter Your Description', 'rr-core'),
                'label_block' => true,
                'default' => 'Starting',
            ]
        );
        $this->add_control(
            'rr_info_card_ammunt',
            [
                'label' => esc_html__('Info Card Ammout', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'title' => esc_html__('Enter Your Info Card Ammout', 'rr-core'),
                'label_block' => true,
                'default' => '370.00',
            ]
        );
        $this->end_controls_section();
           // rr_btn_button_group
           $this->start_controls_section(
            'rr_btn_button_group',
            [
                'label' => esc_html__('Button', 'rr-core'),
            ]
        );

        $this->add_control(
            'rr_btn_text',
            [
                'label' => esc_html__('Button Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'rr-core'),
                'title' => esc_html__('Enter button text', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_btn_link',
            [
                'label' => esc_html__('Button link', 'rr-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htRRs://your-link.com', 'rr-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'label_block' => true,
            ]
        );      
        
        $this->end_controls_section();
         // _rr_image
		$this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();
           // shape section
           $this->start_controls_section(
            'rr_about_shape',
                [
                'label' => esc_html__( 'Shape', 'rr-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,

            ]
        );
      
        $this->add_control(
            'rr_about_shape_switch',
            [
            'label'        => esc_html__( 'Shape On/Off', 'rr-core' ),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'label_on'     => esc_html__( 'Show', 'rr-core' ),
            'label_off'    => esc_html__( 'Hide', 'rr-core' ),
            'return_value' => 'yes',
            'default'      => '1',
            ]
        );

        $this->end_controls_section();
    }

    protected function style_tab_content(){
        $this->rr_section_style_controls('features_section', 'Section - Style', '.rr-el-section'); 
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('section_desc', 'Section - Description', '.rr-el-desc');
        $this->rr_link_controls_style('repiter_btn', 'Features - Number', '.rr-el-btn');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): 
         if ( !empty($settings['rr_image']['url']) ) {
            $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
            $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
        }
    ?>
<div class="wrap overflow-hidden wow fadeInLeft animated rr-el-section" data-wow-delay=".2s">
    <?php if ( !empty($settings['rr_about_shape_switch']) ) : ?>
    <div class="feature-5-shape-sec position-relative">
        <img class="position-absolute shape-3"
            src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/feature-5/feature5-shape-03.png" alt="">
    </div>
    <?php endif; ?>
    <div class="feature-5-card feature-5-bg overflow-hidden mt-30 position-relative rr-el-section">
        <div class="feature-5-content">

            <?php if ( !empty($settings['rr_info_card_sub_title']) ) : ?>
            <p class="des rr-el-sub-title"><?php echo rr_kses($settings['rr_info_card_sub_title']); ?></p>
            <?php endif; ?>
            <?php if ( !empty($settings['rr_info_card_title']) ) : ?>
            <h3 class="feature-5-title rr-el-title"><?php echo rr_kses($settings['rr_info_card_title']); ?></h3>
            <?php endif; ?>
            <h5 class="feature-5-sub rr-el-desc"><?php echo rr_kses($settings['rr_info_card_desc']); ?> <span>
                    <?php echo rr_kses($settings['rr_info_card_ammunt']); ?></span></h5>
            <?php if ( !empty($settings['rr_btn_text']) ) : ?>
            <a href="<?php echo esc_url($settings['rr_btn_link']['url']); ?>" class="feature-btn mt-15 rr-el-btn"><?php echo rr_kses($settings['rr_btn_text']); ?> <i
                    class="fa-light fa-arrow-right"></i></a>
            <?php endif; ?>
        </div>
        <div class="feature-5-right-img feature-5-right-img-2">
            <?php if(!empty($rr_image)) : ?>
            <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
            <?php endif; ?>
        </div>
    </div>
</div>

<?php else: 
     $this->add_render_attribute('title_args', 'class', 'rr-contact-breadcrumb-title');
     if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
 ?>
<div class="wrap wow fadeInLeft animated " data-wow-delay=".1s">
    <?php if ( !empty($settings['rr_about_shape_switch']) ) : ?>
    <div class="feature-5-shape position-relative">
        <img class="position-absolute shape-1" src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/feature-5/feature5-shape-01.png" alt="">
        <img class="position-absolute shape-2" src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/feature-5/feature5-shape-02.png" alt="">
    </div>
    <?php endif; ?>
    <div class="feature-5-card feature-first-bg overflow-hidden position-relative mt-30 rr-el-section">
        <div class="feature-5-content">
            <?php if ( !empty($settings['rr_info_card_sub_title']) ) : ?>
            <p class="rr-el-sub-title"><?php echo rr_kses($settings['rr_info_card_sub_title']); ?></p>
            <?php endif; ?>
            <?php if ( !empty($settings['rr_info_card_title']) ) : ?>
            <h3 class="rr-el-title"><?php echo rr_kses($settings['rr_info_card_title']); ?></h3>
            <?php endif; ?>
            <h5 class="rr-el-desc"><?php echo rr_kses($settings['rr_info_card_desc']); ?> <span>
                    <?php echo rr_kses($settings['rr_info_card_ammunt']); ?></span></h5>
            <?php if ( !empty($settings['rr_btn_text']) ) : ?>
            <a href="<?php echo esc_url($settings['rr_btn_link']['url']); ?>" class="feature-btn mt-15 rr-el-btn"><?php echo rr_kses($settings['rr_btn_text']); ?> <i
                    class="fa-light fa-arrow-right"></i></a>
            <?php endif; ?>
        </div>
        <div class="feature-5-right-img">
            <?php if(!empty($rr_image)) : ?>
            <img src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>"> 
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; 
	}
}

$widgets_manager->register( new rr_Info_Card() );