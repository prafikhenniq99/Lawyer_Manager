<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Clearance_Sale extends Widget_Base {

	use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'clearance_sale';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Clearance Sale', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

    protected function register_controls_section(){
        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
		 'rr_list_sec',
			 [
			   'label' => esc_html__( 'Info List', 'rr-core' ),
			   'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			 ]
		);
		
		$this->add_control(
		'rr_text_list_sub_title',
		  [
			'label'   => esc_html__( 'Sub Title', 'rr-core' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'default'     => esc_html__( 'Clearance Sale - 2024', 'rr-core' ),
			'label_block' => true,
		  ]
		);		
		
		$this->add_control(
		'rr_text_list_title',
		  [
			'label'   => esc_html__( 'Title', 'rr-core' ),
			'type'        => \Elementor\Controls_Manager::TEXT,
			'default'     => esc_html__( 'Big SeasonSale Up To 40 %', 'rr-core' ),
			'label_block' => true,
		  ]
		);

		$this->end_controls_section();

        // _rr_image
		$this->start_controls_section(
            '_rr_image',
            [
                'label' => esc_html__('Thumbnail', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_image',
            [
                'label' => esc_html__( 'Choose Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'rr_image_2',
            [
                'label' => esc_html__( 'Choose Image 2', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],

            ]
        );      
        
        $this->add_control(
            'rr_image_3',
            [
                'label' => esc_html__( 'Choose Image 3', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_image_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();

        // rr_btn_button_group
        $this->start_controls_section(
            'rr_btn_button_group',
            [
                'label' => esc_html__('Button', 'rr-core'),
            ]
        );

        $this->add_control(
            'rr_btn_text',
            [
                'label' => esc_html__('Button Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Shop Now', 'rr-core'),
                'title' => esc_html__('Enter button text', 'rr-core'),
                'label_block' => true,
        
            ]
        );

        $this->add_control(
            'rr_btn_link',
            [
                'label' => esc_html__('Button link', 'rr-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htRRs://your-link.com', 'rr-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],

                'label_block' => true,
            ]
        );
    
        $this->end_controls_section();
		
    }

    protected function style_tab_content(){
		$this->rr_section_style_controls('blog_section', 'Section - Style', '.rr-el-section');
		$this->rr_basic_style_controls('history_sub_title', 'Sub Title', '.rr-el-box-sub-title');
		$this->rr_basic_style_controls('history_title', 'Title', '.rr-el-box-title');
        $this->rr_link_controls_style('main_button', 'Button Style', '.rr-el-btn');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
<?php if ( $settings['rr_design_style']  == 'layout-2' ): ?>

<?php else: 
	
	if ( !empty($settings['rr_image']['url']) ) {
        $rr_image = !empty($settings['rr_image']['id']) ? wp_get_attachment_image_url( $settings['rr_image']['id'], $settings['rr_image_size_size']) : $settings['rr_image']['url'];
        $rr_image_alt = get_post_meta($settings["rr_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_image_2']['url']) ) {
        $rr_image_2 = !empty($settings['rr_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_image_2']['id'], $settings['rr_image_size_size']) : $settings['rr_image_2']['url'];
        $rr_image_alt_2 = get_post_meta($settings["rr_image_2"]["id"], "_wp_attachment_image_alt", true);
    }     
	
	if ( !empty($settings['rr_image_3']['url']) ) {
        $rr_image_3 = !empty($settings['rr_image_3']['id']) ? wp_get_attachment_image_url( $settings['rr_image_3']['id'], $settings['rr_image_size_size']) : $settings['rr_image_3']['url'];
        $rr_image_alt_3 = get_post_meta($settings["rr_image_3"]["id"], "_wp_attachment_image_alt", true);
    }    
    	
?>
<div class="biscount-product-5__banner banner__space-4 rr-el-section">
    <div class="biscount-product-5__circle__shape p-absolute">
        <?php if(!empty($rr_image_3)) : ?>
        <img src="<?php echo esc_url($rr_image_3); ?>" alt="<?php echo esc_attr($rr_image_alt_3); ?>">
        <?php endif; ?>
    </div>
    <div class="biscount-product-5__text text-center">
	<?php if ( !empty($settings['rr_text_list_sub_title']) ) : ?>
        <span class="wow fadeInLeft animated rr-el-box-sub-title" data-wow-delay=".1s"><?php echo rr_kses( $settings['rr_text_list_sub_title']); ?></span>
		<?php endif;?>
		<?php if ( !empty($settings['rr_text_list_title']) ) : ?>
        <h3 class="biscount-product-5__title mb-30 wow fadeInLeft animated rr-el-box-title" data-wow-delay=".2s"><?php echo rr_kses( $settings['rr_text_list_title']); ?></h3>
		<?php endif;?>
		<?php if ( !empty($settings['rr_btn_text']) ) : ?>
        <a href="<?php echo esc_url($settings['rr_btn_link']['url']); ?>" class="discount-shop__btn wow fadeInLeft animated rr-el-btn" data-wow-delay=".3s"><?php echo rr_kses($settings['rr_btn_text']); ?></a>
		<?php endif;?>
    </div>
    <div class="biscount-product-5__thumb">
        <?php if(!empty($rr_image)) : ?>
        <img class="thumb-1" src="<?php echo esc_url($rr_image); ?>" alt="<?php echo esc_attr($rr_image_alt); ?>">
        <?php endif; ?>
        <?php if(!empty($rr_image_2)) : ?>
        <img class="thumb-2" src="<?php echo esc_url($rr_image_2); ?>" alt="<?php echo esc_attr($rr_image_alt_2); ?>">
        <?php endif; ?>
    </div>
</div>


<?php endif; 
	}
}

$widgets_manager->register( new Clearance_Sale() ); 