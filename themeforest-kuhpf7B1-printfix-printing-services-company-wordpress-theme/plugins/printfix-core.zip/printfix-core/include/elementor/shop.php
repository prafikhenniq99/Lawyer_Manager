<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Shop extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'rr-shop';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Shop', 'rr-core' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'rr-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'rr-core' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'rr-core' ];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }
    protected function register_controls_section() {
     // Layout Panel
     $this->start_controls_section(
        'rr_layout',
        [
            'label' => esc_html__('Design Layout', 'rr-core'),
        ]
    );

    $this->add_control(
        'rr_design_style',
        [
            'label'   => esc_html__('Select Layout', 'rr-core'),
            'type'    => Controls_Manager::SELECT,
            'options' => [
                'layout-1' => esc_html__('Layout 1', 'rr-core'),
                'layout-2' => esc_html__('Layout 2', 'rr-core'),
                'layout-3' => esc_html__('Layout 3', 'rr-core'),
            ],
            'default' => 'layout-1',
        ]
    );

    $this->end_controls_section();
        $this->start_controls_section(
            'tp_section_sec',
            [
              'label' => esc_html__( 'Section Title', 'tpcore' ),
              'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
              
            ]
        );
        
        $this->add_control(
         'rr_section_title',
            [
            'label'       => esc_html__( 'Title', 'tpcore' ),
            'type'        => \Elementor\Controls_Manager::TEXTAREA,
            'default'     => esc_html__( 'Your Title', 'tpcore' ),
            'placeholder' => esc_html__( 'Your Text', 'tpcore' ),
            'label_block' => true
            ]
        );
        
        $this->end_controls_section();
           // section column
           $this->rr_columns('col', ['layout-1', 'layout-2', 'layout-3']);
        // Query Controls
        $this->rr_query_controls_wooc('product', 'Product', '6', '10', 'product', 'product_cat', ['layout-1', 'layout-2']);
          // rr_btn_button_group
          $this->start_controls_section(
            'rr_btn_button_group',
            [
                'label' => esc_html__('Button', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_btn_text',
            [
                'label' => esc_html__('Button Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'rr-core'),
                'title' => esc_html__('Enter button text', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_btn_link',
            [
                'label' => esc_html__('Button link', 'rr-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htRRs://your-link.com', 'rr-core'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'label_block' => true,
            ]
        );
        
        $this->end_controls_section();

    }

    // style_tab_content
    protected function style_tab_content(){

        $this->rr_section_style_controls('shops_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('shops_title', 'Shops Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('shops_desc', 'Shops Price Old', '.rr-el-re-price');
        $this->rr_basic_style_controls('shops_price_old', 'Shops Price', '.rr-el-re-price-2');
        $this->rr_link_controls_style('repiter_btn', 'Shops - Button', '.rr-el-btn');
        
    }
    protected function product_badge(){ 
		$settings = $this->get_settings_for_display();

		global $product;
		global $post;
		global $woocommerce;
		$rating = wc_get_rating_html($product->get_average_rating());
		$terms = get_the_terms(get_the_ID(), 'product_cat');	

		// avarage rating
		$product_rating_count = $product->get_average_rating();

		// review count
		$review_count = $product->get_review_count();

		$sale_count_to_show 	= $settings['sale_count_to_show'];
		$rating_count_to_show 	= $settings['rating_count_to_show'];
		$review_count_to_show 	= $settings['review_count_to_show'];
		$view_count_to_show 	= $settings['view_count_to_show'];
		$date_diff_to_show 		= $settings['date_diff_to_show'];
		
	?>

<ul class="d-flex">
    <?php if( $product->is_on_sale()) : ?>
    <li>
        <?php woocommerce_show_product_loop_sale_flash(); ?>
    </li>
    <?php endif; ?>


    <?php if($enable_trending_badge === "yes") : ?>

    <?php if($product_badge_type === "sales") : ?>
    <!-- it depends on sales -->
    <?php if($sale_count > $sale_count_to_show) : ?>
    <li>
        <span class="onsale on-trending"><?php echo esc_html__('Trending', 'shofy'); ?></span>
    </li>
    <!-- it depends on sales end -->
    <?php endif; ?>

    <?php elseif($product_badge_type === "rating") : ?>

    <!-- it depends on rating -->
    <?php if(floatval($product_rating_count) >= floatval($rating_count_to_show)) : ?>
    <li>
        <span class="onsale on-trending"><?php echo esc_html__('Trending', 'shofy'); ?></span>
    </li>
    <!-- it depends on rating end -->
    <?php endif; ?>

    <?php elseif($product_badge_type === "review") : ?>

    <!-- it depends on review -->
    <?php if($review_count >= $review_count_to_show) : ?>
    <li>
        <span class="onsale on-trending"><?php echo esc_html__('Trending', 'shofy'); ?></span>
    </li>
    <!-- it depends on review end -->
    <?php endif; ?>

    <?php elseif($product_badge_type === "views") : ?>

    <!-- it depends on views -->
    <?php if($view_count >= $view_count_to_show) : ?>
    <li>
        <span class="onsale on-trending"><?php echo esc_html__('Trending', 'shofy'); ?></span>
    </li>
    <!-- it depends on views end -->
    <?php endif; ?>

    <?php endif; ?>
    <?php endif; ?>

    <?php if($enable_hot_badge == 'yes') : ?>
    <?php if($date_diff <= $date_diff_to_show) : ?>
    <li>
        <span class="onsale on-hot"><?php echo esc_html__('Hot', 'shofy'); ?></span>
    </li>
    <?php endif; ?>
    <?php endif; ?>
</ul>

<?php
	}


        
    /**
     * Render the widget ouRRut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        // Setup query arguments using helper function
        $query_args = RR_Helper::get_query_args('product', 'product_cat', $settings);

        // The Query
        $query = new \WP_Query($query_args);

        $filter_list = $settings['category'];

        // Ensure $filter_list is an array
        if (is_string($filter_list)) {
            $filter_list = explode(',', $filter_list); // Convert comma-separated string to array
        } elseif (!is_array($filter_list)) { 
            $filter_list = []; // Fallback to an empty array
        }
        
        // Check if the array is not empty
        if (empty($filter_list)) {
            echo '<p>' . esc_html__('No categories found.', 'rr-core') . '</p>';
            return;
        }

        ?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ):
    $this->add_render_attribute('title_args', 'class', 'rr-video-title rr-el-title');
?>
<div class="discount-product-5__wrapper discount-wrapper__space  pl-70">
    <div class="row">
        <div class="col-12">
            <div class="discount-product-5__section-title section-title-space-4 mb-50">
                <?php if(!empty($settings['rr_section_title'])) : ?>
                <h4 class="discount-section-title-5 wow fadeInLeft animated" data-wow-delay=".1s">
                    <?php echo rr_kses($settings['rr_section_title']); ?>
                </h4>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="row">
        <?php 
            while ($query->have_posts()) : 
            $query->the_post();
            global $product;
            global $post;
            global $woocommerce;

            $review_count = $product->get_review_count();
            $rating_count = $product->get_rating_count();
            $terms = get_the_terms(get_the_ID(), 'product_cat');
    ?>
        <div class="col-xl-6 col-lg-6 col-md-6">
            <div class="rr-trend-product-5__item-box product-5__item__space wow fadeInLeft animated"
                data-wow-delay=".2s">
                <div class="rr-trend-product-5__item">
                    <div class="rr-trend-product-5__thumb discount-product-5__thumb  fix p-relative">
                        <?php 
                                $get_img_from_meta = function_exists( 'tpmeta_image_field' ) ? tpmeta_image_field( 'shofy_get_img_thumbnail' ) : NULL;
                                if(!empty($get_img_from_meta)): ?>
                        <img src="<?php echo esc_url($get_img_from_meta['url']) ?>"
                            alt="<?php echo esc_attr($get_img_from_meta['alt']); ?>">
                        <?php else: 
                        the_post_thumbnail();
                        endif; 
                    ?>
                        <div class="discount-product-5__icon">
                            <?php if( function_exists( 'woosw_init' )) : ?>
                            <!-- wishlist button -->
                            <?php echo do_shortcode('[woosw]'); ?>
                            <?php endif; ?>
                            <?php if( function_exists( 'woosc_init' )) : ?>
                            <!-- compare button -->
                            <?php echo do_shortcode('[woosc]');?>
                            <?php endif; ?>
                            <!-- quick view button -->
                            <?php if( class_exists( 'WPCleverWoosq' )) : ?>
                            <?php echo do_shortcode('[woosq]'); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="rr-trend-product-5__content">
                        <ul>
                            <li>
                                <div class="rr-trend-product-5__title-box">
                                    <h4 class="rr-trend-product-5__title-sm"><a
                                            href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    </h4>
                                </div>
                            </li>
                            <?php if(!empty(woocommerce_template_loop_price())): ?>
                            <li>
                                <div class="rr-trend-product-5__price">
                                    <?php echo woocommerce_template_loop_price();?>
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php if(!empty(woocommerce_template_single_rating())): ?>
                            <li>
                                <div class="rr-trend-product-5__star">
                                    <?php woocommerce_template_single_rating(); ?>
                                </div>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; wp_reset_query(); ?>
    </div>
</div>
<?php elseif ( $settings['rr_design_style']  == 'layout-3' ):
    $this->add_render_attribute('title_args', 'class', 'rr-video-title rr-el-title');
?>
<div class="row">
    <?php 
    while ($query->have_posts()) : 
    $query->the_post();
    global $product;
    global $post;
    global $woocommerce;
    $review_count = $product->get_review_count();
    $rating_count = $product->get_rating_count();
    $terms = get_the_terms(get_the_ID(), 'product_cat');
?>
    <div
        class="col-xl-<?php echo esc_attr($settings['rr_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['rr_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['rr_col_for_tablet']); ?> col-<?php echo esc_attr($settings['rr_col_for_mobile']); ?>">
        <div class="rr-fea-product__item rr-pro-img">
            <div class="rr-fea-product__thumb fix p-relative">
                <?php 
        $get_img_from_meta = function_exists( 'tpmeta_image_field' ) ? tpmeta_image_field( 'shofy_get_img_thumbnail' ) : NULL;
        if(!empty($get_img_from_meta)): ?>
                <img class="upDown" src="<?php echo esc_url($get_img_from_meta['url']) ?>"
                    alt="<?php echo esc_attr($get_img_from_meta['alt']); ?>">
                <?php else: 
            the_post_thumbnail();
            endif; 
        ?>
                <div class="rr-fea-product__icon-box icon-box-3 rr-product-action">
                    <?php if( function_exists( 'woosc_init' )) : ?>
                    <!-- compare button -->
                    <div class="product-action-btn mb-6">
                        <?php echo do_shortcode('[woosc]');?>
                    </div>
                    <?php endif; ?>
                    <?php if( function_exists( 'woosw_init' )) : ?>
                    <!-- wishlist button -->
                    <div class="product-action-btn mb-6">
                        <?php echo do_shortcode('[woosw]'); ?>
                    </div>
                    <?php endif; ?>
                    <!-- quick view button -->
                    <?php if( class_exists( 'WPCleverWoosq' )) : ?>
                    <div class="product-action-btn">
                        <?php echo do_shortcode('[woosq]'); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="rr-fea-product__content">
                <?php if(!empty(woocommerce_template_single_rating())): ?>
                <div class="rr-fea-product__star">
                    <?php woocommerce_template_single_rating(); ?>
                </div>
                <?php endif; ?>
                <h4 class="rr-fea-product__title-sm"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                <?php if(!empty(woocommerce_template_loop_price())): ?>
                <div class="rr-product-content-price">
                    <span class="product-item-3-price">
                        <span class="price">
                            <span class="woocs_price_code d-flex gap-6">
                                <?php echo woocommerce_template_loop_price();?>
                            </span>
                        </span>
                    </span>
                </div>
                <?php endif; ?>
                <?php if(!empty(woocommerce_template_loop_add_to_cart())): ?>
                <div class="rr-fea-product__link-box">
                    <?php woocommerce_template_loop_add_to_cart();?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php endwhile; wp_reset_query(); ?>
</div>
<?php else: 
  
    $this->add_render_attribute('title_args', 'class', 'rr-section-title wow rrfadeUp rr-el-title');
?>
<div class="rr-trend-product-5__area mb-60">
    <div class="container custom-container">
        <div class="rr-trend-product-5__title-wrap">
            <?php if(!empty($settings['rr_section_title'])) : ?>
            <h2 class="rr-trend-product-5__title-wrap-title wow fadeInLeft animated" data-wow-delay=".1s">
                <?php echo rr_kses($settings['rr_section_title']); ?> </h2>
            <?php endif; ?>
            <?php if(!empty($settings['rr_btn_text'])) : ?>
            <a href="<?php echo esc_url($settings['rr_btn_link']['url']); ?>"
                class="prodact-5-btn wow fadeInRight animated"
                data-wow-delay=".2s"><?php echo rr_kses($settings['rr_btn_text']); ?>
                <i class="fa-regular fa-arrow-right"></i></a>
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="rr-trend-product-5__wrapper">
                <div class="row">
                    <?php 
                            while ($query->have_posts()) : 
                            $query->the_post();
                            global $product;
                            global $post;
                            global $woocommerce;
                            $review_count = $product->get_review_count();
                            $rating_count = $product->get_rating_count();
                            $terms = get_the_terms(get_the_ID(), 'product_cat');

                    ?>
                    <div class="col-xl-3 col-lg-4 col-md-6">
                        <div class="rr-trend-product-5__item-box wow fadeInLeft animated" data-wow-delay=".1s">
                            <div class="rr-trend-product-5__item">
                                <div class="rr-trend-product-5__thumb fix p-relative">

                                    <?php 
                                             $get_img_from_meta = function_exists( 'tpmeta_image_field' ) ? tpmeta_image_field( 'shofy_get_img_thumbnail' ) : NULL;
                                             if(!empty($get_img_from_meta)): ?>
                                    <img src="<?php echo esc_url($get_img_from_meta['url']) ?>"
                                        alt="<?php echo esc_attr($get_img_from_meta['alt']); ?>">
                                    <?php else: 
                                        the_post_thumbnail();
                                        endif; 
                                    ?>
                                </div>
                                <div class="rr-trend-product-5__content">
                                    <ul>
                                        <li>
                                            <div class="rr-trend-product-5__title-box">
                                                <h4 class="rr-trend-product-5__title-sm">
                                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                                </h4>
                                            </div>
                                        </li>
                                        <?php if(!empty(woocommerce_template_loop_price())): ?>
                                        <li>
                                            <div class="rr-trend-product-5__price">
                                                <?php echo woocommerce_template_loop_price(); ?>
                                            </div>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(!empty(woocommerce_template_single_rating())): ?>
                                        <li>
                                            <div class="rr-trend-product-5__star">
                                                <?php woocommerce_template_single_rating(); ?>
                                            </div>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>

                            </div>
                            <div class="rr-trend-product-5__link-box text-center">
                                <?php  woocommerce_template_loop_add_to_cart();?>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; wp_reset_query(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php endif; 
    }
}

$widgets_manager->register( new rr_Shop() ); 