<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;
use \Elementor\Repeater;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;
use RRCore\Elementor\Controls\Group_Control_RRGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Slider extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-slider';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Slider', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}


    protected static function get_profile_names()
    {
        return [
            'apple' => esc_html__('Apple', 'rr-core'),
            'behance' => esc_html__('Behance', 'rr-core'),
            'bitbucket' => esc_html__('BitBucket', 'rr-core'),
            'codepen' => esc_html__('CodePen', 'rr-core'),
            'delicious' => esc_html__('Delicious', 'rr-core'),
            'deviantart' => esc_html__('DeviantArt', 'rr-core'),
            'digg' => esc_html__('Digg', 'rr-core'),
            'dribbble' => esc_html__('Dribbble', 'rr-core'),
            'email' => esc_html__('Email', 'rr-core'),
            'facebook' => esc_html__('Facebook', 'rr-core'),
            'flickr' => esc_html__('Flicker', 'rr-core'),
            'foursquare' => esc_html__('FourSquare', 'rr-core'),
            'github' => esc_html__('Github', 'rr-core'),
            'houzz' => esc_html__('Houzz', 'rr-core'),
            'instagram' => esc_html__('Instagram', 'rr-core'),
            'jsfiddle' => esc_html__('JS Fiddle', 'rr-core'),
            'linkedin' => esc_html__('LinkedIn', 'rr-core'),
            'medium' => esc_html__('Medium', 'rr-core'),
            'pinterest' => esc_html__('Pinterest', 'rr-core'),
            'product-hunt' => esc_html__('Product Hunt', 'rr-core'),
            'reddit' => esc_html__('Reddit', 'rr-core'),
            'slideshare' => esc_html__('Slide Share', 'rr-core'),
            'snapchat' => esc_html__('Snapchat', 'rr-core'),
            'soundcloud' => esc_html__('SoundCloud', 'rr-core'),
            'spotify' => esc_html__('Spotify', 'rr-core'),
            'stack-overflow' => esc_html__('StackOverflow', 'rr-core'),
            'tripadvisor' => esc_html__('TripAdvisor', 'rr-core'),
            'tumblr' => esc_html__('Tumblr', 'rr-core'),
            'twitch' => esc_html__('Twitch', 'rr-core'),
            'twitter' => esc_html__('Twitter', 'rr-core'),
            'vimeo' => esc_html__('Vimeo', 'rr-core'),
            'vk' => esc_html__('VK', 'rr-core'),
            'website' => esc_html__('Website', 'rr-core'),
            'whatsapp' => esc_html__('WhatsApp', 'rr-core'),
            'wordpress' => esc_html__('WordPress', 'rr-core'),
            'xing' => esc_html__('Xing', 'rr-core'),
            'yelp' => esc_html__('Yelp', 'rr-core'),
            'youtube' => esc_html__('YouTube', 'rr-core'),
        ];
    }


	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {
		

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );
        $this->end_controls_section();

		
		$this->start_controls_section(
            'rr_main_slider',
            [
                'label' => esc_html__('Main Slider', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'rr_slider_image',
            [
                'label' => esc_html__('Upload Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]
            ]
        );
        $repeater->add_control(
            'rr_slider_image2',
            [
                'label' => esc_html__('Upload Image Two', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'rr_slider_sub_title',
            [
                'label' => esc_html__('Sub Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => 'Subtitle',
                'placeholder' => esc_html__('Type Before Heading Text', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_slider_title',
            [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('Grow business.', 'rr-core'),
                'placeholder' => esc_html__('Type Heading Text', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_slider_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'rr-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'rr-core'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'rr-core'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'rr-core'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'rr-core'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'rr-core'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'rr-core'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );

        $repeater->add_control(
            'rr_slider_description',
            [
                'label' => esc_html__('Description', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('There are many variations of passages of Lorem Ipsum available but the majority have suffered alteration.', 'rr-core'),
                'placeholder' => esc_html__('Type section description here', 'rr-core'),
            ]
        );

        
		$repeater->add_control(
            'rr_btn_link_switcher',
            [
                'label' => esc_html__( 'Add Button link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'rr-core' ),
                'label_off' => esc_html__( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $repeater->add_control(
            'rr_btn_btn_text',
            [
                'label' => esc_html__('Button Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'rr-core'),
                'title' => esc_html__('Enter button text', 'rr-core'),
                'label_block' => true,
                'condition' => [
                    'rr_btn_link_switcher' => 'yes',
                ],
            ]
        );
        $repeater->add_control(
            'rr_btn_link_type',
            [
                'label' => esc_html__( 'Button Link Type', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'rr_btn_link_switcher' => 'yes',
                ]
            ]
        );
        
        $repeater->add_control(
            'rr_btn_link',
            [
                'label' => esc_html__( 'Button Link link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htRRs://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'rr_btn_link_type' => '1',
                    'rr_btn_link_switcher' => 'yes',
                ]
            ]
        );

        $repeater->add_control(
            'rr_btn_page_link',
            [
                'label' => esc_html__( 'Select Button Link Page', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => rr_get_all_pages(),
                'condition' => [
                    'rr_btn_link_type' => '2',
                    'rr_btn_link_switcher' => 'yes',
                ]
            ]
        );
        $repeater->add_control(
            'rr_video_url_switcher',
            [
                'label' => esc_html__( 'Video', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'rr-core' ),
                'label_off' => esc_html__( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $repeater->add_control(
            'rr_video_url',
            [
                'label' => esc_html__( 'Video Url', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htRRs://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
               
            ]
        );
        $repeater->add_control(
            'rr_video_text',
            [
                'label' => esc_html__('Video Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'rr-core'),
                'title' => esc_html__('Enter button text', 'rr-core'),
                'label_block' => true,
                'condition' => [
                    'rr_btn_link_switcher' => 'yes',
                ],
            ]
        );


        $repeater->add_control(
            'show_social',
            [
                'label' => __( 'Show Social Links?', 'rr-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Yes', 'rr-core' ),
                'label_off' => __( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'style_transfer' => true,
            ]
        );               

        $repeater->add_control(
            'facebook_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Facebook', 'rr-core' ),
                'default' => __( '#', 'rr-core' ),
                'placeholder' => __( 'Add your facebook link', 'rr-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                

        $repeater->add_control(
            'twitter_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Twitter', 'rr-core' ),
                'default' => __( '#', 'rr-core' ),
                'placeholder' => __( 'Add your twitter link', 'rr-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );      
        $repeater->add_control(
            'instragram_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Instragram', 'rr-core' ),
                'placeholder' => __( 'Add your Instragram link', 'rr-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );                    

        $repeater->add_control(
            'vimeo_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Vimeo', 'rr-core' ),
                'placeholder' => __( 'Add your Vimeo link', 'rr-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );        

        $repeater->add_control(
            'pinterest_title',
            [
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'label' => __( 'Pinterest', 'rr-core' ),
                'placeholder' => __( 'Add your pinterest link', 'rr-core' ),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );



  
        $this->add_control(
            'slider_list',
            [
                'label' => esc_html__('Slider List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_slider_title' => esc_html__('Grow business.', 'rr-core')
                    ],
                    [
                        'rr_slider_title' => esc_html__('Development.', 'rr-core')
                    ],
                    [
                        'rr_slider_title' => esc_html__('Marketing.', 'rr-core')
                    ],
                ],
                'title_field' => '{{{ rr_slider_title }}}',
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'exclude' => ['custom'],
                // 'default' => 'rr-portfolio-thumb',
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'rr_shap_section',
                [
                    'label' => esc_html__( 'Shape', 'rr-core' ),
                    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
                ]
            );
    
            $this->add_control(
                'rr_shape_switcher',
                [
                    'label' => esc_html__( 'Slider Shape', 'rr-core' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => esc_html__( 'Yes', 'rr-core' ),
                    'label_off' => esc_html__( 'No', 'rr-core' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                    'separator' => 'before',
                ]
            );
    
            $this->end_controls_section();
 
        
	}

    
    protected function style_tab_content(){
        $this->rr_section_style_controls('banner_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('banner_sub_title', 'Sub Heading Style', '.ele-sub-heading');
        $this->rr_basic_style_controls('banner_title', 'Heading Style', '.ele-heading');
        $this->rr_basic_style_controls('banner_desc', 'Description Style', '.ele-desc');
        $this->rr_link_controls_style('banner_btn_1', 'Button Style 1', '.ele-btn-1');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *Video Youtube link

	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ): ?>

<!-- Banner area start -->
<section class="banner__area p-relative overflow-hidden ele-section">
    <div class="bg-color"></div>
    <div class="banner-home__middel-shape-2"></div>
    <div class="banner-custom-container">
        <div class="swiper banner_parallax-slider p-relative">
            <div class="swiper-wrapper">
                <?php foreach ($settings['slider_list'] as $key => $item) : 
            $this->add_render_attribute('title_args', 'class', 'title ele-heading');

            if ( !empty($item['rr_slider_image']['url']) ) {
                $rr_slider_image = !empty($item['rr_slider_image']['id']) ? wp_get_attachment_image_url( $item['rr_slider_image']['id'], $settings['thumbnail_size']) : $item['rr_slider_image']['url'];
                $rr_slider_image_alt = get_post_meta($item["rr_slider_image"]["id"], "_wp_attachment_image_alt", true);
            }
            if ( !empty($item['rr_slider_image2']['url']) ) {
                $rr_slider_image2 = !empty($item['rr_slider_image2']['id']) ? wp_get_attachment_image_url( $item['rr_slider_image2']['id'], $settings['thumbnail_size']) : $item['rr_slider_image2']['url'];
                $rr_slider_image_alt2 = get_post_meta($item["rr_slider_image2"]["id"], "_wp_attachment_image_alt", true);
            }

                // btn Link
                if ('2' == $item['rr_btn_link_type']) {
                    $link = get_permalink($item['rr_btn_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['rr_btn_link']['url']) ? $item['rr_btn_link']['url'] : '';
                    $target = !empty($item['rr_btn_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['rr_btn_link']['nofollow']) ? 'nofollow' : '';
                }
            ?>
                <div class="swiper-slide">
                    <div class="banner banner__space banner__space-3 overflow-hidden">
                        <?php if (!empty($settings['rr_shape_switcher'])) : ?>
                        <div class="bg-shape">
                            <img class="leftRight"
                                src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-3/isolation_mode-2.svg"
                                alt="img not found">
                        </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-xl-4 col-lg-6 col-md-12">
                                <div class="banner__content content-3 p-relative z-index-1">

                                    <?php if (!empty($item['rr_slider_sub_title'])) : ?>
                                    <span
                                        class="sub-title ele-sub-heading"><?php echo rr_kses( $item['rr_slider_sub_title'] ); ?></span>
                                    <?php endif; ?>
                                    <?php
                                    if ($item['rr_slider_title_tag']) :
                                        printf('<%1$s %2$s>%3$s</%1$s>',
                                            tag_escape($item['rr_slider_title_tag']),
                                            $this->get_render_attribute_string('title_args'),
                                            rr_kses($item['rr_slider_title'])
                                        );
                                    endif; ?>
                                    <div
                                        class="banner-home-2__btn__wrapper-2 d-flex flex-wrap mt-40 mt-md-35 mt-sm-30 mt-xs-25 pb-40">
                                        <a href="<?php echo esc_url($link); ?>"
                                            class="rr-btn wow fadeInLeft animated ele-btn-1"
                                            data-wow-delay="1s"><?php echo rr_kses($item['rr_btn_btn_text']);?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-6 col-md-12">
                                <div class="banner-media-3 p-relative z-index-1">
                                    <div class="middel-img upDown-bottom">
                                        <?php if(!empty($rr_slider_image)) : ?>
                                        <div class="frist-img img-border">
                                            <img src="<?php echo esc_url($rr_slider_image); ?>"
                                                alt="<?php echo esc_attr($rr_slider_image_alt); ?>">
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($rr_slider_image2)) : ?>
                                        <div class="secend-img img-border">
                                            <img src="<?php echo esc_url($rr_slider_image2); ?>"
                                                alt="<?php echo esc_attr($rr_slider_image_alt2); ?>">
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-6 col-md-12">
                                <div class="banner-text p-relative z-index-1">
                                    <div class="text-space">
                                        <?php if ( !empty($item['rr_slider_description']) ) : ?>
                                        <p class="ele-desc">
                                            <?php echo rr_kses( $item['rr_slider_description'] ); ?></p>
                                        <?php endif; ?>
                                        <?php if (!empty($settings['rr_shape_switcher'])) : ?>
                                        <div class="arrow">
                                            <img class="upDown"
                                                src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-3/banner-3-right-shape.svg"
                                                alt="img not found">
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <!-- If we need navigation buttons -->
    <div class="banner__navigation banner__navigation-3 d-none d-lg-block">
        <button class="banner__button-next">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M19 10H1" stroke="#001D08" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                <path d="M10 1L1 10L10 19" stroke="#001D08" stroke-width="2" stroke-linecap="round"
                    stroke-linejoin="round" />
            </svg>
        </button>
        <button class="banner__button-prev">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1 10H19" stroke="#001D08" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                <path d="M10 1L19 10L10 19" stroke="#001D08" stroke-width="2" stroke-linecap="round"
                    stroke-linejoin="round" />
            </svg>
        </button>

    </div>
</section>
<!-- Banner area end -->
<?php elseif ( $settings['rr_design_style']  == 'layout-3' ): ?>

<section class="banner-4__area p-relative ele-section">
    <div class="swiper banner-4__active">
        <div class="swiper-wrapper">
            <?php foreach ($settings['slider_list'] as $key => $item) : 
            $this->add_render_attribute('title_args', 'class', 'banner-4__title ele-heading');

            if ( !empty($item['rr_slider_image']['url']) ) {
                $rr_slider_image = !empty($item['rr_slider_image']['id']) ? wp_get_attachment_image_url( $item['rr_slider_image']['id'], $settings['thumbnail_size']) : $item['rr_slider_image']['url'];
                $rr_slider_image_alt = get_post_meta($item["rr_slider_image"]["id"], "_wp_attachment_image_alt", true);
            }

                // btn Link
                if ('2' == $item['rr_btn_link_type']) {
                    $link = get_permalink($item['rr_btn_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['rr_btn_link']['url']) ? $item['rr_btn_link']['url'] : '';
                    $target = !empty($item['rr_btn_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['rr_btn_link']['nofollow']) ? 'nofollow' : '';
                }
            ?>
            <div class="swiper-slide">
                <div class="p-relative banner-4__section__space overflow-hidden">
                    <div class="banner-4__bg"></div>
                    <div class="banner-4__circle__bg-1 p-absolute"></div>
                    <div class="banner-4__circle__bg-4 p-absolute"></div>
                    <div class="banner-4__circle__bg-2 p-absolute upDown"></div>
                    <div class="banner-4__circle__bg-3 p-absolute upDown-bottom"></div>
                    <div class="banner-4__circle__shape-1 p-absolute zooming"></div>
                    <div class="banner-4__circle__shape-2 p-absolute upDown-top"></div>
                    <div class="container custom-container">
                        <div class="row align-items-center flex-column-reverse flex-xl-row">
                            <div class="col-xl-7">
                                <div class="banner-4__thumb text-center text-xl-start" data-animation="pixfix-fadeInUp"
                                    data-delay="1000ms" data-duration="1200ms">
                                    <?php if(!empty($rr_slider_image)) : ?>
                                    <img src="<?php echo esc_url($rr_slider_image); ?>"
                                        alt="<?php echo esc_attr($rr_slider_image_alt); ?>">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-xl-5">
                                <div class="banner-4__text banner-4__text__space">
                                    <?php
                                    if ($item['rr_slider_title_tag']) :
                                        printf('<%1$s %2$s>%3$s</%1$s>',
                                            tag_escape($item['rr_slider_title_tag']),
                                            $this->get_render_attribute_string('title_args'),
                                            rr_kses($item['rr_slider_title'])
                                        );
                                    endif; ?>
                                    <?php if ( !empty($item['rr_slider_description']) ) : ?>
                                    <p class="banner-4__dec ele-desc" data-animation="pixfix-fadeInUp"
                                        data-delay="1400ms" data-duration="1600ms">
                                        <?php echo rr_kses( $item['rr_slider_description'] ); ?>
                                    </p>
                                    <?php endif; ?>
                                    <div class="banner-4__btn__wrapper">
                                        <a href="<?php echo esc_url($link); ?>" class="banner-4__btn ele-btn-1"
                                            data-animation="pixfix-fadeInUp" data-delay="1600ms"
                                            data-duration="1800ms"><?php echo rr_kses($item['rr_btn_btn_text']);?> <i
                                                class="fa-solid fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="slider-arrow d-none d-lg-block">
            <div class="slider-arrow-button slider-next p-absolute"><i class="fa-regular fa-chevron-right"></i></div>
            <div class="slider-arrow-button slider-prev p-absolute"><i class="fa-regular fa-chevron-left"></i></div>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-4' ): ?>
<section class="banner-5__area banner-4  p-relative overflow-hidden"
    data-background="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-4/banner-4-bg-shape.png">
    <div class="banner-5__bg-shape-5"></div>
    <div class="swiper banner-4__active">
        <div class="swiper-wrapper">

            <?php foreach ($settings['slider_list'] as $key => $item) : 
            $this->add_render_attribute('title_args', 'class', 'banner-4__title ele-heading');

            if ( !empty($item['rr_slider_image']['url']) ) {
                $rr_slider_image = !empty($item['rr_slider_image']['id']) ? wp_get_attachment_image_url( $item['rr_slider_image']['id'], $settings['thumbnail_size']) : $item['rr_slider_image']['url'];
                $rr_slider_image_alt = get_post_meta($item["rr_slider_image"]["id"], "_wp_attachment_image_alt", true);
            }
            if ( !empty($item['rr_slider_image2']['url']) ) {
                $rr_slider_image2 = !empty($item['rr_slider_image2']['id']) ? wp_get_attachment_image_url( $item['rr_slider_image2']['id'], $settings['thumbnail_size']) : $item['rr_slider_image2']['url'];
                $rr_slider_image_alt2 = get_post_meta($item["rr_slider_image2"]["id"], "_wp_attachment_image_alt", true);
            }
                // btn Link
                if ('2' == $item['rr_btn_link_type']) {
                    $link = get_permalink($item['rr_btn_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['rr_btn_link']['url']) ? $item['rr_btn_link']['url'] : '';
                    $target = !empty($item['rr_btn_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['rr_btn_link']['nofollow']) ? 'nofollow' : '';
                }
            ?>
            <div class="swiper-slide">
                <div class="banner-5__banner-space">
                    <div class="banner-5__color-shapes">
                        <div class="banner-5__color-shapes-shape-1"></div>
                        <div class="banner-5__color-shapes-shape-2"></div>
                    </div>
                    <?php if (!empty($settings['rr_shape_switcher'])) : ?>
                    <div class="banner-5__shapes">
                        <div class="banner-5__shapes-shape-1 upDown-top">
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-4/banner-5-shape-1.png"
                                alt="img not found">
                        </div>
                        <div class="banner-5__shapes-shape-2">
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-4/banner-5-shape-2.png"
                                alt="img not found" data-animation="pixfix-fadeInLeft" data-delay="1200ms"
                                data-duration="1400ms">
                        </div>
                        <div class="banner-5__shapes-shape-3">
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-4/banner-5-shape-3.png"
                                alt="img not found">
                        </div>
                        <div class="banner-5__shapes-shape-4">
                            <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-4/banner-5-shape-4.png"
                                alt="img not found">
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="container custom-container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="banner-5__content p-relative">
                                    <?php if (!empty($item['rr_slider_sub_title'])) : ?>
                                    <h6 class="banner-5__content-subtitle" data-animation="pixfix-fadeInUp"
                                        data-delay="1000ms" data-duration="1200ms">
                                        <?php echo rr_kses( $item['rr_slider_sub_title'] ); ?></h6>
                                    <?php endif; ?>
                                    <?php if (!empty($item['rr_slider_title'])) : ?>
                                    <h1 class="banner-5__content-title" data-animation="pixfix-fadeInUp"
                                        data-delay="1200ms" data-duration="1400ms">
                                        <?php echo rr_kses( $item['rr_slider_title'] ); ?></h1>
                                    <?php endif; ?>
                                    <?php if (!empty($item['rr_slider_description'])) : ?>
                                    <p class="banner-5__content-dec" data-animation="pixfix-fadeInUp"
                                        data-delay="1400ms" data-duration="1600ms">
                                        <?php echo rr_kses( $item['rr_slider_description'] ); ?></p>
                                    <?php endif; ?>
                                    <div class="banner-5__content-button-box" data-animation="pixfix-fadeInUp"
                                        data-delay="1600ms" data-duration="1800ms">
                                        <?php if (!empty($item['rr_btn_btn_text'])) : ?>
                                        <a class="banner-5__content-button-box-btn"
                                            href="<?php echo esc_url($link); ?>"><?php echo rr_kses($item['rr_btn_btn_text']);?></a>
                                            <?php endif; ?>
                                        <?php if (!empty($item['rr_video_url_switcher'])) : ?>
                                        <div class="banner-5__content-play-btn-box">
                                            <a class="banner-5__content-play-btn-box-play popup-video zooming"
                                                href="<?php echo esc_url($item['rr_video_url']['url']); ?>">
                                                <svg width="13" height="16" viewBox="0 0 13 16" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M12.5 7.13398C13.1667 7.51888 13.1667 8.48112 12.5 8.86602L2 14.9282C1.33333 15.3131 0.5 14.832 0.5 14.0622V1.93782C0.5 1.16802 1.33333 0.686897 2 1.0718L12.5 7.13398Z"
                                                        fill="#D44E49" />
                                                </svg>
                                            </a>
                                          
                                            <?php if (!empty($item['rr_video_text'])) : ?>
                                            <a class="banner-5__content-play-btn-box-btn popup-video zooming"
                                                href="<?php echo esc_url($item['rr_video_url']['url']); ?>"><?php echo rr_kses($item['rr_video_text']); ?></a>
                                            <?php endif; ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="banner-5__media">
                                    <div class="banner-5__media-img-1">
                                        <?php if(!empty($rr_slider_image)) : ?>
                                        <img src="<?php echo esc_url($rr_slider_image); ?>"
                                            alt="<?php echo esc_url($rr_slider_image_alt); ?>"
                                            data-animation="pixfix-fadeInLeft" data-delay="1000ms"
                                            data-duration="1200ms">
                                        <?php endif; ?>
                                    </div>
                                    <?php if(!empty($rr_slider_image2)) : ?>
                                    <div class="banner-5__media-img-2">
                                        <img src="<?php echo esc_url($rr_slider_image2); ?>"
                                            alt="<?php echo esc_url($rr_slider_image_alt2); ?>"
                                            data-animation="pixfix-fadeInRight" data-delay="1200ms"
                                            data-duration="1400ms">
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if (!empty($item['show_social'])) : ?>
                    <div class="banner-5__hero-social">
                        <ul class="banner-5__hero-social-list">
                        <?php if (!empty($item['facebook_title'])) : ?>
                            <li data-animation="pixfix-fadeInUp" data-delay="1000ms" data-duration="1200ms">
                                <a href="<?php echo esc_url($item['facebook_title']); ?>"><i class="fab fa-facebook-f"></i></a>
                            </li>
                        <?php endif; ?>
                        <?php if (!empty($item['instragram_title'])) : ?>
                            <li data-animation="pixfix-fadeInUp" data-delay="1200ms" data-duration="1400ms">
                                <a href="<?php echo esc_url($item['instragram_title']); ?>"><i class="fab fa-instagram"></i></a>
                            </li>
                            <?php endif; ?>
                            <?php if (!empty($item['pinterest_title'])) : ?>
                            <li data-animation="pixfix-fadeInUp" data-delay="1400ms" data-duration="1600ms">
                                <a href="<?php echo esc_url($item['pinterest_title']); ?>"><i class="fa-brands fa-pinterest-p"></i></a>
                            </li>
                            <?php endif; ?>
                            <?php if (!empty($item['vimeo_title'])) : ?>
                            <li data-animation="pixfix-fadeInUp" data-delay="1600ms" data-duration="1800ms">
                                <a href="<?php echo esc_url($item['vimeo_title']); ?>"><i class="fa-brands fa-vimeo-v"></i></a>
                            </li>
                            <?php endif; ?>
                        </ul>
                        <div class="overlay" data-animation="pixfix-fadeInUp" data-delay="1800ms"
                            data-duration="2000ms"></div>
                        <h4 class="follow"><?php echo esc_attr__( 'Follow Us', 'rr-core' )?></h4>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="slider-arrow banner-5__slider-arrow">
            <div class="slider-arrow-button slider-next p-absolute">
                <svg width="17" height="12" viewBox="0 0 17 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M16.5303 6.53033C16.8232 6.23744 16.8232 5.76256 16.5303 5.46967L11.7574 0.696699C11.4645 0.403806 10.9896 0.403806 10.6967 0.696699C10.4038 0.989593 10.4038 1.46447 10.6967 1.75736L14.9393 6L10.6967 10.2426C10.4038 10.5355 10.4038 11.0104 10.6967 11.3033C10.9896 11.5962 11.4645 11.5962 11.7574 11.3033L16.5303 6.53033ZM0 6.75L16 6.75V5.25L0 5.25L0 6.75Z"
                        fill="#001D08" />
                </svg>
            </div>
            <div class="slider-arrow-button slider-prev p-absolute">
                <svg width="17" height="12" viewBox="0 0 17 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M0.469669 6.53033C0.176777 6.23744 0.176777 5.76256 0.469669 5.46967L5.24264 0.696699C5.53553 0.403806 6.01041 0.403806 6.3033 0.696699C6.59619 0.989593 6.59619 1.46447 6.3033 1.75736L2.06066 6L6.3033 10.2426C6.59619 10.5355 6.59619 11.0104 6.3033 11.3033C6.01041 11.5962 5.53553 11.5962 5.24264 11.3033L0.469669 6.53033ZM17 6.75L1 6.75V5.25L17 5.25V6.75Z"
                        fill="#001D08" />
                </svg>
            </div>
        </div>
    </div>
</section>
<?php else: 
?>
<section class="banner__area p-relative z-1 ele-section">
    <div class="swiper banner_parallax-slider p-relative">
        <div class="swiper-wrapper">
            <?php foreach ($settings['slider_list'] as $key => $item) : 
            $this->add_render_attribute('title_args', 'class', 'banner__title wow fade-in-bottom ele-heading');

            if ( !empty($item['rr_slider_image']['url']) ) {
                $rr_slider_image = !empty($item['rr_slider_image']['id']) ? wp_get_attachment_image_url( $item['rr_slider_image']['id'], $settings['thumbnail_size']) : $item['rr_slider_image']['url'];
                $rr_slider_image_alt = get_post_meta($item["rr_slider_image"]["id"], "_wp_attachment_image_alt", true);
            }

                // btn Link
                if ('2' == $item['rr_btn_link_type']) {
                    $link = get_permalink($item['rr_btn_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['rr_btn_link']['url']) ? $item['rr_btn_link']['url'] : '';
                    $target = !empty($item['rr_btn_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['rr_btn_link']['nofollow']) ? 'nofollow' : '';
                }
            ?>
            <div class="swiper-slide">
                <div class="banner banner__space">
                    <div class="banner__thumb-bg" data-background="<?php echo esc_url($rr_slider_image); ?>"></div>
                    <div class="container">
                        <div class="banner__space-shape-wrapper">
                            <div class="banner__space-shape-wrapper-top-black-shape">
                                <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-2/banner-2-top-black-shape.svg"
                                    alt="img not found">
                            </div>
                            <div class="banner__space-shape-wrapper-bottom-shape">
                                <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/banner-2/banner-2-botom-shape.svg"
                                    alt="img not found">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xxl-9 col-xl-9 col-lg-10">
                                <div class="banner__content p-relative z-index-1">
                                    <?php if (!empty($item['rr_slider_sub_title'])) : ?>
                                    <span class="banner__sub-title wow fade-in-bottom ele-sub-heading"
                                        data-wow-delay="200ms"><?php echo rr_kses( $item['rr_slider_sub_title'] ); ?></span>
                                    <?php endif; ?>
                                    <?php
                                    if ($item['rr_slider_title_tag']) :
                                        printf('<%1$s %2$s>%3$s</%1$s>',
                                            tag_escape($item['rr_slider_title_tag']),
                                            $this->get_render_attribute_string('title_args'),
                                            rr_kses($item['rr_slider_title'])
                                        );
                                    endif; ?>
                                    <?php if ( !empty($item['rr_slider_description']) ) : ?>
                                    <p class="h5 wow fade-in-bottom ele-desc" data-wow-delay="400ms">
                                        <?php echo rr_kses( $item['rr_slider_description'] ); ?></p>
                                    <?php endif; ?>
                                    <?php if ( !empty($item['rr_btn_btn_text']) ) : ?>
                                    <div
                                        class="banner-home-2__btn__wrapper-2 d-flex flex-wrap mt-40 mt-md-35 mt-sm-30 mt-xs-25">
                                        <a href="<?php echo esc_url($link); ?>"
                                            class="rr-btn btn-hover-white wow fadeInLeft animated"
                                            data-wow-delay="1s"><?php echo rr_kses($item['rr_btn_btn_text']);?></a>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- If we need navigation buttons -->
        <div class="banner__navigation d-none d-lg-block">
            <button class="banner__button-next"><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 10H1" stroke="#001D08" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                    <path d="M10 1L1 10L10 19" stroke="#001D08" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
            </button>

            <button class="banner__button-prev"><svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M1 10H19" stroke="#001D08" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                    <path d="M10 1L19 10L10 19" stroke="#001D08" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
            </button>

        </div>
    </div>
</section>

<?php endif; 
		
	}

}

$widgets_manager->register( new rr_Slider() );