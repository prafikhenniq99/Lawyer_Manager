<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Control_Media;
use Elementor\Core\Utils\ImportExport\Url;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * rr Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Team_Details extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'rr-team-details-contact';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Team Details Contact', 'rr-core' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'rr-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'rr-core' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'rr-core' ];
    }
    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */

     protected static function get_profile_names()
    {
        return [
            'apple' => esc_html__('Apple', 'rr-core'),
            'behance' => esc_html__('Behance', 'rr-core'),
            'bitbucket' => esc_html__('BitBucket', 'rr-core'),
            'codepen' => esc_html__('CodePen', 'rr-core'),
            'delicious' => esc_html__('Delicious', 'rr-core'),
            'deviantart' => esc_html__('DeviantArt', 'rr-core'),
            'digg' => esc_html__('Digg', 'rr-core'),
            'dribbble' => esc_html__('Dribbble', 'rr-core'),
            'email' => esc_html__('Email', 'rr-core'),
            'facebook-f' => esc_html__('Facebook', 'rr-core'),
            'flickr' => esc_html__('Flicker', 'rr-core'),
            'foursquare' => esc_html__('FourSquare', 'rr-core'),
            'github' => esc_html__('Github', 'rr-core'),
            'houzz' => esc_html__('Houzz', 'rr-core'),
            'instagram' => esc_html__('Instagram', 'rr-core'),
            'jsfiddle' => esc_html__('JS Fiddle', 'rr-core'),
            'linkedin-in' => esc_html__('LinkedIn', 'rr-core'),
            'medium' => esc_html__('Medium', 'rr-core'),
            'pinterest' => esc_html__('Pinterest', 'rr-core'),
            'product-hunt' => esc_html__('Product Hunt', 'rr-core'),
            'reddit' => esc_html__('Reddit', 'rr-core'),
            'slideshare' => esc_html__('Slide Share', 'rr-core'),
            'snapchat' => esc_html__('Snapchat', 'rr-core'),
            'soundcloud' => esc_html__('SoundCloud', 'rr-core'),
            'spotify' => esc_html__('Spotify', 'rr-core'),
            'stack-overflow' => esc_html__('StackOverflow', 'rr-core'),
            'tripadvisor' => esc_html__('TripAdvisor', 'rr-core'),
            'tumblr' => esc_html__('Tumblr', 'rr-core'),
            'twitch' => esc_html__('Twitch', 'rr-core'),
            'twitter' => esc_html__('Twitter', 'rr-core'),
            'vimeo' => esc_html__('Vimeo', 'rr-core'),
            'vk' => esc_html__('VK', 'rr-core'),
            'website' => esc_html__('Website', 'rr-core'),
            'whatsapp' => esc_html__('WhatsApp', 'rr-core'),
            'wordpress' => esc_html__('WordPress', 'rr-core'),
            'xing' => esc_html__('Xing', 'rr-core'),
            'yelp' => esc_html__('Yelp', 'rr-core'),
            'youtube' => esc_html__('YouTube', 'rr-core'),
        ];
    }
     
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

    protected function register_controls_section(){

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // rr_section_title
        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1','layout-2']);



        // Team Extra Info
        $this->start_controls_section(
            'rr_info_sec',
            [
                'label' => esc_html__('Team Extra Info', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_team_bio',
            [
                'label' => esc_html__('Bio', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('bio', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_thumbnail_image',
            [
                'label' => esc_html__( 'Choose Member Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );


        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_thumbnail_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->add_control(
            'rr_team_phone',
            [
                'label' => esc_html__('Phone', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('+880 17823-63794', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_team_phone_url',
            [
                'label' => esc_html__('Phone Url', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('+8801782363794', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_team_email',
            [
                'label' => esc_html__('Email', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('info@themepure.com', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_team_email_url',
            [
                'label' => esc_html__('Email Url', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('info@themepure.com', 'rr-core'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'rr_team_website',
            [
                'label' => esc_html__('Website', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('rrdevs.net', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_team_website_url',
            [
                'label' => esc_html__('Website Url', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('#', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();
        
        $this->start_controls_section(
            '_section_social',
            [
                'label' => esc_html__('Social Profiles', 'tpcore'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_profiles',
            [
                'label' => esc_html__('Show Profiles', 'tpcore'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'tpcore'),
                'label_off' => esc_html__('Hide', 'tpcore'),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
                'style_transfer' => true,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'name',
            [
                'label' => esc_html__('Profile Name', 'tpcore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'select2options' => [
                    'allowClear' => false,
                ],
                'options' => self::get_profile_names()
            ]
        );

        $repeater->add_control(
            'link', [
                'label' => esc_html__('Profile Link', 'tpcore'),
                'placeholder' => esc_html__('Add your profile link', 'tpcore'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'autocomplete' => false,
                'show_external' => false,
                'condition' => [
                    'name!' => 'email'
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );
        $this->add_control(
            'profiles',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(name.slice(0,1).toUpperCase() + name.slice(1)) #>',
                'default' => [
                    [
                        'link' => ['url' => 'https://facebook.com/'],
                        'name' => 'facebook'
                    ],
                    [
                        'link' => ['url' => 'https://linkedin.com/'],
                        'name' => 'linkedin'
                    ],
                    [
                        'link' => ['url' => 'https://twitter.com/'],
                        'name' => 'twitter'
                    ]
                ],
            ]
        );
        $this->end_controls_section();
     
    }

    protected function style_tab_content(){
        $this->rr_section_style_controls('comint_section', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('team_title', 'Team Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('team_desc', 'Team Description', '.rr-el-re-dec');
        $this->rr_basic_style_controls('section_bio', 'Section - Bio', '.rr-el-bio');
        $this->rr_basic_style_controls('team_desc_rep', 'Team Rep', '.rr-el-re');
        $this->rr_basic_style_controls('team_desc_rep_sub', 'Team Sub Title', '.rr-el-re-title');
    }

    /**
     * Render the widget ourrut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>


<?php if ( $settings['rr_design_style']  == 'layout-2' ) : ?>



<?php else :
    // thumbnail image
    if ( !empty($settings['rr_thumbnail_image']['url']) ) {
        $rr_thumbnail_image = !empty($settings['rr_thumbnail_image']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image']['url'];
        $rr_thumbnail_image_alt = get_post_meta($settings["rr_thumbnail_image"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_thumbnail_image_2']['url']) ) {
        $rr_thumbnail_image_2 = !empty($settings['rr_thumbnail_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image_2']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image_2']['url'];
        $rr_thumbnail_image_2_alt = get_post_meta($settings["rr_thumbnail_image_2"]["id"], "_wp_attachment_image_alt", true);
    }
    $this->add_render_attribute('title_args', 'class', 'rr-team-details-title rr-el-title');  
?>
<section class="main-team-details__area rr-el-section">
    <div class="container">
        <div class="row">
            <div class="col-xl-5 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="main-team-details__first-img">
                    <?php  if ( !empty($rr_thumbnail_image) ) : ?>
                    <img src="<?php echo esc_url($rr_thumbnail_image); ?>"
                        alt="<?php echo esc_attr($rr_thumbnail_image_alt); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-7 col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="main-team-details__content">
                    <div class="main-team-details__content-title mb-30">
                        <?php if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s data-wow-duration=".9s"
                        data-wow-delay=".5s" >%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        );
                    endif;  ?>
                        <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                        <p class="rr-el-sub-title"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="main-team-details__content-thumb">
                    <?php if ( !empty($settings['rr_team_bio']) ) : ?>
                        <h4 class="rr-el-bio"><?php echo rr_kses( $settings['rr_team_bio']);?></h4>
                    <?php endif; ?>
                        <?php if ( !empty($settings['rr_section_description']) ) : ?>
                        <p class="rr-el-re-dec"><?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
                        <?php endif; ?>
                        <ul class="personal-info__list mt-30 mb-35">
                            <?php  if ( !empty($settings['rr_team_phone']) ) : ?>
                            <li class="mb-15 rr-el-re"><span>Phone:</span> <a
                                    href="tel:<?php echo esc_attr( $settings['rr_team_phone_url'] ); ?>"
                                    class="number rr-el-re-title"><?php echo rr_kses( $settings['rr_team_phone'] ); ?></a></li>
                            <?php endif; ?>
                            <?php  if ( !empty($settings['rr_team_email']) ) : ?>
                            <li class="mb-15 rr-el-re"><span>Email:</span> <a
                                    href="mailto:<?php echo esc_attr( $settings['rr_team_email_url'] ); ?>"
                                    class="email rr-el-re-title"><?php echo rr_kses( $settings['rr_team_email'] ); ?></a></li>
                            <?php endif; ?>
                            <?php  if ( !empty($settings['rr_team_email']) ) : ?>
                            <li><span class="rr-el-re">Website:</span> <a href="<?php echo esc_url($settings['rr_team_website_url']);?>"
                                    class="website rr-el-re-title"><?php echo rr_kses($settings['rr_team_website']);?></a></li>
                            <?php endif; ?>
                        </ul>
                        <div class="main-team-details__content-thumb-btn d-flex">

                            <?php
                                foreach ($settings['profiles'] as $profile) :
                                    $icon = $profile['name'];
                                    $url = esc_url($profile['link']['url']);
                                    
                                    printf('<a target="_blank" rel="noopener"  href="%s" ><i class="fa-brands fa-%s"></i></a>',
                                        $url,
                                        esc_attr($icon)
                                    );
                                endforeach; 
                            ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- team details area srat -->

<?php endif; 
    }
}

$widgets_manager->register( new rr_Team_Details() );