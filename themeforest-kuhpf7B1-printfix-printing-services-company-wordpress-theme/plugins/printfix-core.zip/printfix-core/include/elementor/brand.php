<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;
use RRCore\Elementor\Controls\Group_Control_RRBGGradient;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world. 
 *
 * @since 1.0.0
 */
class rr_Main_Brand extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-brand';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Brand', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }   


	protected function register_controls_section() {

    $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',$control_condition = ['layout-1', 'layout-2', 'layout-4']);

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // brand section
		$this->start_controls_section( 
            'rr_brand_section',
            [
                'label' => __( 'Brand Item', 'rr-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'rr_design_style' => ['layout-1', 'layout-2', 'layout-4']
                ]
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );
        
        $repeater->add_control(
            'rr_brand_image',
            [
                'type' => Controls_Manager::MEDIA,
                'label' => __( 'Image', 'rr-core' ),
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $this->add_control(
            'rr_brand_slides',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => esc_html__( 'Brand Item', 'rr-core' ),
                'default' => [
                    [
                        'rr_brand_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'rr_brand_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail',
                'default' => 'medium_large',
                'separator' => 'before',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->end_controls_section();
        // brand section
		$this->start_controls_section( 
            'rr_brand_text_section',
            [
                'label' => __( 'Brand Item', 'rr-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,  
                'condition' => [
                    'rr_design_style' => ['layout-2', 'layout-3']
                ]
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'repeater_condition_text',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );
        

        $repeater->add_control(
            'rr_box_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'RRcore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'RRcore'),
                    'icon' => esc_html__('Icon', 'RRcore'),
                    'svg' => esc_html__('SVG', 'RRcore'),
                ],
            ]
        );

        $repeater->add_control(
            'rr_box_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'RRcore'),
                'condition' => [
                    'rr_box_icon_type' => 'svg',
                ]
            ]
        );

        $repeater->add_control(
            'rr_box_icon_image',
            [
                'label' => esc_html__('Upload Icon Image', 'RRcore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_box_icon_type' => 'image',
                ]
            ]
        );

        if (rr_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'rr_box_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_box_icon_type' => 'icon',
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'rr_box_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_box_icon_type' => 'icon',
                    ]
                ]
            );
        }

        $repeater->add_control(
            'rr_brand_title_rep', [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_brand_slides_text',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => esc_html__( 'Brand Item', 'rr-core' ),
                'default' => [
                    [
                        'rr_brand_image_text' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'rr_brand_image_text' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                    ],
                ]
            ]
        );

        $this->end_controls_section();

    
	}


    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('section_section', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('heading_title', 'Section - Title', '.rr-el-title');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
<?php if ( $settings['rr_design_style']  == 'layout-2' ) : 
    $this->add_render_attribute('title_args', 'class', 'partners__title-wrapper-title rr-el-title');
?>
<!--partners-area start -->
<section class="partners__area section-space position-relative">
    <div class="container-fluid overflow-hidden">
        <div class="row">
            <div class="col-12">
                <div class="partners__title-wrapper text-center">
                    <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h6 class="partners__title-wrapper-subtitle rr-el-subtitle" data-wow-duration=".9s"
                        data-wow-delay=".5s"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?></h6>
                    <?php endif; ?>
                    <?php
                    if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        );
                    endif;
                    ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="slick marquee mt-40">
                    <?php foreach ($settings['rr_brand_slides'] as $item) :
                                if ( !empty($item['rr_brand_image']['url']) ) {
                                    $rr_brand_image_url = !empty($item['rr_brand_image']['id']) ? wp_get_attachment_image_url( $item['rr_brand_image']['id'], $settings['thumbnail_size']) : $item['rr_brand_image']['url'];
                                    $rr_brand_image_alt = get_post_meta($item["rr_brand_image"]["id"], "_wp_attachment_image_alt", true);
                                }
                            ?>
                    <div class="slick-slide">
                        <div class="inner">
                            <img src="<?php echo esc_url($rr_brand_image_url); ?>"
                                alt="<?php echo esc_attr($rr_brand_image_alt); ?>">
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div dir="rtl">
                    <div class="slick marquee_rtl mt-30">
                        <?php foreach ($settings['rr_brand_slides'] as $item) :
                                if ( !empty($item['rr_brand_image']['url']) ) {
                                    $rr_brand_image_url = !empty($item['rr_brand_image']['id']) ? wp_get_attachment_image_url( $item['rr_brand_image']['id'], $settings['thumbnail_size']) : $item['rr_brand_image']['url'];
                                    $rr_brand_image_alt = get_post_meta($item["rr_brand_image"]["id"], "_wp_attachment_image_alt", true);
                                }
                            ?>
                        <div class="slick-slide">
                            <div class="inner">
                                <img src="<?php echo esc_url($rr_brand_image_url); ?>"
                                    alt="<?php echo esc_attr($rr_brand_image_alt); ?>">
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--partners-area end -->
<?php elseif ( $settings['rr_design_style']  == 'layout-3' ) : 
    $this->add_render_attribute('title_args', 'class', 'partners__title-wrapper-title rr-el-title');
?>
<section class="text-brand__area rr-el-section">
    <div class="text-brand__wrapper pt-80 pb-80">
        <div class="container">
            <div class="row mb-minus-30">
            <?php foreach ($settings['rr_brand_slides_text'] as $item) :
                if ( !empty($item['rr_brand_image']['url']) ) {
                    $rr_brand_image_url = !empty($item['rr_brand_image']['id']) ? wp_get_attachment_image_url( $item['rr_brand_image']['id'], $settings['thumbnail_size']) : $item['rr_brand_image']['url'];
                    $rr_brand_image_alt = get_post_meta($item["rr_brand_image"]["id"], "_wp_attachment_image_alt", true);
                }
            ?>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="text-brand__wrapper-text mb-30">
                        <h5 class="rr-el-title">
                        <?php if($item['rr_box_icon_type'] == 'icon') : ?>
                            <?php if (!empty($item['rr_box_icon']) || !empty($item['rr_box_selected_icon']['value'])) : ?>
                            <?php rr_render_icon($item, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                            <?php endif; ?>
                            <?php elseif( $item['rr_box_icon_type'] == 'image' ) : ?>
                            <?php if (!empty($item['rr_box_icon_image']['url'])): ?>
                            <img src="<?php echo $item['rr_box_icon_image']['url']; ?>"
                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                            <?php endif; ?>
                            <?php else : ?>
                            <?php if (!empty($item['rr_box_icon_svg'])): ?>
                            <?php echo $item['rr_box_icon_svg']; ?>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php echo rr_kses($item['rr_brand_title_rep']); ?></h5>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-4' ) : 
    $this->add_render_attribute('title_args', 'class', 'partners__title-wrapper-title rr-el-title');
?>
<!-- Brand area start -->
<section class="main-brand__area rr-el-section">
    <div class="brand__area section-space">
        <div class="container custom-container">
            <div class="row">
                <div class="main-brand__tittle-wrapper text-center mb-40">
                    <?php
                    if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        );
                    endif;
                    ?>
                    <?php if ( !empty($settings['rr_section_description']) ) : ?>
                    <p class="main-brand__tittle-wrapper-subtitle rr-el-content">
                        <?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="swiper brand__active wow fadeIn" data-wow-delay=".3s">
                        <div class="swiper-wrapper">
                            <?php foreach ($settings['rr_brand_slides'] as $item) :
                                if ( !empty($item['rr_brand_image']['url']) ) {
                                    $rr_brand_image_url = !empty($item['rr_brand_image']['id']) ? wp_get_attachment_image_url( $item['rr_brand_image']['id'], $settings['thumbnail_size']) : $item['rr_brand_image']['url'];
                                    $rr_brand_image_alt = get_post_meta($item["rr_brand_image"]["id"], "_wp_attachment_image_alt", true);
                                }
                            ?>
                            <div class="swiper-slide">
                                <div class="brand__item text-center  wow fadeIn animated" data-wow-delay=".1s">
                                    <div class="brand__thumb">
                                        <img src="<?php echo esc_url($rr_brand_image_url); ?>"
                                            alt="<?php echo esc_attr($rr_brand_image_alt); ?>">
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Brand area end -->
<?php else :
if ( !empty($settings['rr_brand_bg_image']['url']) ) {
    $rr_brand_bg_image_url = !empty($settings['rr_brand_bg_image']['id']) ? wp_get_attachment_image_url( $settings['rr_brand_bg_image']['id'], $settings['thumbnail_size']) : $settings['rr_brand_bg_image']['url'];
    $rr_brand_bg_image_alt = get_post_meta($settings["rr_brand_bg_image"]["id"], "_wp_attachment_image_alt", true);
}
$this->add_render_attribute('title_args', 'class', 'main-brand__tittle-wrapper-title rr-el-title');
?>
<!-- Brand area start -->
<section class="main-brand__area rr-el-section">
    <div class="brand__area section-space">
        <div class="container">
            <div class="row">
                <div class="main-brand__tittle-wrapper text-center mb-40">
                    <?php
                    if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        );
                    endif;
                    ?>
                    <?php if ( !empty($settings['rr_section_description']) ) : ?>
                    <p class="main-brand__tittle-wrapper-subtitle rr-el-content">
                        <?php echo rr_kses( $settings['rr_section_description'] ); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="swiper brand__active wow fadeIn" data-wow-delay=".3s">
                        <div class="swiper-wrapper">
                            <?php foreach ($settings['rr_brand_slides'] as $item) :
                                if ( !empty($item['rr_brand_image']['url']) ) {
                                    $rr_brand_image_url = !empty($item['rr_brand_image']['id']) ? wp_get_attachment_image_url( $item['rr_brand_image']['id'], $settings['thumbnail_size']) : $item['rr_brand_image']['url'];
                                    $rr_brand_image_alt = get_post_meta($item["rr_brand_image"]["id"], "_wp_attachment_image_alt", true);
                                }
                            ?>
                            <div class="swiper-slide">
                                <div class="brand__item text-center  wow fadeIn animated" data-wow-delay=".1s">
                                    <div class="brand__thumb">
                                        <img src="<?php echo esc_url($rr_brand_image_url); ?>"
                                            alt="<?php echo esc_attr($rr_brand_image_alt); ?>">
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Brand area end -->
<?php endif;  
	}
}

$widgets_manager->register( new rr_Main_Brand() );