<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class RR_Features extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr_features';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Features', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
     
    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                    'layout-4' => esc_html__('Layout 4', 'rr-core'),
                    'layout-5' => esc_html__('Layout 5', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        
        // title/content
        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.' );

        // Features group
        $this->start_controls_section(
            'rr_features',
            [
                'label' => esc_html__('Features List', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'rr_features_number', [
                'label' => esc_html__('Item Number', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('1', 'rr-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'rr_features_main_image',
            [
                'label' => esc_html__('Upload Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ]

            ]
        );

        $repeater->add_control(
            'rr_features_title', [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'rr-core'),
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'rr_features_description',
            [
                'label' => esc_html__('Description', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered.',
                'label_block' => true,
            ]
        );
        

        $repeater->add_control(
            'rr_features_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'rr-core' ),
                'label_off' => esc_html__( 'No', 'rr-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $repeater->add_control(
            'rr_features_btn_text',
            [
                'label' => esc_html__('Button Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'rr-core'),
                'title' => esc_html__('Enter button text', 'rr-core'),
                'label_block' => true,
                'condition' => [
                    'rr_features_link_switcher' => 'yes',
                ],
            ]
        );
        $repeater->add_control(
            'rr_features_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'rr_features_link_switcher' => 'yes'
                ]
            ]
        );

        $repeater->add_control(
            'rr_features_link',
            [
                'label' => esc_html__( 'Service Link link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htRRs://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'rr_features_link_type' => '1',
                    'rr_features_link_switcher' => 'yes',
                ]
            ]
        );

        $repeater->add_control(
            'rr_features_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => rr_get_all_pages(),
                'condition' => [
                    'rr_features_link_type' => '2',
                    'rr_features_link_switcher' => 'yes',
                ]
            ]
        );
        
        // creative animation
        $repeater->add_control(
			'rr_creative_anima_switcher',
			[
				'label' => esc_html__( 'Active Animation', 'rr-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'rr-core   ' ),
				'label_off' => esc_html__( 'No', 'rr-core   ' ),
				'return_value' => 'yes',
				'default' => '0',
                'separator' => 'before',
                'condition' => [
                    'repeater_condition' => ['style_1']
                ]
			]
		);

        $repeater->add_control(
            'rr_anima_type',
            [
                'label' => __( 'Animation Type', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'fadeInUp' => __( 'fadeInUp', 'rr-core' ),
                    'fadeInDown' => __( 'fadeInDown', 'rr-core' ),
                    'fadeInLeft' => __( 'fadeInLeft', 'rr-core' ),
                    'fadeInRight' => __( 'fadeInRight', 'rr-core' ),
                ],
                'default' => 'fadeInUp',
                'frontend_available' => true,
                'style_transfer' => true,
                'condition' => [
                    'rr_creative_anima_switcher' => 'yes',
                    'repeater_condition' => ['style_1']
                ],
            ]
        );
        
        $repeater->add_control(
            'rr_anima_dura', [
                'label' => esc_html__('Animation Duration', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('0.3s', 'rr-core'),
                'condition' => [
                    'rr_creative_anima_switcher' => 'yes',
                    'repeater_condition' => ['style_1']
                ],
            ]
        );
        
        $repeater->add_control(
            'rr_anima_delay', [
                'label' => esc_html__('Animation Delay', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('0.6s', 'rr-core'),
                'condition' => [
                    'rr_creative_anima_switcher' => 'yes',
                    'repeater_condition' => ['style_1']
                ],
            ]
        );

        $this->add_control(
            'rr_features_list',
            [
                'label' => esc_html__('Services - List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_features_title' => esc_html__('Discover', 'rr-core'),
                    ],
                    [
                        'rr_features_title' => esc_html__('Define', 'rr-core')
                    ],
                    [
                        'rr_features_title' => esc_html__('Develop', 'rr-core')
                    ]
                ],
                'title_field' => '{{{ rr_features_title }}}',
            ]
        );
        $this->end_controls_section();
    
        // section column
        $this->rr_columns('col');

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('features_section', 'Section - Style', '.rr-el-section'); 
        $this->rr_basic_style_controls('features_title', 'Features Title', '.rr-el-re-Title');
        $this->rr_link_controls_style('repiter_btn', 'Features - Number', '.rr-el-btn');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ) : 
?>
<section class="latest-feature2__area rr-el-section">
    <div class="container">
        <div class="row mb-minus-30">
            <?php foreach ($settings['rr_features_list'] as $key => $item) :
                // Link
                if ('2' == $item['rr_features_link_type']) {
                    $link = get_permalink($item['rr_features_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['rr_features_link']['url']) ? $item['rr_features_link']['url'] : '';
                    $target = !empty($item['rr_features_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['rr_features_link']['nofollow']) ? 'nofollow' : '';
                }

                // thumbnail image
                if ( !empty($item['rr_features_main_image']['url']) ) {
                    $rr_features_main_image = !empty($item['rr_features_main_image']['id']) ? wp_get_attachment_image_url( $item['rr_features_main_image']['id'], 'full' ) : $item['rr_features_main_image']['url'];
                    $rr_features_main_image_alt = get_post_meta($item["rr_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                }
            ?>
            <div
                class="col-xl-<?php echo esc_attr($settings['rr_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['rr_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['rr_col_for_tablet']); ?> col-<?php echo esc_attr($settings['rr_col_for_mobile']); ?>">
                <div class="latest-feature2__media mb-30">
                    <div class="overlay"></div>
                    <span class="number-top rr-el-btn"><?php echo rr_kses($item['rr_features_number']); ?></span>
                    <div class="overlay-heading"><a href="<?php echo esc_url($link); ?>">
                            <h6 class="rr-el-re-Title"><?php echo rr_kses($item['rr_features_title' ]); ?></h6>
                        </a></div>
                    <div class="latest-feature2-thumb">
                        <?php if(!empty($rr_features_main_image)) : ?>
                        <img class="thumb" src="<?php echo esc_url($rr_features_main_image); ?>"
                            alt="<?php echo esc_attr($rr_features_main_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-3' ) : 
?>
<section class="services-5__area section-space position-relative rr-el-section">
    <div class="container custom-container">
        <div class="swiper services-5__active">
            <div class="swiper-wrapper">
                <?php foreach ($settings['rr_features_list'] as $key => $item) :
                    // Link
                    if ('2' == $item['rr_features_link_type']) {
                        $link = get_permalink($item['rr_features_page_link']);
                        $target = '_self';
                        $rel = 'nofollow';
                    } else {
                        $link = !empty($item['rr_features_link']['url']) ? $item['rr_features_link']['url'] : '';
                        $target = !empty($item['rr_features_link']['is_external']) ? '_blank' : '';
                        $rel = !empty($item['rr_features_link']['nofollow']) ? 'nofollow' : '';
                    }
                    // thumbnail image
                    if ( !empty($item['rr_features_main_image']['url']) ) {
                        $rr_features_main_image = !empty($item['rr_features_main_image']['id']) ? wp_get_attachment_image_url( $item['rr_features_main_image']['id'], 'full' ) : $item['rr_features_main_image']['url'];
                        $rr_features_main_image_alt = get_post_meta($item["rr_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                    }
                ?>
                <div class="swiper-slide">
                    <div class="services-1__item">
                        <div class="services__item__thumb-border">
                            <div class="services__item__thumb">
                                <?php if(!empty($rr_features_main_image)) : ?>
                                <img class="thumb" src="<?php echo esc_url($rr_features_main_image); ?>"
                                    alt="<?php echo esc_attr($rr_features_main_image_alt); ?>">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="services__item__text text-center">
                            <h4 class="services__item__title rr-el-re-Title"><a
                                    href="<?php echo esc_url($link); ?>"><?php echo rr_kses($item['rr_features_title' ]); ?></a>
                            </h4>
                            <span><?php echo rr_kses($item['rr_features_number']); ?></span>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

        </div>
    </div>
    <!-- If we need navigation buttons -->
    <div class="banner__navigation banner__navigation-3 services-5__navigation d-none d-lg-block">
        <button class="banner__button-next services-5__button services-5__button-next">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M19 10H1" stroke="#001D08" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                <path d="M10 1L1 10L10 19" stroke="#001D08" stroke-width="2" stroke-linecap="round"
                    stroke-linejoin="round" />
            </svg>
        </button>
        <button class="banner__button-prev services-5__button services-5__button-prev">
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1 10H19" stroke="#001D08" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                <path d="M10 1L19 10L10 19" stroke="#001D08" stroke-width="2" stroke-linecap="round"
                    stroke-linejoin="round" />
            </svg>
        </button>

    </div>
</section>
<?php elseif ( $settings['rr_design_style']  == 'layout-4' ) : ?>
<section class="feature4__area section-space">
    <div class="container custom-container">
        <div class="row mb-minus-30">
            <?php foreach ($settings['rr_features_list'] as $key => $item) :
                // Link
                if ('2' == $item['rr_features_link_type']) {
                    $link = get_permalink($item['rr_features_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['rr_features_link']['url']) ? $item['rr_features_link']['url'] : '';
                    $target = !empty($item['rr_features_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['rr_features_link']['nofollow']) ? 'nofollow' : '';
                }

                // thumbnail image
                if ( !empty($item['rr_features_main_image']['url']) ) {
                    $rr_features_main_image = !empty($item['rr_features_main_image']['id']) ? wp_get_attachment_image_url( $item['rr_features_main_image']['id'], 'full' ) : $item['rr_features_main_image']['url'];
                    $rr_features_main_image_alt = get_post_meta($item["rr_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                }
            ?>
            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="feature4__item mb-30 wow fadeInLeft animated" data-wow-delay=".1s">
                    <div class="icon">
                        <?php if(!empty($rr_features_main_image)) : ?>
                        <img class="thumb" src="<?php echo esc_url($rr_features_main_image); ?>"
                            alt="<?php echo esc_attr($rr_features_main_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                    <?php if ( !empty($item['rr_features_title']) ) : ?>
                    <h3 class="title rr-el-re-Title"><?php echo rr_kses($item['rr_features_title' ]); ?></h3>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php elseif ( $settings['rr_design_style']  == 'layout-5' ) : ?>

<section class="rr-brand-5__area section-space-top rr-el-section">
    <div class="container custom-container">
        <div class="rr-brand-5__border">
            <div class="row row-cols-xl-4 row-cols-lg-3 row-cols-md-2 row-cols-1 row-cols-sm-2">
                <?php foreach ($settings['rr_features_list'] as $key => $item) :
                        // Link
                        if ('2' == $item['rr_features_link_type']) {
                            $link = get_permalink($item['rr_features_page_link']);
                            $target = '_self';
                            $rel = 'nofollow';
                        } else {
                            $link = !empty($item['rr_features_link']['url']) ? $item['rr_features_link']['url'] : '';
                            $target = !empty($item['rr_features_link']['is_external']) ? '_blank' : '';
                            $rel = !empty($item['rr_features_link']['nofollow']) ? 'nofollow' : '';
                        }

                        // thumbnail image
                        if ( !empty($item['rr_features_main_image']['url']) ) {
                            $rr_features_main_image = !empty($item['rr_features_main_image']['id']) ? wp_get_attachment_image_url( $item['rr_features_main_image']['id'], 'full' ) : $item['rr_features_main_image']['url'];
                            $rr_features_main_image_alt = get_post_meta($item["rr_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                        }
                    ?>
                <div class="col">
                    <div class="rr-brand-5__item-box d-flex align-items-center wow fadeInLeft animated"
                        data-wow-delay=".1s">
                        <div class="rr-brand-3__icon">
                            <span class="rr-el-rep-icon">
                                <?php if(!empty($rr_features_main_image)) : ?>
                                <img src="<?php echo esc_url($rr_features_main_image); ?>"
                                    alt="<?php echo esc_attr($rr_features_main_image_alt); ?>">
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="rr-brand-3__text">
                            <?php if ( !empty($item['rr_features_title']) ) : ?>
                            <h5 class="rr-el-rep-title rr-el-re-Title"> <?php echo rr_kses($item['rr_features_title' ]); ?></h5>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
<?php else: 

    // shape image
    if ( !empty($settings['rr_shape_image_1']['url']) ) {
        $rr_shape_image = !empty($settings['rr_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['rr_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['rr_shape_image_1']['url'];
        $rr_shape_image_alt = get_post_meta($settings["rr_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
    }

    $this->add_render_attribute('title_args', 'class', 'rr-section-title'); 
?>
<section class="latest-feature2__area rr-el-section">
    <div class="container">
        <div class="row mb-minus-30">
            <?php foreach ($settings['rr_features_list'] as $key => $item) :
                // Link
                if ('2' == $item['rr_features_link_type']) {
                    $link = get_permalink($item['rr_features_page_link']);
                    $target = '_self';
                    $rel = 'nofollow';
                } else {
                    $link = !empty($item['rr_features_link']['url']) ? $item['rr_features_link']['url'] : '';
                    $target = !empty($item['rr_features_link']['is_external']) ? '_blank' : '';
                    $rel = !empty($item['rr_features_link']['nofollow']) ? 'nofollow' : '';
                }

                // thumbnail image
                if ( !empty($item['rr_features_main_image']['url']) ) {
                    $rr_features_main_image = !empty($item['rr_features_main_image']['id']) ? wp_get_attachment_image_url( $item['rr_features_main_image']['id'], 'full' ) : $item['rr_features_main_image']['url'];
                    $rr_features_main_image_alt = get_post_meta($item["rr_features_main_image"]["id"], "_wp_attachment_image_alt", true);
                }
            ?>
            <div
                class="col-xl-<?php echo esc_attr($settings['rr_col_for_desktop']); ?> col-lg-<?php echo esc_attr($settings['rr_col_for_laptop']); ?> col-md-<?php echo esc_attr($settings['rr_col_for_tablet']); ?> col-<?php echo esc_attr($settings['rr_col_for_mobile']); ?>">
                <div class="latest-feature2__media mb-30">
                    <div class="overlay"></div>
                    <?php if ( !empty($item['rr_features_number']) ) : ?>
                    <span class="number-top rr-el-btn"><?php echo rr_kses($item['rr_features_number']); ?></span>
                    <?php endif; ?>
                    <?php if ( !empty($item['rr_features_title']) ) : ?>
                    <div class="overlay-heading"><a href="<?php echo esc_url($link); ?>">
                            <h6 class="rr-el-re-Title"><?php echo rr_kses($item['rr_features_title' ]); ?></h6>
                        </a></div>
                    <?php endif; ?>
                    <div class="latest-feature2-thumb">
                        <?php if(!empty($rr_features_main_image)) : ?>
                        <img src="<?php echo esc_url($rr_features_main_image); ?>"
                            alt="<?php echo esc_attr($rr_features_main_image_alt); ?>">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php endif;
	}
}

$widgets_manager->register( new RR_Features() );