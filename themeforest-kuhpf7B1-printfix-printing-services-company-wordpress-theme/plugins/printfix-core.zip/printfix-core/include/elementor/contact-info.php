<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Contact_Info extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-contact-info';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Contact Info', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

    public function get_rr_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $rr_cfa         = array();
        $rr_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $rr_forms       = get_posts( $rr_cf_args );
        $rr_cfa         = ['0' => esc_html__( 'Select Form', 'rr-core' ) ];
        if( $rr_forms ){
            foreach ( $rr_forms as $rr_form ){
                $rr_cfa[$rr_form->ID] = $rr_form->post_title;
            }
        }else{
            $rr_cfa[ esc_html__( 'No contact form found', 'rr-core' ) ] = 0;
        }
        return $rr_cfa;
    }
  /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */


    protected static function get_profile_names()
    {
        return [
            'apple' => esc_html__('Apple', 'rr-core'),
            'behance' => esc_html__('Behance', 'rr-core'),
            'bitbucket' => esc_html__('BitBucket', 'rr-core'),
            'codepen' => esc_html__('CodePen', 'rr-core'),
            'delicious' => esc_html__('Delicious', 'rr-core'),
            'deviantart' => esc_html__('DeviantArt', 'rr-core'),
            'digg' => esc_html__('Digg', 'rr-core'),
            'dribbble' => esc_html__('Dribbble', 'rr-core'),
            'email' => esc_html__('Email', 'rr-core'),
            'facebook-f' => esc_html__('Facebook', 'rr-core'),
            'flickr' => esc_html__('Flicker', 'rr-core'),
            'foursquare' => esc_html__('FourSquare', 'rr-core'),
            'github' => esc_html__('Github', 'rr-core'),
            'houzz' => esc_html__('Houzz', 'rr-core'),
            'instagram' => esc_html__('Instagram', 'rr-core'),
            'jsfiddle' => esc_html__('JS Fiddle', 'rr-core'),
            'linkedin-in' => esc_html__('LinkedIn', 'rr-core'),
            'medium' => esc_html__('Medium', 'rr-core'),
            'pinterest' => esc_html__('Pinterest', 'rr-core'),
            'product-hunt' => esc_html__('Product Hunt', 'rr-core'),
            'reddit' => esc_html__('Reddit', 'rr-core'),
            'slideshare' => esc_html__('Slide Share', 'rr-core'),
            'snapchat' => esc_html__('Snapchat', 'rr-core'),
            'soundcloud' => esc_html__('SoundCloud', 'rr-core'),
            'spotify' => esc_html__('Spotify', 'rr-core'),
            'stack-overflow' => esc_html__('StackOverflow', 'rr-core'),
            'tripadvisor' => esc_html__('TripAdvisor', 'rr-core'),
            'tumblr' => esc_html__('Tumblr', 'rr-core'),
            'twitch' => esc_html__('Twitch', 'rr-core'),
            'twitter' => esc_html__('Twitter', 'rr-core'),
            'vimeo' => esc_html__('Vimeo', 'rr-core'),
            'vk' => esc_html__('VK', 'rr-core'),
            'website' => esc_html__('Website', 'rr-core'),
            'whatsapp' => esc_html__('WhatsApp', 'rr-core'),
            'wordpress' => esc_html__('WordPress', 'rr-core'),
            'xing' => esc_html__('Xing', 'rr-core'),
            'yelp' => esc_html__('Yelp', 'rr-core'),
            'youtube' => esc_html__('YouTube', 'rr-core'),
            'tiktok' => esc_html__('Tiktok', 'rr-core'),
        ];
    }

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }


	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'rr-core_contact',
            [
                'label' => esc_html__('Contact Form', 'rr-core'),
                'condition' => [
                    'rr_design_style' => 'layout-2'
                ]
            ]
        );

        $this->add_control(
            'rr-core_select_contact_form',
            [
                'label'   => esc_html__( 'Select Form', 'rr-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '0',
                'options' => $this->get_rr_contact_form(),
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'rr-core_contact_info_text',
            [
                'label' => esc_html__('Info Text', 'rr-core'),
                'condition' => [
                    'rr_design_style' => 'layout-2'
                ]
            ]
        );

        $this->add_control(
            'core_contact_info_text_title',
            [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Title Here',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'core_contact_info_text_desc',
            [
                'label' => esc_html__('Description', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Title Here',
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        $this->rr_section_title_render_controls('contact', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.', ['layout-1', 'layout-2']);

        // Service group
        $this->start_controls_section(
            '_rr_contact_info',
            [
                'label' => esc_html__('Contact  List', 'rr-core'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'rr-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'repeater_condition',
            [
                'label' => __( 'Field condition', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'rr-core' ),
                ],
                'default' => 'style_1',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'rr_box_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'rr-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'rr-core'),
                    'icon' => esc_html__('Icon', 'rr-core'),
                    'svg' => esc_html__('SVG', 'rr-core'),
                ],

            ]
        );
        $repeater->add_control(
            'rr_box_icon_svg',
            [
                'show_label' => false,
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
                'placeholder' => esc_html__('SVG Code Here', 'rr-core'),
                'condition' => [
                    'rr_box_icon_type' => 'svg'
                ]
            ]
        );

        $repeater->add_control(
            'rr_box_icon_image',
            [
                'label' => esc_html__('Upload Icon Image', 'rr-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'rr_box_icon_type' => 'image',
                ]
            ]
        );

        if (rr_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'rr_box_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'fa fa-star',
                    'condition' => [
                        'rr_box_icon_type' => 'icon'
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'rr_box_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'rr_box_icon_type' => 'icon'
                    ]
                ]
            );
        }

        $repeater->add_control(
            'rr_contact_info_title',
            [
                'label' => esc_html__('Title', 'rr-core'),
                'description' => rr_get_allowed_html_desc( 'intermediate' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Title Here',
                'label_block' => true,
            ]
        );


        $repeater->add_control(
            'link_type',
            [
                'label' => __( 'Link Type', 'rr-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'text' => __( 'Text', 'rr-core' ),
                    'url' => __( 'URL', 'rr-core' ),
                    'tell' => __( 'Phone Number', 'rr-core' ),
                    'email' => __( 'Email', 'rr-core' ),
                ],
                'default' => '',
                'frontend_available' => true,
                'style_transfer' => true,
            ]
        );

        // url
        $repeater->add_control(
            'rr_contact_url',
            [
                'label' => esc_html__('URL', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '#',
                'label_block' => true,
                'condition' => [
                    'link_type' => 'url'
                ]
            ]
        );

        // tell
        $repeater->add_control(
            'rr_contact_tell',
            [
                'label' => esc_html__('Phone Number', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '012345',
                'label_block' => true,
                'condition' => [
                    'link_type' => 'tell'
                ]
            ]
        );

        // email
        $repeater->add_control(
            'rr_contact_email',
            [
                'label' => esc_html__('Email Address', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('technix@gmail.com', 'rr-core'),
                'label_block' => true,
                'condition' => [
                    'link_type' => 'email'
                ]
            ]
        );
        // email
        $repeater->add_control(
            'rr_contact_text_label',
            [
                'label' => esc_html__('Label Text', 'rr-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Label Text', 'rr-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'rr_list',
            [
                'label' => esc_html__('Contact - List', 'rr-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'rr_contact_info_title' => esc_html__('united states', 'rr-core'),
                    ],
                    [
                        'rr_contact_info_title' => esc_html__('south Africa', 'rr-core')
                    ],
                    [
                        'rr_contact_info_title' => esc_html__('United Kingdom', 'rr-core')
                    ]
                ],
                'title_field' => '{{{ rr_contact_info_title }}}',
            ]
        );
        $this->end_controls_section();



        // Social Profiles
        $this->start_controls_section(
            '_section_social',
            [
                'label' => __('Social Profiles', 'rr-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'rr_design_style' => 'layout-2'
                ]
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'name',
            [
                'label' => __('Profile Name', 'rr-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'select2options' => [
                    'allowClear' => false,
                ],
                'options' => self::get_profile_names()
            ]
        );

        $repeater->add_control(
            'link', [
                'label' => __('Profile Link', 'rr-core'),
                'placeholder' => __('Add your profile link', 'rr-core'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'autocomplete' => false,
                'show_external' => false,
                'condition' => [
                    'name!' => 'email'
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'email', [
                'label' => __('Email Address', 'rr-core'),
                'placeholder' => __('Add your email address', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'input_type' => 'email',
                'condition' => [
                    'name' => 'email'
                ],
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'customize',
            [
                'label' => __('Want To Customize?', 'rr-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'rr-core'),
                'label_off' => __('No', 'rr-core'),
                'return_value' => 'yes',
                'style_transfer' => true,
            ]
        );

        $repeater->start_controls_tabs(
            '_tab_icon_colors',
            [
                'condition' => ['customize' => 'yes']
            ]
        );

        $repeater->start_controls_tab(
            '_tab_icon_normal',
            [
                'label' => __('Normal', 'rr-core'),
            ]
        );

        $repeater->add_control(
            'color',
            [
                'label' => __('Text Color', 'rr-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .latest-contact-us-2-media-content-social-icon > {{CURRENT_ITEM}}' => 'color: {{VALUE}}',
                ],
                'condition' => ['customize' => 'yes'],
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'border_color',
            [
                'label' => __('Border Color', 'rr-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .latest-contact-us-2-media-content-social-icon > {{CURRENT_ITEM}}' => 'border-color: {{VALUE}}',
                ],
                'condition' => ['customize' => 'yes'],
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'bg_color',
            [
                'label' => __('Background Color', 'rr-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .latest-contact-us-2-media-content-social-icon > {{CURRENT_ITEM}}' => 'background-color: {{VALUE}}',
                ],
                'condition' => ['customize' => 'yes'],
                'style_transfer' => true,
            ]
        );

        $repeater->end_controls_tab();
        $repeater->start_controls_tab(
            '_tab_icon_hover',
            [
                'label' => __('Hover', 'rr-core'),
            ]
        );

        $repeater->add_control(
            'hover_color',
            [
                'label' => __('Text Color', 'rr-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .latest-contact-us-2-media-content-social-icon > {{CURRENT_ITEM}}:hover, {{WRAPPER}} .latest-contact-us-2-media-content-social-icon > {{CURRENT_ITEM}}:focus' => 'color: {{VALUE}}',
                ],
                'condition' => ['customize' => 'yes'],
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'hover_bg_color',
            [
                'label' => __('Background Color', 'rr-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .latest-contact-us-2-media-content-social-icon > {{CURRENT_ITEM}}:hover, {{WRAPPER}} .latest-contact-us-2-media-content-social-icon > {{CURRENT_ITEM}}:focus' => 'background-color: {{VALUE}}',
                ],
                'condition' => ['customize' => 'yes'],
                'style_transfer' => true,
            ]
        );

        $repeater->add_control(
            'hover_border_color',
            [
                'label' => __('Border Color', 'rr-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .latest-contact-us-2-media-content-social-icon > {{CURRENT_ITEM}}:hover, {{WRAPPER}} .latest-contact-us-2-media-content-social-icon > {{CURRENT_ITEM}}:focus' => 'border-color: {{VALUE}}',
                ],
                'condition' => ['customize' => 'yes'],
                'style_transfer' => true,
            ]
        );

        $repeater->end_controls_tab();
        $repeater->end_controls_tabs();

        $this->add_control(
            'profiles',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '<# print(name.slice(0,1).toUpperCase() + name.slice(1)) #>',
                'default' => [
                    [
                        'link' => ['url' => 'https://facebook.com/'],
                        'name' => 'facebook'
                    ],
                    [
                        'link' => ['url' => 'https://twitter.com/'],
                        'name' => 'twitter'
                    ],
                    [
                        'link' => ['url' => 'https://linkedin.com/'],
                        'name' => 'linkedin'
                    ]
                ],
            ]
        );

        $this->add_control(
            'show_profiles',
            [
                'label' => __('Show Profiles', 'rr-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'rr-core'),
                'label_off' => __('Hide', 'rr-core'),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
                'style_transfer' => true,
            ]
        );

        $this->end_controls_section();
	}

    // TAB_STYLE
    protected function style_tab_content(){
        $this->rr_section_style_controls('section_info', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('contact_subtitle', 'contact - Sub Title', '.rr-el-subtitle');
        $this->rr_basic_style_controls('contact_repeter_title', 'contact Repeter Title', '.rr-el-re-Title');
        $this->rr_basic_style_controls('contact_repeter_info_title', 'contact Repeter Info Title', '.rr-el-info-Title');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
        $this->add_render_attribute('title_args', 'class', 'latest-contact-us-2__title-wrapper-title wow fadeIn  animated rr-el-title');
		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ) : ?>
    <section class="latest-contact-us-2 section-space rr-el-section">
        <div class="container position-relative">
            <div class="latest-contact-us-2-all-shape">
                <div class="latest-contact-us-2-all-shape-circle-shape d-none d-xl-block">
                    <img src="<?php echo get_template_directory_uri(  ); ?>/assets/imgs/concact/circle.svg"
                        alt="img not found">
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <?php if ( !empty($settings['rr_contact_section_title_show']) ) : ?>
                    <div class="latest-contact-us-2__title-wrapper text-center mb-40 mb-sm-35 mb-xs-30">
                        <?php if ( !empty($settings['rr_contact_sub_title']) ) : ?>
                        <h6 class="latest-contact-us-2__title-wrapper-subtitle rr-el-subtitle">
                            <?php echo rr_kses( $settings['rr_contact_sub_title'] ); ?></h6>
                        <?php endif; ?>
                        <?php
                                if ( !empty($settings['rr_contact_title' ]) ) :
                                    printf( '<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape( $settings['rr_contact_title_tag'] ),
                                        $this->get_render_attribute_string( 'title_args' ),
                                        rr_kses( $settings['rr_contact_title' ] )
                                        );
                                endif;
                            ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row align-items-center box-shadow">
                <div class="col-lg-5">
                    <div class="latest-contact-us-2-media">
                        <div class="latest-contact-us-2-media-content latest-team-bg">
                            <div class="latest-contact-us-2-media-content-title pt-50">
                                <?php if ( !empty($settings['core_contact_info_text_desc']) ) : ?>
                                <h4><?php echo rr_kses($settings['core_contact_info_text_desc']);?></h4>
                                <?php endif; ?>
                                <?php if ( !empty($settings['core_contact_info_text_title']) ) : ?>
                                <p><?php echo rr_kses($settings['core_contact_info_text_title']);?></p>
                                <?php endif; ?>
                            </div>
                            <?php foreach ($settings['rr_list'] as $key => $item) :
                                $key = $key+1;

                                $link_type = $item['link_type'];
                                $url = $item['rr_contact_url'];
                                $tell = $item['rr_contact_tell'];
                                $email = $item['rr_contact_email'];

                                $contact_link;

                                if($link_type == 'url'){
                                    $contact_link = $url;
                                } elseif($link_type == 'tell'){
                                    $contact_link = 'tel:'.$tell;
                                } elseif($link_type == 'email'){
                                    $contact_link = 'mailto:'.$email;
                                }

                            ?>
                            <div class="latest-contact-us-2-media-content-contact">
                                <div class="latest-contact-us-2-media-content-contact-icon">
                                    <a href="contact.html">
                                        <?php if($item['rr_box_icon_type'] == 'icon') : ?>
                                        <?php if (!empty($item['rr_box_icon']) || !empty($item['rr_box_selected_icon']['value'])) : ?>
                                        <span>
                                            <?php rr_render_icon($item, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                                        </span>
                                        <?php endif; ?>
                                        <?php elseif( $item['rr_box_icon_type'] == 'image' ) : ?>
                                        <?php if (!empty($item['rr_box_icon_image']['url'])): ?>
                                        <span>
                                            <img src="<?php echo $item['rr_box_icon_image']['url']; ?>"
                                                alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                        </span>
                                        <?php endif; ?>
                                        <?php else : ?>
                                        <?php if (!empty($item['rr_box_icon_svg'])): ?>
                                        <div class="contact-inner-img contact-img-<?php echo esc_attr($key); ?>">
                                            <?php echo $item['rr_box_icon_svg']; ?>
                                        </div>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </a>
                                </div>
                                <div class="latest-contact-us-2-media-content-contact-text">
                                    <?php if ( !empty($item['rr_contact_text_label']) ) : ?>
                                    <p><?php echo rr_kses($item['rr_contact_text_label']);?></p>
                                    <?php endif; ?>
                                    <?php if(!empty($item['link_type'])) : ?>
                                    <a href="<?php echo esc_url($contact_link); ?>">
                                        <h6><?php echo rr_kses($item['rr_contact_info_title']); ?></h6>
                                    </a>
                                    <?php else : ?>
                                    <h6><?php echo rr_kses($item['rr_contact_info_title']); ?></h6>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>

                            <?php if ($settings['show_profiles'] && is_array($settings['profiles'])) : ?>
                            <div class="latest-contact-us-2-media-content-social">

                                <?php
                                foreach ($settings['profiles'] as $profile) :
                                    $icon = !empty($profile['name']) ? $profile['name'] : '';
                                    $url = !empty($profile['link']['url']) ? $profile['link']['url'] : '';

                                    if ($profile['name'] === 'website') {
                                        $icon = 'globe';
                                    } elseif ($profile['name'] === 'email') {
                                        $icon = 'envelope';
                                        $url = 'mailto:' . antispambot($profile['email']);
                                    }

                                    printf('<div class="latest-contact-us-2-media-content-social-icon"><a target="_blank" rel="noopener" data-tooltip="hello" href="%s" class="elementor-repeater-item-%s comments-btn"><i class="fab fa-%s" aria-hidden="true"></i></a></div>',
                                        $url,
                                        esc_attr($profile['_id']),
                                        esc_attr($icon),
                                        esc_attr($icon)
                                    );
                                endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <?php if( !empty($settings['rr-core_select_contact_form']) ) : ?>
                    <?php echo do_shortcode( '[contact-form-7  id="'.$settings['rr-core_select_contact_form'].'"]' ); ?>
                    <?php else : ?>
                    <?php echo '<div class="alert alert-info"><p class="m-0">' . __('Please Select contact form.', 'rr-core' ). '</p></div>'; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

<?php else:
    $this->add_render_attribute('title_args', 'class', 'rr-contact__title wow rrfadeUp rr-el-title');
?>
    <div class="rr-contact-info rr-el-section">
        <?php if ( !empty($settings['rr_contact_section_title_show']) ) : ?>
        <div class="rr-contact__comment-form-box2 mb-30">
            <?php
                if ( !empty($settings['rr_contact_title' ]) ) :
                    printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_contact_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_contact_title' ] )
                        );
                endif;
            ?>
            <?php if ( !empty($settings['rr_contact_description']) ) : ?>
            <p class="rr-el-subtitle"><?php echo rr_kses( $settings['rr_contact_description'] ); ?></p>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <div class="rr-contact-info-text">
            <?php foreach ($settings['rr_list'] as $key => $item) :
            $key = $key+1;

            $link_type = $item['link_type'];
            $url = $item['rr_contact_url'];
            $tell = $item['rr_contact_tell'];
            $email = $item['rr_contact_email'];

            $contact_link;

            if($link_type == 'url'){
                $contact_link = $url;
            } elseif($link_type == 'tell'){
                $contact_link = 'tel:'.$tell;
            } elseif($link_type == 'email'){
                $contact_link = 'mailto:'.$email;
            }

            ?>
            <div class="rr-contact-item d-flex">
                <div class="rr-contact-item-icon">

                    <?php if($item['rr_box_icon_type'] == 'icon') : ?>
                    <?php if (!empty($item['rr_box_icon']) || !empty($item['rr_box_selected_icon']['value'])) : ?>
                    <span>
                        <?php rr_render_icon($item, 'rr_box_icon', 'rr_box_selected_icon'); ?>
                    </span>
                    <?php endif; ?>
                    <?php elseif( $item['rr_box_icon_type'] == 'image' ) : ?>
                    <?php if (!empty($item['rr_box_icon_image']['url'])): ?>
                    <span>
                        <img src="<?php echo $item['rr_box_icon_image']['url']; ?>"
                            alt="<?php echo get_post_meta(attachment_url_to_postid($item['rr_box_icon_image']['url']), '_wp_attachment_image_alt', true); ?>">
                    </span>
                    <?php endif; ?>
                    <?php else : ?>
                    <?php if (!empty($item['rr_box_icon_svg'])): ?>
                    <div class="contact-inner-img contact-img-<?php echo esc_attr($key); ?>">
                        <?php echo $item['rr_box_icon_svg']; ?>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>

                </div>
                <div class="rr-contact-item-content">
                    <?php if ( !empty($item['rr_contact_text_label']) ) : ?>
                    <h3 class="rr-contact-item-title rr-el-re-Title"><?php echo rr_kses($item['rr_contact_text_label']);?>
                    </h3>
                    <?php endif; ?>
                    <?php if(!empty($item['link_type'])) : ?>
                    <a
                        href="<?php echo esc_url($contact_link); ?>"><?php echo rr_kses($item['rr_contact_info_title']); ?></a>
                    <?php else : ?>
                    <?php echo rr_kses($item['rr_contact_info_title']); ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif;
	}
}

$widgets_manager->register( new rr_Contact_Info() );