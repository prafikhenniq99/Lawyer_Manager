<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Background;
use \Elementor\Control_Media;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Video_Popup extends Widget_Base {

     use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'rr-video-popup';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Video Popup', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

    protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  
	protected function register_controls_section() {
       // rr_section_title
	   $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1', 'layout-2', 'layout-3']);

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style', 
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // rr_video
        $this->start_controls_section(
            'rr_video',
            [
                'label' => esc_html__('Video', 'rr-core'),
            ]
        );

        $this->add_control(
            'rr_video_url',
            [
                'label' => esc_html__('Video URL', 'rr-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => 'htRRs://www.youtube.com/watch?v=_RpLvsA1SNM',
                'label_block' => true,
                'description' => __("We recommended to put video url form video website such as 'youtube', 'vimeo'.", 'rr-core')
            ]
        );

		$this->add_control(
            'rr_thumbnail_image',
            [
                'label' => esc_html__( 'Choose Member Image', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'rr_thumbnail_size',
                'default' => 'full',
                'exclude' => [
                    'custom'
                ]
            ]
        );

        $this->add_control(
            'rr_btn_btn_text',
            [
                'label' => esc_html__('Button Text', 'rr-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'rr-core'),
                'title' => esc_html__('Enter button text', 'rr-core'),
                'label_block' => true,
               
            ]
        );
        
        $this->add_control(
            'rr_btn_link',
            [
                'label' => esc_html__( 'Button Link link', 'rr-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htRRs://your-link.com', 'rr-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
            ]
        );

        $this->end_controls_section();  
	}
    
    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('video_section', 'Section - Style', '.rr-el-section');
        $this->rr_basic_style_controls('section_sub_title', 'Section - Sub Title', '.rr-el-sub-title');
        $this->rr_basic_style_controls('section_title', 'Section - Title', '.rr-el-title');
        $this->rr_basic_style_controls('section_desc', 'Section - Description', '.rr-el-desc');
        $this->rr_link_controls_style('banner_btn', 'Button Style', '.ele-btn');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>

<?php if ( $settings['rr_design_style']  == 'layout-2' ) : 
	?>

<?php else:
	if ( !empty($settings['rr_thumbnail_image']['url']) ) {
        $rr_thumbnail_image = !empty($settings['rr_thumbnail_image']['id']) ? wp_get_attachment_image_url( $settings['rr_thumbnail_image']['id'], $settings['rr_thumbnail_size_size']) : $settings['rr_thumbnail_image']['url'];
        $rr_thumbnail_image_alt = get_post_meta($settings["rr_thumbnail_image"]["id"], "_wp_attachment_image_alt", true);
    }
	$this->add_render_attribute('title_args', 'class', 'cta-3__content-title rr-el-title');
?>
<!-- cta-3-area start -->
<section class="cta-3__area position-relative rr-el-section">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                <div class="cta-3__content pt-105 pb-105">
                <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                    <h6 class="cta-3__content-subtitle rr-el-sub-title"><?php echo rr_kses( $settings['rr_section_sub_title'] ); ?></h6>
                <?php endif; ?>
                    <?php
                    if ( !empty($settings['rr_section_title' ]) ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                        tag_escape( $settings['rr_section_title_tag'] ),
                        $this->get_render_attribute_string( 'title_args' ),
                        rr_kses( $settings['rr_section_title' ] )
                        );
                    endif;
                    ?>
                     <?php if ( !empty($settings['rr_section_description']) ) : ?>
                    <h6 class="cta-3__content-dollar mb-30 rr-el-desc"><?php echo rr_kses( $settings['rr_section_description'] ); ?></h6>
                    <?php endif; ?>

                    <?php if ( !empty($settings['rr_video_url']) ) : ?>
                    <div class="cta-3__content-video d-flex">

                        <a href="<?php echo esc_url($settings['rr_btn_link']['url']); ?>" class="rr-btn btn-hover-white ele-btn"><?php echo rr_kses($settings['rr_btn_btn_text']);?></a>

                        <a href="<?php echo esc_url($settings['rr_video_url']); ?>"
                            class="popup-video zooming cta-3__content-video-button"
                            data-effect="mfp-move-from-top vertical-middle">
                            <svg width="26" height="28" viewBox="0 0 26 28" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <g filter="url(#filter0_d_836_9)">
                                    <path
                                        d="M19.5 10.134C20.1667 10.5189 20.1667 11.4811 19.5 11.866L7.5 18.7942C6.83333 19.1791 6 18.698 6 17.9282L6 4.0718C6 3.302 6.83333 2.82087 7.5 3.20577L19.5 10.134Z"
                                        fill="#FF3D00" />
                                </g>
                                <defs>
                                    <filter id="filter0_d_836_9" x="0" y="0.0703125" width="26" height="27.8594"
                                        filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                                        <feFlood flood-opacity="0" result="BackgroundImageFix" />
                                        <feColorMatrix in="SourceAlpha" type="matrix"
                                            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
                                        <feOffset dy="3" />
                                        <feGaussianBlur stdDeviation="3" />
                                        <feComposite in2="hardAlpha" operator="out" />
                                        <feColorMatrix type="matrix"
                                            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0" />
                                        <feBlend mode="normal" in2="BackgroundImageFix"
                                            result="effect1_dropShadow_836_9" />
                                        <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_836_9"
                                            result="shape" />
                                    </filter>
                                </defs>
                            </svg>
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
            <?php if(!empty($rr_thumbnail_image)) : ?>
                <div class="cta-3__media">
                <img src="<?php echo esc_url($rr_thumbnail_image); ?>"
                                            alt="<?php echo esc_attr($rr_thumbnail_image_alt); ?>">
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section> 
<!-- cta-3-area end -->

<?php endif;
	}
}

$widgets_manager->register( new rr_Video_Popup() );