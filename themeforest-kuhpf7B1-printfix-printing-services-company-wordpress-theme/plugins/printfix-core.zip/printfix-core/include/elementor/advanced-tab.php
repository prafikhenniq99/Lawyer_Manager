<?php
namespace RRCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Repeater;
use \Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * RR Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class rr_Advanced_Tab extends Widget_Base {

    use \RRCore\Widgets\RRCoreElementFunctions;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'advanced-tab';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Advanced Tab', 'rr-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'rr-icon';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'rr-core' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'rr-core' ];
	}


	protected function register_controls(){
        $this->register_controls_section();
        $this->style_tab_content();
    }  



	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */

	protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'rr_layout',
            [
                'label' => esc_html__('Design Layout', 'rr-core'),
            ]
        );
        $this->add_control(
            'rr_design_style',
            [
                'label' => esc_html__('Select Layout', 'rr-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'rr-core'),
                    'layout-2' => esc_html__('Layout 2', 'rr-core'),
                    'layout-3' => esc_html__('Layout 3', 'rr-core'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

		
        // rr_section_title
        $this->rr_section_title_render_controls('section', 'Section Title', 'Sub Title', 'your title here', $default_description = 'Hic nesciunt galisum aut dolorem aperiam eum soluta quod ea cupiditate.',['layout-1', 'layout-2','layout-3']);

		$this->start_controls_section(
            '_section_price_tabs',
            [
                'label' => __('Advanced Tabs', 'rr-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'title',
            [
                'type' => Controls_Manager::TEXT,
                'label' => __('Title', 'rr-core'),
                'default' => __('Tab Title', 'rr-core'),
                'placeholder' => __('Type Tab Title', 'rr-core'),
                'dynamic' => [
                    'active' => true,
                ]
            ]
        );

        $repeater->add_control(
            'template',
            [
                'label' => __('Section Template', 'rr-core'),
                'placeholder' => __('Select a section template for as tab content', 'rr-core'),
  
                'type' => Controls_Manager::SELECT2,
                'options' => get_elementor_templates()
            ]
        );

        $this->add_control(
            'tabs',
            [
                'show_label' => false,
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{title}}',
                'default' => [
                    [
                        'title' => 'Tab 1',
                    ],
                    [
                        'title' => 'Tab 2',
                    ]
                ]
            ]
        );

        $this->end_controls_section();

	}

    // style_tab_content
    protected function style_tab_content(){
        $this->rr_section_style_controls('advanced_tab_section', 'Section Style', '.ele-section');
        $this->rr_basic_style_controls('advanced_tab_sub_title', 'Subtitle Style', '.ele-subtitle');
        $this->rr_basic_style_controls('advanced_tab_title', 'Heading Style', '.ele-heading');
        $this->rr_basic_style_controls('advanced_tab_des', 'Content Style', '.ele-description');
        $this->rr_basic_style_controls('advanced_tab_link', 'Tab Link Style', '.ele-link');
    }

	/**
	 * Render the widget ouRRut on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>


<?php if ( $settings['rr_design_style']  == 'layout-2' ): 
    // shape image
    if ( !empty($settings['rr_shape_image_1']['url']) ) {
        $rr_shape_image = !empty($settings['rr_shape_image_1']['id']) ? wp_get_attachment_image_url( $settings['rr_shape_image_1']['id'], $settings['shape_image_size_size']) : $settings['rr_shape_image_1']['url'];
        $rr_shape_image_alt = get_post_meta($settings["rr_shape_image_1"]["id"], "_wp_attachment_image_alt", true);
    }
    if ( !empty($settings['rr_shape_image_2']['url']) ) {
        $rr_shape_image_2 = !empty($settings['rr_shape_image_2']['id']) ? wp_get_attachment_image_url( $settings['rr_shape_image_2']['id'], $settings['shape_image_size_size']) : $settings['rr_shape_image_2']['url'];
        $rr_shape_image_alt_2 = get_post_meta($settings["rr_shape_image_2"]["id"], "_wp_attachment_image_alt", true);
    }
    $this->add_render_attribute('title_args', 'class', 'title-5 wow fadeInLeft animated rr-section-title');
?>
<div class="rr-trend-product-5__area project-section-4 pb-60 overflow-hidden">
    <div class="container custom-container">
        <div class="rr-trend-product-5__top-mb">
            <div class="row align-items-center">
                <div class="rr-trend-product-5__btn-wrap">
                    <?php if (!empty($settings['rr_section_title'])): ?>
                        <<?php echo esc_html($settings['rr_section_title_tag']); ?>
                            <?php echo $this->get_render_attribute_string('title_args'); ?>>
                            <?php echo esc_html($settings['rr_section_title']); ?>
                        </<?php echo esc_html($settings['rr_section_title_tag']); ?>>
                    <?php endif; ?>
                    <div class="button-box wow fadeInLeft animated" data-wow-delay=".2s">
                        <ul class="project-filter text-center wow fade-in-right" data-wow-delay="400ms">
                            <?php foreach ($settings['tabs'] as $key => $tab): 
                                $active = ($key == 0) ? 'active' : ''; ?>
                                <li class="list <?php echo esc_attr($active); ?>" data-filter="<?php echo esc_attr($key); ?>">
                                    <?php echo esc_html($tab['title']); ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <div class="button">
                            <a class="btn" href="shop-details.html"><?php esc_html_e('All Product', 'rr-core'); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row filter-items">
            <?php foreach ($settings['tabs'] as $key => $tab): 
                $active = ($key == 0) ? 'show active' : ''; ?>
                <div class="col-xl-3 col-lg-4 col-md-6 single-item design app" data-filter="<?php echo esc_attr($key); ?>">
                    <div class="rr-trend-product-5__item-box wow fadeInLeft animated" data-wow-delay=".1s">
                        <?php echo \Elementor\Plugin::instance()->frontend->get_builder_content($tab['template'], true); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>


<?php else: 
    $this->add_render_attribute('title_args', 'class', 'title rr-section-title');
?>

<!-- prodact-3-area start -->
<section class="prodact-area product-bg">
    <div class="rr-fea-product__area p-relative fix grey-bg-2 pb-35 pt-115 rr-pro-tab1 rr-el-section">
        <div class="container custom-container-3">
            <div class="row">
                <div class="col-xl-12">
                    <div class="prodact-title-wrapper text-center mb-25">
                        <?php if ( !empty($settings['rr_section_sub_title']) ) : ?>
                        <span
                            class="subtitle rr-el-subtitle"><?php echo rr_kses($settings['rr_section_sub_title']); ?></span>
                        <?php endif; ?>
                        <?php
                        if ( !empty($settings['rr_section_title' ]) ) :
                            printf( '<%1$s %2$s>%3$s</%1$s>',
                            tag_escape( $settings['rr_section_title_tag'] ),
                            $this->get_render_attribute_string( 'title_args' ),
                            rr_kses( $settings['rr_section_title' ] )
                            );
                        endif;
                        ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="rr-fea-product__tab mb-25">
                        <nav>
                            <div class="nav nav-tab justify-content-center" id="nav-tab" role="tablist">
                                <?php foreach ($settings['tabs'] as $key => $tab):
                                    $active = ($key == 0) ? 'active' : '';
                                ?>
                                <button class="nav-link rr-el-rep-filterBtn <?php echo esc_attr($active); ?>"
                                    id="nav-<?php echo esc_attr($key); ?>-tab" data-bs-toggle="tab"
                                    data-bs-target="#nav-<?php echo esc_attr($key); ?>" type="button" role="tab"
                                    aria-controls="nav-<?php echo esc_attr($key); ?>"
                                    aria-selected="true"><?php echo rr_kses($tab['title']); ?>
                                </button>
                                <?php endforeach; ?>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="tab-content" id="nav-tabContent">
                    <?php foreach ($settings['tabs'] as $key => $tab):
                        $active = ($key == 0) ? 'show active' : '';
                    ?>
                    <div class="tab-pane fade <?php echo esc_attr($active); ?>" id="nav-<?php echo esc_attr($key); ?>"
                        role="tabpanel" aria-labelledby="nav-<?php echo esc_attr($key); ?>-tab"
                        tabindex="<?php echo esc_attr($key); ?>">
                        <?php echo \Elementor\Plugin::instance()->frontend->get_builder_content($tab['template'], true); ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- prodact-3-area end -->

<?php endif;

	}

}
$widgets_manager->register( new rr_Advanced_Tab() );