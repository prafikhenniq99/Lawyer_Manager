<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package printfix
 */

function get_header_style($style){
    if ( $style == 'header_2'  ) {
        get_template_part( 'template-parts/header/header-2' );
    }
    elseif ( $style == 'header_3'  ) {
        get_template_part( 'template-parts/header/header-3' );
    }
    elseif ( $style == 'header_4'  ) {
        get_template_part( 'template-parts/header/header-4' );
    }

    elseif ( $style == 'header_5'  ) {
        get_template_part( 'template-parts/header/header-5' );
    }

    elseif ( $style == 'header_6'  ) {
        get_template_part( 'template-parts/header/header-6' );
    }

    else{
        get_template_part( 'template-parts/header/header-1');
    }
}

function printfix_check_header() {
    $tp_header_tabs = function_exists('tpmeta_field')? tpmeta_field('printfix_header_tabs') : false;
    $tp_header_style_meta = function_exists('tpmeta_field')? tpmeta_field('printfix_header_style') : '';
    $elementor_header_template_meta = function_exists('tpmeta_field')? tpmeta_field('printfix_header_templates') : false;

    $printfix_header_option_switch = get_theme_mod('printfix_header_elementor_switch', false);
    $header_default_style_kirki = get_theme_mod( 'header_layout_custom', 'header_1' );
    $elementor_header_templates_kirki = get_theme_mod( 'printfix_header_templates' );

    if($tp_header_tabs == 'default'){
        if($printfix_header_option_switch){
            if($elementor_header_templates_kirki){
                echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_header_templates_kirki);
            }
        }else{
            if($header_default_style_kirki){
                get_header_style($header_default_style_kirki);
            }else{
                get_template_part( 'template-parts/header/header-1' );
            }
        }
    }elseif($tp_header_tabs == 'custom'){
        if ($tp_header_style_meta) {
            get_header_style($tp_header_style_meta);
        }else{
            get_header_style($header_default_style_kirki);
        }
    }elseif($tp_header_tabs == 'elementor'){
        if($elementor_header_template_meta){
            echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_header_template_meta);
        }else{
            echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_header_templates_kirki);
        }
    }else{
        if($printfix_header_option_switch){

            if($elementor_header_templates_kirki){
                echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_header_templates_kirki);
            }else{
                get_template_part( 'template-parts/header/header-1' );
            }
        }else{
            get_header_style($header_default_style_kirki);

        }

    }

}
add_action( 'printfix_header_style', 'printfix_check_header', 10 );



/**
 * [printfix_header_lang description]
 * @return [type] [description]
 */

function printfix_header_lang_defualt() {
    $printfix_header_lang = get_theme_mod( 'printfix_header_lang', true );
    if ( $printfix_header_lang ): ?>

<span class="tp-header-lang-selected-lang tp-lang-toggle"
    id="tp-header-lang-toggle"><?php print esc_html__( 'English', 'printfix' );?></span>

<?php do_action( 'printfix_language' );?>

<?php endif;?>
<?php
}

/**
 * [printfix_language_list description]
 * @return [type] [description]
 */
function _printfix_language( $mar ) {
    return $mar;
}
function printfix_language_list() {

    $mar = '';
    $languages = apply_filters( 'wpml_active_languages', NULL, 'orderby=id&order=desc' );
    if ( !empty( $languages ) ) {
        $mar = '<ul class="tp-header-lang-list tp-lang-list">';
        foreach ( $languages as $lan ) {
            $active = $lan['active'] == 1 ? 'active' : '';
            $mar .= '<li class="' . $active . '"><a href="' . $lan['url'] . '">' . $lan['translated_name'] . '</a></li>';
        }
        $mar .= '</ul>';
    } else {
        //remove this code when send themeforest reviewer team
        $mar .= '<ul class="tp-header-lang-list tp-lang-list tp-header-lan-list-area">';
        $mar .= '<li><a href="#">' . esc_html__( 'English', 'printfix' ) . '</a></li>';
        $mar .= '<li><a href="#">' . esc_html__( 'Bangla', 'printfix' ) . '</a></li>';
        $mar .= '<li><a href="#">' . esc_html__( 'French', 'printfix' ) . '</a></li>';
        $mar .= '<li><a href="#">' . esc_html__( 'Hindi', 'printfix' ) . '</a></li>';
        $mar .= ' </ul>';
    }
    print _printfix_language( $mar );
}
add_action( 'printfix_language', 'printfix_language_list' );


// header logo
function printfix_header_logo() { ?>
    <?php
            $printfix_logo_on = function_exists('tpmeta_field')? tpmeta_field('printfix_en_secondary_logo') : '';
            $printfix_logo = get_template_directory_uri() . '/assets/imgs/logo/logo.png';
            $printfix_logo_white = get_template_directory_uri() . '/assets/imgs/logo/offcanvas-logo.png';

            $printfix_site_logo = get_theme_mod( 'header_logo', $printfix_logo );
            $printfix_secondary_logo = get_theme_mod( 'header_secondary_logo', $printfix_logo_white );
        ?>

    <?php if ( $printfix_logo_on == 'on' ) : ?>
    <a class="main-logo" href="<?php print esc_url( home_url( '/' ) );?>">
        <img src="<?php print esc_url( $printfix_secondary_logo );?>"
            alt="<?php print esc_attr__( 'logo', 'printfix' );?>" />
    </a>
    <?php else : ?>
    <a class="standard-logo" href="<?php print esc_url( home_url( '/' ) );?>">
        <img src="<?php print esc_url( $printfix_site_logo );?>" alt="<?php print esc_attr__( 'logo', 'printfix' );?>" />
    </a>
    <?php endif; ?>
    <?php
}


// header logo
function printfix_header_black_logo() { ?>
    <?php
            $printfix_logo = get_template_directory_uri() . '/assets/img/logo/logo-black.png';

            $printfix_black_logo = get_theme_mod( 'header_logo', $printfix_logo );
        ?>

    <a href="<?php print esc_url( home_url( '/' ) );?>">
        <img src="<?php print esc_url( $printfix_black_logo );?>" alt="<?php print esc_attr__( 'logo', 'printfix' );?>" />
    </a>
    <?php
}

/**
 * [printfix_header_social_profiles description]
 * @return [type] [description]
 */
function printfix_header_social_profiles() {
    $printfix_topbar_fb_url = get_theme_mod( 'header_facebook_link', __( '#', 'printfix' ) );
    $printfix_topbar_linkedin_url = get_theme_mod( 'header_linkedin_link', __( '#', 'printfix' ) );
    $printfix_topbar_instagram_url = get_theme_mod( 'header_instagram_link', __( '#', 'printfix' ) );
    $printfix_topbar_pinterest_url = get_theme_mod( 'header_pinterest_link', __( '#', 'printfix' ) );
    $printfix_topbar_vimeo_url = get_theme_mod( 'header_vimeo_link', __( '#', 'printfix' ) );
    $printfix_topbar_youtube_url = get_theme_mod( 'header_youtube_link', __( '#', 'printfix' ) );
    $printfix_topbar_behance_url = get_theme_mod( 'header_behance_url', __( '#', 'printfix' ) );
    $printfix_topbar_dribble_url = get_theme_mod( 'header_dribble_url', __( '#', 'printfix' ) );
    $printfix_topbar_tiktok_url = get_theme_mod( 'header_tiktok_url', __( '#', 'printfix' ) );
    ?>
    <ul>
        <?php if ( !empty( $printfix_topbar_fb_url ) ): ?>
            <li>
                <a href="<?php print esc_url( $printfix_topbar_fb_url );?>">
                    <i class="fab fa-facebook-f"></i>
                </a>
            </li>
        <?php endif;?>

        <?php if ( !empty( $printfix_topbar_linkedin_url ) ): ?>
            <li>
                <a href="<?php print esc_url( $printfix_topbar_linkedin_url );?>">
                    <i class="fa-brands fa-linkedin-in"></i>
                </a>
            </li>
        <?php endif;?>

        <?php if ( !empty( $printfix_topbar_instagram_url ) ): ?>
            <li>
                <a href="<?php echo esc_url( $printfix_topbar_instagram_url ) ?>">
                    <i class="fab fa-instagram"></i>
                </a>
            </li>
        <?php endif;?>

        <?php if ( !empty( $printfix_topbar_pinterest_url ) ): ?>
            <li>
                <a href="<?php echo esc_url( $printfix_topbar_pinterest_url ) ?>">
                    <i class="fa-brands fa-pinterest-p"></i>
                </a>
            </li>
        <?php endif; ?>

        <?php if ( !empty( $printfix_topbar_vimeo_url ) ): ?>
            <li>
                <a href="<?php echo esc_url( $printfix_topbar_vimeo_url ) ?>">
                    <i class="fa-brands fa-vimeo-v"></i>
                </a>
            </li>
        <?php endif; ?>

        <?php if ( !empty( $printfix_topbar_youtube_url ) ): ?>
            <li>
                <a href="<?php echo esc_url( $printfix_topbar_youtube_url ) ?>">
                    <i class="fa-brands fa-youtube"></i>
                </a>
            </li>
        <?php endif; ?>

        <?php if ( !empty( $printfix_topbar_behance_url ) ): ?>
            <li>
                <a href="<?php echo esc_url( $printfix_topbar_behance_url ) ?>">
                    <i class="fa-brands fa-behance"></i>
                </a>
            </li>
        <?php endif; ?>

        <?php if ( !empty( $printfix_topbar_dribble_url ) ): ?>
            <li>
                <a href="<?php echo esc_url( $printfix_topbar_dribble_url ) ?>">
                    <i class="fa-brands fa-dribbble"></i>
                </a>
            </li>
        <?php endif; ?>

        <?php if ( !empty( $printfix_topbar_tiktok_url ) ): ?>
            <li>
                <a href="<?php echo esc_url( $printfix_topbar_tiktok_url ) ?>">
                    <i class="fa-brands fa-tiktok"></i>
                </a>
            </li>
        <?php endif; ?>
    </ul>

    <?php
}



/**
 * [printfix_header_menu description]
 * @return [type] [description]
 */
function printfix_header_menu() {
    ?>
<?php
        wp_nav_menu( [
            'theme_location' => 'main-menu',
            'menu_class'     => '',
            'container'      => '',
            'fallback_cb'    => 'printfix_Navwalker_Class::fallback',
            'walker'         => new \TPCore\Widgets\printfix_Navwalker_Class,
        ] );
    ?>
<?php
}


/**
 * [printfix_footer_menu description]
 * @return [type] [description]
 */
function printfix_header_top_menu() {
    wp_nav_menu( [
        'theme_location' => 'header-top-menu',
        'menu_class'     => '',
        'container'      => '',
        'fallback_cb'    => 'printfix_Navwalker_Class::fallback',
        'walker'         =>  new \TPCore\Widgets\printfix_Navwalker_Class,
    ] );
}
/**
 * [printfix_footer_menu description]
 * @return [type] [description]
 */
function printfix_footer_bottom_menu() {
    wp_nav_menu( [
        'theme_location' => 'footer-bottom-menu',
        'menu_class'     => '',
        'container'      => '',
        'fallback_cb'    => 'printfix_Navwalker_Class::fallback',
        'walker'         =>  new \TPCore\Widgets\printfix_Navwalker_Class,
    ] );
}


 /*
 * printfix footer
 */
add_action( 'printfix_footer_style', 'printfix_check_footer', 10 );


function get_footer_style($style){
    if( $style == 'footer_2'  ) {
        get_template_part( 'template-parts/footer/footer-2' );
    }
    elseif ( $style == 'footer_3'  ) {
        get_template_part( 'template-parts/footer/footer-3' );
    }
    elseif ( $style == 'footer_4'  ) {
        get_template_part( 'template-parts/footer/footer-4' );
    }
    else{
        get_template_part( 'template-parts/footer/footer-1');
    }
}

function printfix_check_footer() {
    $tp_footer_tabs = function_exists('tpmeta_field')? tpmeta_field('printfix_footer_tabs') : '';
    $printfix_footer_style = function_exists( 'tpmeta_field' ) ? tpmeta_field( 'printfix_footer_style' ) : NULL;
    $footer_template = function_exists('tpmeta_field')? tpmeta_field('printfix_footer_template') : false;

    $printfix_footer_option_switch = get_theme_mod( 'printfix_footer_elementor_switch', false );
    $elementor_footer_template = get_theme_mod( 'printfix_footer_templates');
    $printfix_default_footer_style = get_theme_mod( 'footer_layout', 'footer_1' );

    if($tp_footer_tabs == 'default'){
        if($printfix_footer_option_switch){
            if($elementor_footer_template){
                echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_footer_template);
            }
        }else{
            if($printfix_default_footer_style){
                get_footer_style($printfix_default_footer_style);
            }else{
                get_template_part( 'template-parts/footer/footer-1' );
            }
        }
    }elseif($tp_footer_tabs == 'custom'){
        if ($printfix_footer_style) {
            get_footer_style($printfix_footer_style);
        }else{
            get_footer_style($printfix_default_footer_style);
        }
    }elseif($tp_footer_tabs == 'elementor'){
        if($footer_template){
            echo \Elementor\Plugin::$instance->frontend->get_builder_content($footer_template);
        }else{
            echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_footer_template);
        }

    }else{
        if($printfix_footer_option_switch){

            if($elementor_footer_template){
                echo \Elementor\Plugin::$instance->frontend->get_builder_content($elementor_footer_template);
            }else{
                get_template_part( 'template-parts/footer/footer-1' );
            }
        }else{
            get_footer_style($printfix_default_footer_style);

        }
    }
}

// Header Logo Size Control
function printfix_style_functions()
{
    wp_enqueue_style('printfix-custom', PRINTFIX_THEME_CSS_DIR . 'printfix-custom.css', []);

    $logo_size = get_theme_mod('printfix_logo_size', '163');
    if ($logo_size != '') {
        $custom_css = '';
        $custom_css .= ".header__area .header-container .mega__menu-wrapper .header__logo a img, .header__area .mega__menu-wrapper .header__main .header__left .header__logo img{ width: " . $logo_size . "px}";
        wp_add_inline_style('printfix-custom', $custom_css);
    }
}
add_action('wp_enqueue_scripts', 'printfix_style_functions');

// printfix_copyright_text
function printfix_copyright_text() {
   print get_theme_mod( 'footer_copyright', esc_html__( '© 2024 printfix, All Rights Reserved. Design By RRDevs', 'printfix' ) );
}


/**
 *
 * pagination
 */
if ( !function_exists( 'printfix_pagination' ) ) {

    function _printfix_pagi_callback( $pagination ) {
        return $pagination;
    }

    //page navegation
    function printfix_pagination( $prev, $next, $pages, $args ) {
        global $wp_query, $wp_rewrite;
        $menu = '';
        $wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;

        if ( $pages == '' ) {
            global $wp_query;
            $pages = $wp_query->max_num_pages;

            if ( !$pages ) {
                $pages = 1;
            }

        }

        $pagination = [
            'base'      => add_query_arg( 'paged', '%#%' ),
            'format'    => '',
            'total'     => $pages,
            'current'   => $current,
            'prev_text' => $prev,
            'next_text' => $next,
            'type'      => 'array',
        ];

        //rewrite permalinks
        if ( $wp_rewrite->using_permalinks() ) {
            $pagination['base'] = user_trailingslashit( trailingslashit( remove_query_arg( 's', get_pagenum_link( 1 ) ) ) . 'page/%#%/', 'paged' );
        }

        if ( !empty( $wp_query->query_vars['s'] ) ) {
            $pagination['add_args'] = ['s' => get_query_var( 's' )];
        }

        $pagi = '';
        if ( paginate_links( $pagination ) != '' ) {
            $paginations = paginate_links( $pagination );
            $pagi .= '<ul>';
            foreach ( $paginations as $key => $pg ) {
                $pagi .= '<li>' . $pg . '</li>';
            }
            $pagi .= '</ul>';
        }

        print _printfix_pagi_callback( $pagi );
    }
}

// theme color
function printfix_custom_color() {
    $printfix_theme_primary = get_theme_mod( 'printfix_theme_primary', '#FF3D00' );
    $printfix_heading_primary = get_theme_mod( 'printfix_heading_primary', '#001D08' );
    $printfix_text_body = get_theme_mod( 'printfix_text_body', '#646464' );
    $printfix_common_placeholder = get_theme_mod( 'printfix_common_placeholder', '#4A5764' );
    $printfix_common_black = get_theme_mod( 'printfix_common_black', '#000000' );
    $printfix_common_white = get_theme_mod( 'printfix_common_white', '#FFFFFF' );
    $printfix_border_primary = get_theme_mod( 'printfix_border_primary', '#FF3D00' );

    wp_enqueue_style( 'printfix-custom', PRINTFIX_THEME_CSS_DIR . 'printfix-custom.css', [] );

    if ( !empty( $printfix_theme_primary || $printfix_heading_primary || $printfix_text_body || $printfix_common_placeholder || $printfix_common_black || $printfix_common_white || $printfix_border_primary )) {
        $custom_css = '';
        $custom_css .= "html:root{
            --rr-theme-primary: " . $printfix_theme_primary . ";
            --rr-heading-primary: " . $printfix_heading_primary . ";
            --rr-text-body: " . $printfix_text_body . ";
            --rr-common-placeholder: " . $printfix_common_placeholder . ";
            --rr-common-black: " . $printfix_common_black . ";
            --rr-common-white: " . $printfix_common_white . ";
            --rr-border-color: 1px solid " . $printfix_border_primary . ";
        }";

        wp_add_inline_style( 'printfix-custom', $custom_css );
    }
}
add_action( 'wp_enqueue_scripts', 'printfix_custom_color' );

// printfix_kses_intermediate
function printfix_kses_intermediate( $string = '' ) {
    return wp_kses( $string, printfix_get_allowed_html_tags( 'intermediate' ) );
}

function printfix_get_allowed_html_tags( $level = 'basic' ) {
    $allowed_html = [
        'b'      => [],
        'i'      => [],
        'u'      => [],
        'em'     => [],
        'br'     => [],
        'abbr'   => [
            'title' => [],
        ],
        'span'   => [
            'class' => [],
        ],
        'strong' => [],
        'a'      => [
            'href'  => [],
            'title' => [],
            'class' => [],
            'id'    => [],
        ],
    ];

    if ($level === 'intermediate') {
        $allowed_html['a'] = [
            'href' => [],
            'title' => [],
            'class' => [],
            'id' => [],
        ];
        $allowed_html['div'] = [
            'class' => [],
            'id' => [],
        ];
        $allowed_html['img'] = [
            'src' => [],
            'class' => [],
            'alt' => [],
        ];
        $allowed_html['del'] = [
            'class' => [],
        ];
        $allowed_html['ins'] = [
            'class' => [],
        ];
        $allowed_html['bdi'] = [
            'class' => [],
        ];
        $allowed_html['i'] = [
            'class' => [],
            'data-rating-value' => [],
        ];
    }

    return $allowed_html;
}



// WP kses allowed tags
// ----------------------------------------------------------------------------------------
function printfix_kses($raw){

   $allowed_tags = array(
      'a'                         => array(
         'class'   => array(),
         'href'    => array(),
         'rel'  => array(),
         'title'   => array(),
         'target' => array(),
      ),
      'abbr'                      => array(
         'title' => array(),
      ),
      'b'                         => array(),
      'blockquote'                => array(
         'cite' => array(),
      ),
      'cite'                      => array(
         'title' => array(),
      ),
      'code'                      => array(),
      'del'                    => array(
         'datetime'   => array(),
         'title'      => array(),
      ),
      'dd'                     => array(),
      'div'                    => array(
         'class'   => array(),
         'title'   => array(),
         'style'   => array(),
      ),
      'dl'                     => array(),
      'dt'                     => array(),
      'em'                     => array(),
      'h1'                     => array(),
      'h2'                     => array(),
      'h3'                     => array(),
      'h4'                     => array(),
      'h5'                     => array(),
      'h6'                     => array(),
      'i'                         => array(
         'class' => array(),
      ),
      'img'                    => array(
         'alt'  => array(),
         'class'   => array(),
         'height' => array(),
         'src'  => array(),
         'width'   => array(),
      ),
      'li'                     => array(
         'class' => array(),
      ),
      'ol'                     => array(
         'class' => array(),
      ),
      'p'                         => array(
         'class' => array(),
      ),
      'q'                         => array(
         'cite'    => array(),
         'title'   => array(),
      ),
      'span'                      => array(
         'class'   => array(),
         'title'   => array(),
         'style'   => array(),
      ),
      'iframe'                 => array(
         'width'         => array(),
         'height'     => array(),
         'scrolling'     => array(),
         'frameborder'   => array(),
         'allow'         => array(),
         'src'        => array(),
      ),
      'strike'                 => array(),
      'br'                     => array(),
      'strong'                 => array(),
      'data-wow-duration'            => array(),
      'data-wow-delay'            => array(),
      'data-wallpaper-options'       => array(),
      'data-stellar-background-ratio'   => array(),
      'ul'                     => array(
         'class' => array(),
      ),
      'svg' => array(
           'class' => true,
           'aria-hidden' => true,
           'aria-labelledby' => true,
           'role' => true,
           'xmlns' => true,
           'width' => true,
           'height' => true,
           'viewbox' => true, // <= Must be lower case!
       ),
       'g'     => array( 'fill' => true ),
       'title' => array( 'title' => true ),
       'path'  => array( 'd' => true, 'fill' => true,  ),
      );

   if (function_exists('wp_kses')) { // WP is here
      $allowed = wp_kses($raw, $allowed_tags);
   } else {
      $allowed = $raw;
   }

   return $allowed;
}
// blog single social share
function printfix_blog_social_share(){

    $printfix_singleblog_social = get_theme_mod( 'printfix_singleblog_social', false );
    $post_url = get_the_permalink();
    $end_class = has_tag() ? 'text-lg-end' : 'text-lg-start';

    if(!empty($printfix_singleblog_social)) : ?>
<div class="col-xl-6 col-lg-6 col-md-6 col-12">
    <div class="share-social-media_wrapper">
        <span><?php echo esc_attr__( 'Share:', 'printfix' )?></span>

        <div class="share-social-media">
            <a href="<?php echo esc_url($post_url);?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="17" height="13" viewBox="0 0 17 13" fill="none">
                    <path
                        d="M16.8235 0.00728525C16.0912 0.496661 15.2804 0.870955 14.4224 1.11575C13.9618 0.614052 13.3497 0.25846 12.6689 0.0970684C11.9881 -0.064323 11.2714 -0.023726 10.6157 0.213369C9.96004 0.450463 9.39704 0.872616 9.00287 1.42273C8.60869 1.97285 8.40236 2.62438 8.41177 3.28922V4.01371C7.0679 4.04672 5.73627 3.76435 4.53548 3.19174C3.33469 2.61913 2.30201 1.77405 1.52941 0.731774C1.52941 0.731774 -1.52941 7.25217 5.35294 10.1501C3.77805 11.1629 1.90194 11.6708 0 11.5991C6.88235 15.2216 15.2941 11.5991 15.2941 3.26749C15.2934 3.06568 15.2729 2.86438 15.2329 2.66616C16.0134 1.93696 16.5642 1.01629 16.8235 0.00728525Z"
                        fill="white" />
                </svg>
            </a>
            <a href="<?php echo esc_url($post_url);?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="17" viewBox="0 0 10 17" fill="none">
                    <path
                        d="M9.35 0H6.8C5.67283 0 4.59183 0.447767 3.7948 1.2448C2.99777 2.04183 2.55 3.12283 2.55 4.25V6.8H0V10.2H2.55V17H5.95V10.2H8.5L9.35 6.8H5.95V4.25C5.95 4.02457 6.03955 3.80837 6.19896 3.64896C6.35837 3.48955 6.57457 3.4 6.8 3.4H9.35V0Z"
                        fill="white" />
                </svg>
            </a>
            <a href="<?php echo esc_url($post_url);?>">
                <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M11.0513 4.73682C12.3075 4.73682 13.5124 5.23587 14.4007 6.1242C15.289 7.01252 15.7881 8.21735 15.7881 9.47363V14.9999H12.6302V9.47363C12.6302 9.05487 12.4638 8.65326 12.1677 8.35715C11.8716 8.06104 11.47 7.89469 11.0513 7.89469C10.6325 7.89469 10.2309 8.06104 9.93479 8.35715C9.63868 8.65326 9.47233 9.05487 9.47233 9.47363V14.9999H6.31445V9.47363C6.31445 8.21735 6.81351 7.01252 7.70183 6.1242C8.59016 5.23587 9.79498 4.73682 11.0513 4.73682Z"
                        fill="white" />
                    <path d="M3.15787 5.52612H0V14.9997H3.15787V5.52612Z" fill="white" />
                    <path
                        d="M1.57894 3.15787C2.45096 3.15787 3.15787 2.45096 3.15787 1.57894C3.15787 0.706914 2.45096 0 1.57894 0C0.706914 0 0 0.706914 0 1.57894C0 2.45096 0.706914 3.15787 1.57894 3.15787Z"
                        fill="white" />
                </svg>
            </a>
            <a href="<?php echo esc_url($post_url);?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                    <path
                        d="M9.00757 0C4.03279 0 0 4.02609 0 8.99262C0 12.8043 2.37242 16.0608 5.7231 17.3707C5.64105 16.6605 5.57519 15.5647 5.75232 14.7878C5.91537 14.0843 6.80489 10.317 6.80489 10.317C6.80489 10.317 6.53832 9.77695 6.53832 8.98488C6.53832 7.73402 7.2648 6.80168 8.16911 6.80168C8.93996 6.80168 9.31112 7.3793 9.31112 8.06766C9.31112 8.83723 8.82199 9.99211 8.56211 11.0654C8.3473 11.9609 9.01426 12.6935 9.89639 12.6935C11.498 12.6935 12.7287 11.006 12.7287 8.57812C12.7287 6.4241 11.1796 4.92188 8.96285 4.92188C6.39816 4.92188 4.89273 6.83895 4.89273 8.82246C4.89273 9.59203 5.18959 10.4214 5.5597 10.8731C5.63471 10.961 5.64245 11.0426 5.61992 11.1312C5.55301 11.4124 5.39771 12.0266 5.36743 12.1528C5.33045 12.3156 5.23361 12.3521 5.06317 12.2713C3.9363 11.7457 3.23165 10.1099 3.23165 8.7852C3.23165 5.9502 5.29242 3.34547 9.1847 3.34547C12.3061 3.34547 14.737 5.56629 14.737 8.54156C14.737 11.5168 12.7801 14.1374 10.0665 14.1374C9.15442 14.1374 8.29412 13.6635 8.00571 13.101C8.00571 13.101 7.55356 14.8177 7.44228 15.2399C7.24261 16.0242 6.69326 17.0016 6.3228 17.601C7.16866 17.859 8.05889 18 8.99278 18C13.9676 18 18.0004 13.9739 18.0004 9.00738C18.0148 4.02609 13.9824 0 9.00757 0Z"
                        fill="white" />
                </svg>
            </a>
        </div>
    </div>
</div>
<?php endif ;

}

// product single social share
function printfix_product_social_share(){
    $post_url = get_the_permalink();
    ?>
<div class="tp-shop-details__social">
    <span><?php echo esc_html__('Share:', 'printfix');?></span>
    <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo esc_url($post_url);?>" target="_blank"><i
            class="fa-brands fa-linkedin-in"></i></a>
    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo esc_url($post_url);?>" target="_blank"><i
            class="fa-brands fa-facebook"></i></a>
    <a href="https://twitter.com/share?url=<?php echo esc_url($post_url);?>" target="_blank"><i
            class="fa-brands fa-twitter"></i></a>
    <a href="http://pinterest.com/pin/create/button/?url=<?php echo esc_url($post_url);?>" target="_blank"><i
            class="fa-brands fa-pinterest-p"></i></a>
</div>
<?php
}

// / This code filters the Archive widget to include the post count inside the link /
add_filter( 'get_archives_link', 'printfix_archive_count_span' );
function printfix_archive_count_span( $links ) {
    $links = str_replace('</a>&nbsp;(', '<span > (', $links);
    $links = str_replace(')', ')</span></a> ', $links);
    return $links;
}


// / This code filters the Category widget to include the post count inside the link /
add_filter('wp_list_categories', 'printfix_cat_count_span');
function printfix_cat_count_span($links) {
  $links = str_replace('</a> (', '<span> (', $links);
  $links = str_replace(')', ')</span></a>', $links);
  return $links;
}