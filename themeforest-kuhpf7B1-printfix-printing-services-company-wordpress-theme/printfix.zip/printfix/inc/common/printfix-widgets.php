<?php 

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function printfix_widgets_init() {

    $footer_style_2_switch = get_theme_mod( 'footer_layout_2_switch', true );
    $footer_style_3_switch = get_theme_mod( 'footer_layout_3_switch', true );
    $footer_style_4_switch = get_theme_mod( 'footer_layout_4_switch', true );

    /**
     * blog sidebar
     */
    register_sidebar( [
        'name'          => esc_html__( 'Blog Sidebar', 'printfix' ),
        'id'            => 'blog-sidebar',
        'before_widget' => '<div id="%1$s" class="sidebar__widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5 class="sidebar__widget-title">',
        'after_title'   => '</h5>',
    ] );

    /** 
     * Services sidebar
     */
    if(class_exists("RR_Core")) :
    register_sidebar( [
        'name'          => esc_html__( 'Services Sidebar', 'printfix' ),
        'id'            => 'rr-services-sidebar',
        'before_widget' => '<div id="%1$s" class="service-details-righ-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h5 class="service-details-title">',
        'after_title'   => '</h5>',
    ] );
    endif;
    
    
    $footer_widgets = get_theme_mod( 'footer_widget_number', 4 );

    // footer default
    for ( $num = 1; $num <= $footer_widgets; $num++ ) {
        register_sidebar( [
            'name'          => sprintf( esc_html__( 'Footer %1$s', 'printfix' ), $num ),
            'id'            => 'footer-' . $num,
            'description'   => sprintf( esc_html__( 'Footer Column %1$s', 'printfix' ), $num ),
            'before_widget' => '<div id="%1$s" class="footer__widget footer__widget-item-'.$num.' %2$s"><div class="footer__link"> ',
            'after_widget'  => '</div></div>',
            'before_title'  => '<div class="footer__widget-title"><h4>',
            'after_title'   => '</h4></div>',
        ] );
    }

    // footer 2 
    if ( $footer_style_2_switch ) {
        for ( $num = 1; $num <= $footer_widgets; $num++ ) {

            register_sidebar( [
                'name'          => sprintf( esc_html__( 'Footer Style 2 : %1$s', 'printfix' ), $num ),
                'id'            => 'footer-2-' . $num,
                'description'   => sprintf( esc_html__( 'Footer Style 2 : %1$s', 'printfix' ), $num ),
                'before_widget' => '<div id="%1$s" class="footer__widget footer__widget-item-2-'.$num.' %2$s"><div class="footer__link">',
                'after_widget'  => '</div></div>',
                'before_title'  => '<div class="footer__widget-title"><h4>',
                'after_title'   => '</h4></div>',
            ] );
        }
    }       
    // footer 3 
    if ( $footer_style_3_switch ) {
        for ( $num = 1; $num <= $footer_widgets; $num++ ) {

            register_sidebar( [
                'name'          => sprintf( esc_html__( 'Footer Style 3 : %1$s', 'printfix' ), $num ),
                'id'            => 'footer-3-' . $num,
                'description'   => sprintf( esc_html__( 'Footer Style 3 : %1$s', 'printfix' ), $num ),
                'before_widget' => '<div id="%1$s" class="footer__widget footer__widget-item-5-3 footer__widget-item-5-'.$num.' %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="footer__widget-title footer__widget-title-5"><h4>',
                'after_title'   => '</h4></div>',
            ] );
        }
    }    
    // footer 4 
    if ( $footer_style_4_switch ) {
        for ( $num = 1; $num <= $footer_widgets; $num++ ) {

            register_sidebar( [
                'name'          => sprintf( esc_html__( 'Footer Style 4 : %1$s', 'printfix' ), $num ),
                'id'            => 'footer-4-' . $num,
                'description'   => sprintf( esc_html__( 'Footer Style 4 : %1$s', 'printfix' ), $num ),
                'before_widget' => '<div id="%1$s" class="footer__widget footer__widget-item-4 footer__widget-item-4-'.$num.' %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<div class="footer__widget-title footer__widget-title-4"><h4>',
                'after_title'   => '</h4></div>',
            ] );
        }
    }        
}
add_action( 'widgets_init', 'printfix_widgets_init' );