<?php

	/**
	 * Template part for displaying header layout three
	 *
	 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
	 *
	 * @package printfix
	*/
	// info
   $header_topbar_switch = get_theme_mod( 'header_topbar_switch', false );


   // Button Text
   $header_top_button_text = get_theme_mod( 'header_button_text', __( 'Let’s Talk', 'printfix' ) );
   $header_top_button_link = get_theme_mod( 'header_button_link', __( '#', 'printfix' ) );
   $header_cart_link = get_theme_mod( 'header_cart_link', __( '#', 'printfix' ) );
   $header_sing_link = get_theme_mod( 'header_sing_link', __( '#', 'printfix' ) );
   $header_wishlist_link = get_theme_mod( 'header_wishlist_link', __( '#', 'printfix' ) );
   // header right
   $header_social_switch = get_theme_mod( 'header_social_switch', false );
   $printfix_header_right = get_theme_mod( 'header_right_switch', false );
   $printfix_menu_col = $printfix_header_right ? 'col-xxl-6 col-xl-6 col-lg-8 d-none d-lg-block' : 'col-xxl-9 col-xl-9 col-lg-8 d-none d-lg-block text-end';

   //Phone
   $header_top_phone = get_theme_mod( 'header_phone', __( '+880190678956', 'printfix' ) );

   // Header charity Text
   $header_top_charity_text = get_theme_mod( 'header_top_charity_text', __( 'Open time: Sun To Thu 9:00AM To 6:00PM / Call:', 'printfix' ) );
   $header_card_switch = get_theme_mod( 'header_card_switch', true );

?>
<!-- Header area start -->
<header>
    <div id="header-sticky" class="header__area header-4  box-shadow-3 bg-headr-3">
        <?php if(!empty($header_topbar_switch)) : ?>
        <div class="header-4-top d-none d-md-block">
            <div class="container custom-container">
                <div class="header-4-top__wrapper d-flex justify-content-between align-items-center">
                    <ul class="header-4-top__wrapper-call">
                        <li><?php echo esc_html( $header_top_charity_text ); ?> <a
                                href="tel:<?php echo esc_html( $header_top_phone ); ?>"><?php echo esc_html( $header_top_phone ); ?></a>
                        </li>
                    </ul>
                    <?php if(!empty($header_social_switch)) : ?>
                    <div class="header-4-top__wrapper-social">
                        <div class="header-4-top__wrapper-social-follow">
                            <ul>
                                <li><?php echo esc_attr__( 'Follow Us -', 'printfix' )?></li>
                            </ul>
                        </div>
                        <div class="header-4-top__wrapper-social-list">
                            <?php printfix_header_social_profiles(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="container custom-container">
            <div class="mega__menu-wrapper p-relative">
                <div class="header__main header-4__main">
                    <div class="header__left">
                        <div class="header__logo header__logo-3">
                            <?php printfix_header_logo(); ?>
                        </div>
                    </div>
                    <div class="header__middle header-4__middle">
                        <div class="mean__menu-wrapper d-none d-lg-block">
                            <div class="main-menu header-4__main-menu">
                                <nav id="mobile-menu" class="mobile-menu">
                                    <?php printfix_header_menu(); ?>
                                </nav>
                            </div>
                        </div>
                        <?php if(!empty($printfix_header_right)) : ?>
                        <div class="header__right header-4__right">
                            <div class="header__action header-4__action d-flex align-items-center">

                                <?php  if ( !empty( $header_top_button_text ) ): ?>
                                <a href="<?php echo esc_url( $header_top_button_link ); ?>"
                                    class="header-4__right-btn d-none d-sm-inline-flex"><?php echo esc_html( $header_top_button_text ); ?></a>
                                <?php endif; ?>
                                <div class="header__social header-4__social d-none d-sm-inline-flex">
                                <?php if(!empty($header_card_switch)) : ?>
                                    <a href="<?php echo esc_url( $header_cart_link ); ?>">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M7.54572 18.9999C7.99759 18.9999 8.3639 18.6162 8.3639 18.1428C8.3639 17.6694 7.99759 17.2856 7.54572 17.2856C7.09385 17.2856 6.72754 17.6694 6.72754 18.1428C6.72754 18.6162 7.09385 18.9999 7.54572 18.9999Z"
                                                stroke="#001D08" stroke-width="1.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path
                                                d="M16.5447 18.9999C16.9966 18.9999 17.3629 18.6162 17.3629 18.1428C17.3629 17.6694 16.9966 17.2856 16.5447 17.2856C16.0929 17.2856 15.7266 17.6694 15.7266 18.1428C15.7266 18.6162 16.0929 18.9999 16.5447 18.9999Z"
                                                stroke="#001D08" stroke-width="1.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path
                                                d="M1 1H4.27273L6.46545 12.4771C6.54027 12.8718 6.7452 13.2263 7.04436 13.4785C7.34351 13.7308 7.71784 13.8649 8.10182 13.8571H16.0545C16.4385 13.8649 16.8129 13.7308 17.112 13.4785C17.4112 13.2263 17.6161 12.8718 17.6909 12.4771L19 5.28571H5.09091"
                                                stroke="#001D08" stroke-width="1.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                        </svg>
                                        <?php  if ( !empty( $header_card_switch ) ): ?>
                                        <div class="icon-wrapper">

                                                <?php if (class_exists('WooCommerce') && WC()->cart): ?>
                                                <div>
                                                    <span><?php echo esc_html(WC()->cart->cart_contents_count); ?></span>
                                                </div>
                                                <?php else: ?>
                                                <div>
                                                    <span>0</span> <!-- Default to 0 if WooCommerce is not available -->
                                                </div>
                                                <?php endif; ?>

                                        </div>
                                        <?php endif; ?>
                                    </a>
                                    <?php endif; ?>
                                </div>
                                <div class="header__hamburger ml-20 d-lg-none">
                                    <div class="sidebar__toggle">
                                        <button class="bar-icon">
                                            <span></span>
                                            <span></span>
                                            <span></span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(empty($printfix_header_right)) : ?>
                        <div class="header__hamburger ml-20 d-lg-none">
                            <div class="sidebar__toggle">
                                <button class="bar-icon">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </button>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- Header area end -->


<?php get_template_part( 'template-parts/header/header-side-info' ); ?>